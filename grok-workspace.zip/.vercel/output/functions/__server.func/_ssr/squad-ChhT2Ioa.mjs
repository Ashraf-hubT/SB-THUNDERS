import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { i as Route$14 } from "./router-BqvUT-Ki.mjs";
import { t as PublicShell } from "./public-shell-BOyI-Zlg.mjs";
import { t as EmptyState } from "./empty-state-BMSD6eul.mjs";
import { t as SectionHead } from "./section-head-v7RAHbAM.mjs";
import { t as SeasonSwitch } from "./season-switch-BULz71yR.mjs";
import { t as PlayerCard } from "./player-card-kewBYBDF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/squad-ChhT2Ioa.js
var import_jsx_runtime = require_jsx_runtime();
function SquadPage() {
	const data = Route$14.useLoaderData();
	const playing = data.squad.filter((s) => s.role !== "Management");
	const management = data.squad.filter((s) => s.role === "Management" || s.role === "Player + Management");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicShell, {
		settings: data.settings,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 py-14 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
					overline: data.season?.name ?? "Squad",
					title: "The Thunders",
					copy: "A player can belong to one season and not another. Roles can change. This list is the active published roster for the selected season."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeasonSwitch, {
					seasons: data.seasons,
					current: data.season,
					path: "/squad"
				})]
			}), data.squad.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: "No published players",
					copy: "The squad for this season has not been entered yet. HQ will add names, roles, and photographs before they appear here."
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4",
				children: playing.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerCard, { entry }, entry.id))
			}), management.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "font-display text-4xl text-ivory",
					children: "Management"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4",
					children: management.map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerCard, { entry }, `m-${entry.id}`))
				})]
			}) : null] })]
		})
	});
}
//#endregion
export { SquadPage as component };
