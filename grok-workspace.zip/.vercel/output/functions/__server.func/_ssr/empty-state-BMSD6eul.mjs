import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/empty-state-BMSD6eul.js
var import_jsx_runtime = require_jsx_runtime();
function EmptyState({ title, copy }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel relative overflow-hidden px-6 py-14 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 opacity-40 bg-[radial-gradient(ellipse_at_top,rgba(227,27,35,0.18),transparent_55%)]" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "relative font-display text-4xl text-ivory",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "relative mx-auto mt-3 max-w-md text-sm leading-relaxed text-steel",
				children: copy
			})
		]
	});
}
//#endregion
export { EmptyState as t };
