import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-4Kkadyjj.mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/button-CiAG7yUi.js
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium tracking-wide transition-transform duration-150 ease-out active:not-disabled:scale-[0.96] disabled:opacity-50 disabled:pointer-events-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-thunder/80", {
	variants: {
		variant: {
			thunder: "bg-thunder text-ivory hover:bg-thunder-dim uppercase text-sm",
			outline: "border border-ivory/20 text-ivory hover:border-thunder hover:text-thunder bg-transparent uppercase text-sm",
			ghost: "text-steel hover:text-ivory bg-transparent",
			ivory: "bg-ivory text-ink hover:bg-ivory/90 uppercase text-sm",
			danger: "bg-thunder/20 text-thunder border border-thunder/40 hover:bg-thunder/30"
		},
		size: {
			sm: "h-9 px-3 text-xs",
			md: "h-11 px-5",
			lg: "h-12 px-7 text-sm",
			icon: "h-11 w-11"
		}
	},
	defaultVariants: {
		variant: "thunder",
		size: "md"
	}
});
function Button({ className, variant, size, asChild, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
//#endregion
export { Button as t };
