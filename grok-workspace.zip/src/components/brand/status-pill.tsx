import { cn } from "@/lib/utils";

export function StatusPill({ status }: { status: string }) {
  const s = status.toLowerCase();
  if (s === "live") {
    return (
      <span className="inline-flex items-center gap-2 rounded-sm bg-thunder px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-ivory">
        <span className="live-dot" />
        Live now
      </span>
    );
  }
  if (s === "completed") {
    return (
      <span className="inline-flex rounded-sm border border-ivory/15 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-steel">
        Result
      </span>
    );
  }
  return (
    <span className="inline-flex rounded-sm border border-thunder/40 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-thunder">
      Upcoming
    </span>
  );
}

export function ResultMark({ result }: { result?: string | null }) {
  if (result === "won") {
    return <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-emerald-400">Won</span>;
  }
  if (result === "lost") {
    return <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-thunder">Lost</span>;
  }
  if (!result) return null;
  return (
    <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-steel">{result}</span>
  );
}

export function cnStatus(status: string) {
  return cn(status);
}
