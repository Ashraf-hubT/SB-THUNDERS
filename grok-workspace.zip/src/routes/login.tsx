import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/field";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const { user, isPending } = useCurrentUserState();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (isPending) {
    return <div className="min-h-dvh bg-navy" />;
  }
  if (user) return <Navigate to="/hq" />;

  async function onEmail(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      if (mode === "up") {
        const { error: err } = await authClient.signUp.email({
          email,
          password,
          name: name || "Administrator",
        });
        if (err) throw new Error(err.message ?? "Could not create account");
      } else {
        const { error: err } = await authClient.signIn.email({ email, password });
        if (err) throw new Error(err.message ?? "Could not sign in");
      }
      window.location.href = "/hq";
    } catch (err) {
      setError(err instanceof Error ? err.message : "Sign-in failed");
      setBusy(false);
    }
  }

  return (
    <main className="relative min-h-dvh overflow-hidden bg-ink">
      <div className="hero-storm absolute inset-0 opacity-50" />
      <div className="lightning-veil" />
      <div className="relative mx-auto flex min-h-dvh max-w-md flex-col justify-center px-5 py-16">
        <div className="mb-8 text-center">
          <img src="/team/logo.jpg" alt="" className="mx-auto h-20 w-20 object-contain" />
          <p className="mt-4 text-[11px] uppercase tracking-[0.32em] text-thunder">Restricted</p>
          <h1 className="mt-2 font-display text-5xl text-ivory">SB THUNDERS HQ</h1>
          <p className="mt-3 text-sm text-steel">Administrator access only.</p>
        </div>
        <div className="panel p-6">
          {authEnabled ? (
            <>
              <div className="flex flex-col gap-2">
                {GROK_PROVIDERS.filter((p) => p.idp === "google").map((p) => (
                  <Button
                    key={p.providerId}
                    type="button"
                    variant="ivory"
                    onClick={() => signIn(p.providerId, { callbackURL: "/hq", errorCallbackURL: "/login" })}
                  >
                    Continue with {p.label}
                  </Button>
                ))}
              </div>
              <div className="my-6 flex items-center gap-3 text-[10px] uppercase tracking-[0.2em] text-steel-2">
                <span className="h-px flex-1 bg-white/10" />
                Email
                <span className="h-px flex-1 bg-white/10" />
              </div>
              <form onSubmit={onEmail} className="space-y-4">
                {mode === "up" ? (
                  <Field label="Name">
                    <Input value={name} onChange={(e) => setName(e.target.value)} autoComplete="name" />
                  </Field>
                ) : null}
                <Field label="Email">
                  <Input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    autoComplete="email"
                  />
                </Field>
                <Field label="Password">
                  <Input
                    type="password"
                    required
                    minLength={8}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoComplete={mode === "up" ? "new-password" : "current-password"}
                  />
                </Field>
                {error ? <p className="text-sm text-thunder">{error}</p> : null}
                <Button type="submit" className="w-full" disabled={busy}>
                  {busy ? "Please wait…" : mode === "up" ? "Create administrator" : "Sign in"}
                </Button>
              </form>
              <button
                type="button"
                className="mt-4 w-full text-center text-xs text-steel hover:text-ivory"
                onClick={() => setMode(mode === "in" ? "up" : "in")}
              >
                {mode === "in" ? "Create administrator account" : "Have an account? Sign in"}
              </button>
            </>
          ) : (
            <p className="text-sm text-steel">Sign-in is disabled.</p>
          )}
        </div>
        <a href="/" className="mt-8 text-center text-xs uppercase tracking-[0.18em] text-steel hover:text-ivory">
          Back to the public site
        </a>
      </div>
    </main>
  );
}
