import { Outlet, createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getHqAccess } from "@/lib/server/hq";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/hq")({
  component: HqGate,
});

function HqGate() {
  const { user, isPending } = useCurrentUserState();
  const access = useQuery({
    queryKey: ["hq-access"],
    queryFn: () => getHqAccess(),
    enabled: Boolean(user),
    retry: false,
  });

  if (isPending) return <div className="min-h-dvh bg-ink" />;
  if (!user) return <RedirectToSignIn to="/login" />;
  if (access.isPending) return <div className="min-h-dvh bg-ink" />;

  const message = access.error instanceof Error ? access.error.message : "";
  if (message === "Unauthorized" || message.toLowerCase().includes("unauthorized")) {
    return <RedirectToSignIn to="/login" />;
  }
  if (access.error) {
    return (
      <main className="grid min-h-dvh place-items-center bg-ink px-6 text-center">
        <div>
          <p className="text-[11px] uppercase tracking-[0.24em] text-thunder">Restricted</p>
          <h1 className="mt-3 font-display text-5xl text-ivory">HQ is locked</h1>
          <p className="mt-4 max-w-md text-sm text-steel">
            Signed in as {user.primaryEmail ?? user.displayName}. This account is not on the SB THUNDERS
            administrator list.
          </p>
          <div className="mt-8">
            <Button asChild variant="outline">
              <a href="/">Return to the public site</a>
            </Button>
          </div>
        </div>
      </main>
    );
  }

  return <Outlet />;
}
