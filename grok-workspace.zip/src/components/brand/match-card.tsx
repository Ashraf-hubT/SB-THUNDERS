import { Link } from "@tanstack/react-router";
import { format } from "date-fns";
import type { Match } from "@/lib/types";
import { ResultMark, StatusPill } from "./status-pill";

function prettyDate(value: string | null) {
  if (!value) return "Date TBC";
  try {
    return format(new Date(value + "T12:00:00"), "EEE d MMM yyyy");
  } catch {
    return value;
  }
}

export function MatchCard({ match }: { match: Match }) {
  return (
    <Link
      to="/matches/$matchId"
      params={{ matchId: match.id }}
      className="panel group block p-5 transition-colors hover:border-thunder/50"
    >
      <div className="flex items-center justify-between gap-3">
        <StatusPill status={match.status} />
        <ResultMark result={match.result} />
      </div>
      <p className="mt-4 text-[11px] uppercase tracking-[0.2em] text-steel">SB Thunders vs</p>
      <h3 className="mt-1 font-display text-3xl leading-none text-ivory group-hover:text-thunder">
        {match.opponent || "Opponent TBC"}
      </h3>
      {match.competition ? (
        <p className="mt-2 text-xs uppercase tracking-[0.16em] text-thunder/80">{match.competition}</p>
      ) : null}
      <div className="mt-4 flex flex-wrap gap-x-4 gap-y-1 text-sm text-steel">
        <span>{prettyDate(match.matchDate)}</span>
        {match.matchTime ? <span>{match.matchTime}</span> : null}
        {match.venue ? <span>{match.venue}</span> : null}
      </div>
      {match.status === "completed" && (match.resultDescription || match.ourScoreText) ? (
        <p className="mt-4 text-sm text-ivory">
          {match.resultDescription || `${match.ourScoreText} — ${match.oppScoreText}`}
        </p>
      ) : null}
    </Link>
  );
}
