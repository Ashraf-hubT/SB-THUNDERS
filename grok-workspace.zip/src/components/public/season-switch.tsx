import { useRouter } from "@tanstack/react-router";
import type { Season } from "@/lib/types";
import { Select } from "@/components/ui/field";

export function SeasonSwitch({
  seasons,
  current,
  path,
}: {
  seasons: Season[];
  current?: Season | null;
  path: string;
}) {
  const router = useRouter();
  if (seasons.length < 2) return null;
  return (
    <div className="flex items-center gap-3">
      <span className="text-[11px] uppercase tracking-[0.18em] text-steel">Season</span>
      <Select
        aria-label="Select season"
        value={current?.slug ?? ""}
        className="h-10 w-auto min-w-40"
        onChange={(e) => {
          const slug = e.target.value;
          router.history.push(slug ? `${path}?season=${encodeURIComponent(slug)}` : path);
        }}
      >
        {seasons.map((s) => (
          <option key={s.id} value={s.slug}>
            {s.name}
            {s.isActive ? " · Active" : ""}
          </option>
        ))}
      </Select>
    </div>
  );
}
