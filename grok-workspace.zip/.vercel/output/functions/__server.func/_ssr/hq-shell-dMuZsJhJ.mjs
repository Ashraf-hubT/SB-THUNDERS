import { o as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-4Kkadyjj.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { f as useRouterState, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as Trophy, c as Menu, d as Image, f as Gauge, i as UserRound, l as List, m as CalendarDays, n as X, p as Camera, r as Users, s as Settings, t as Zap, u as LayoutDashboard } from "../_libs/lucide-react.mjs";
import { p as HQ_NAV } from "./router-BqvUT-Ki.mjs";
import { n as UserButton } from "./hq-DLvonivC.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hq-shell-dMuZsJhJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ICONS = {
	layout: LayoutDashboard,
	calendar: CalendarDays,
	users: Users,
	zap: Zap,
	list: List,
	chart: Gauge,
	image: Image,
	trophy: Trophy,
	settings: Settings,
	user: UserRound
};
function HqShell({ children, title }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-ink text-ivory",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "fixed inset-y-0 left-0 z-30 hidden w-60 border-r border-white/5 bg-navy-2 lg:flex lg:flex-col",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/hq",
						className: "flex items-center gap-2 border-b border-white/5 px-4 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: "/team/logo.jpg",
							alt: "",
							className: "h-9 w-9 object-contain"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl leading-none",
							children: "SB THUNDERS"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] uppercase tracking-[0.2em] text-thunder",
							children: "HQ"
						})] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "flex-1 overflow-y-auto px-2 py-3",
						children: HQ_NAV.map((item) => {
							const Icon = ICONS[item.icon] ?? LayoutDashboard;
							const active = item.to === "/hq" ? pathname === "/hq" : pathname.startsWith(item.to);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								className: cn("mb-0.5 flex min-h-11 items-center gap-3 px-3 text-sm", active ? "bg-thunder text-ivory" : "text-steel hover:bg-navy-3 hover:text-ivory"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" }), item.label]
							}, item.to);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-white/5 p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "mt-3 block text-[11px] uppercase tracking-[0.16em] text-steel hover:text-ivory",
							children: "View public site"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 flex h-14 items-center justify-between border-b border-white/5 bg-ink px-4 lg:hidden",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "inline-flex h-11 w-11 items-center justify-center",
						"aria-label": "Open menu",
						onClick: () => setOpen(true),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-5 w-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-xl",
						children: ["HQ · ", title]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Camera, { className: "h-5 w-5 opacity-0" })
				]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40 lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "absolute inset-0 bg-ink/70",
					"aria-label": "Close",
					onClick: () => setOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative h-full w-[82%] max-w-xs bg-navy-2 p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl",
							children: "HQ"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-11 w-11",
							onClick: () => setOpen(false),
							"aria-label": "Close menu",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
						})]
					}), HQ_NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: item.to,
						onClick: () => setOpen(false),
						className: "flex min-h-12 items-center px-2 text-sm text-ivory",
						children: item.label
					}, item.to))]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:pl-60",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "hidden border-b border-white/5 px-8 py-5 lg:block",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.22em] text-thunder",
						children: "SB Thunders HQ"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 font-display text-4xl",
						children: title
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "px-4 py-6 pb-28 sm:px-6 lg:px-8 lg:pb-12",
					children
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 grid grid-cols-4 border-t border-white/5 bg-ink lg:hidden",
				children: [
					{
						to: "/hq",
						label: "Home"
					},
					{
						to: "/hq/match-day",
						label: "Match"
					},
					{
						to: "/hq/players",
						label: "Squad"
					},
					{
						to: "/hq/matches",
						label: "List"
					}
				].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: item.to,
					className: cn("flex min-h-14 flex-col items-center justify-center text-[10px] uppercase tracking-[0.14em]", pathname === item.to || item.to !== "/hq" && pathname.startsWith(item.to) ? "text-thunder" : "text-steel"),
					children: item.label
				}, item.to))
			})
		]
	});
}
//#endregion
export { HqShell as t };
