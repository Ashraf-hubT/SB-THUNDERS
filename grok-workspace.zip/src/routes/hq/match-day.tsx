import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { HqShell } from "@/components/hq/hq-shell";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { MATCH_RESULTS, MATCH_STATUSES } from "@/lib/constants";
import { getHqMatchDay, saveMatch } from "@/lib/server/hq";

export const Route = createFileRoute("/hq/match-day")({ component: MatchDayPage });

function MatchDayPage() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["hq-match-day"], queryFn: () => getHqMatchDay() });
  const [matchId, setMatchId] = useState<string>("");
  const [opponent, setOpponent] = useState("");
  const [venue, setVenue] = useState("");
  const [matchDate, setMatchDate] = useState("");
  const [matchTime, setMatchTime] = useState("");
  const [status, setStatus] = useState("upcoming");
  const [ourScore, setOurScore] = useState("");
  const [oppScore, setOppScore] = useState("");
  const [result, setResult] = useState("");
  const [resultDescription, setResultDescription] = useState("");
  const [pom, setPom] = useState("");
  const [notes, setNotes] = useState("");
  const [cricheroesUrl, setCricheroesUrl] = useState("");
  const [squadIds, setSquadIds] = useState<string[]>([]);
  const [published, setPublished] = useState(true);

  useEffect(() => {
    if (!q.data) return;
    const current = q.data.matches.find((m) => m.id === matchId) ?? q.data.current;
    if (!current) return;
    setMatchId(current.id);
    setOpponent(current.opponent);
    setVenue(current.venue);
    setMatchDate(current.matchDate ?? "");
    setMatchTime(current.matchTime);
    setStatus(current.status);
    setOurScore(current.ourScoreText);
    setOppScore(current.oppScoreText);
    setResult(current.result);
    setResultDescription(current.resultDescription);
    setPom(current.playerOfMatchId ?? "");
    setNotes(current.notes);
    setCricheroesUrl(current.cricheroesUrl);
    setPublished(current.published);
    setSquadIds(q.data.current?.id === current.id ? q.data.selected : squadIds);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q.data, matchId]);

  const save = useMutation({
    mutationFn: (publish: boolean) =>
      saveMatch({
        data: {
          id: matchId || undefined,
          seasonId: q.data!.active!.id,
          opponent,
          venue,
          matchDate: matchDate || null,
          matchTime,
          status,
          isFeatured: true,
          published: publish,
          ourScoreText: ourScore,
          oppScoreText: oppScore,
          result,
          resultDescription,
          playerOfMatchId: pom || null,
          notes,
          cricheroesUrl,
          squadIds,
        },
      }),
    onSuccess: async () => {
      toast.success("Match day updated");
      await qc.invalidateQueries();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const roster = q.data?.roster ?? [];

  return (
    <HqShell title="Today's match">
      <p className="max-w-xl text-sm text-steel">
        Built for a phone. Update opponent, status, score, and today's XI, then publish.
      </p>
      <div className="mt-5">
        <Field label="Fixture">
          <Select value={matchId} onChange={(e) => setMatchId(e.target.value)}>
            <option value="">New match</option>
            {(q.data?.matches ?? []).map((m) => (
              <option key={m.id} value={m.id}>
                {m.opponent || "Untitled"} · {m.status} {m.published ? "" : "(draft)"}
              </option>
            ))}
          </Select>
        </Field>
      </div>
      <form
        className="mt-6 grid gap-4"
        onSubmit={(e) => {
          e.preventDefault();
          save.mutate(published);
        }}
      >
        <Field label="Opponent">
          <Input required value={opponent} onChange={(e) => setOpponent(e.target.value)} />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Date">
            <Input type="date" value={matchDate} onChange={(e) => setMatchDate(e.target.value)} />
          </Field>
          <Field label="Time">
            <Input value={matchTime} onChange={(e) => setMatchTime(e.target.value)} placeholder="4:00 PM" />
          </Field>
        </div>
        <Field label="Venue">
          <Input value={venue} onChange={(e) => setVenue(e.target.value)} />
        </Field>
        <Field label="Status">
          <Select value={status} onChange={(e) => setStatus(e.target.value)}>
            {MATCH_STATUSES.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </Select>
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="SB Thunders score">
            <Input value={ourScore} onChange={(e) => setOurScore(e.target.value)} placeholder="145/7 (20)" />
          </Field>
          <Field label="Opponent score">
            <Input value={oppScore} onChange={(e) => setOppScore(e.target.value)} />
          </Field>
        </div>
        <Field label="Result">
          <Select value={result} onChange={(e) => setResult(e.target.value)}>
            {MATCH_RESULTS.map((r) => (
              <option key={r || "none"} value={r}>
                {r || "Not set"}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Result description">
          <Input value={resultDescription} onChange={(e) => setResultDescription(e.target.value)} placeholder="Won by 8 wickets" />
        </Field>
        <Field label="Player of the match">
          <Select value={pom} onChange={(e) => setPom(e.target.value)}>
            <option value="">Not set</option>
            {roster.map((sp) => (
              <option key={sp.playerId} value={sp.playerId}>
                {sp.player.displayName}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="CricHeroes match URL">
          <Input value={cricheroesUrl} onChange={(e) => setCricheroesUrl(e.target.value)} />
        </Field>
        <Field label="Notes">
          <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
        </Field>
        <div>
          <p className="mb-2 text-[11px] uppercase tracking-[0.16em] text-steel">Today's squad</p>
          <ul className="divide-y divide-white/5 border border-white/10">
            {roster.length === 0 ? (
              <li className="px-3 py-4 text-sm text-steel">Add players to this season first.</li>
            ) : (
              roster.map((sp) => {
                const on = squadIds.includes(sp.playerId);
                return (
                  <li key={sp.playerId}>
                    <label className="flex min-h-12 items-center gap-3 px-3 text-sm">
                      <input
                        type="checkbox"
                        checked={on}
                        onChange={() =>
                          setSquadIds((ids) =>
                            on ? ids.filter((id) => id !== sp.playerId) : [...ids, sp.playerId],
                          )
                        }
                      />
                      <span className="flex-1 text-ivory">{sp.player.displayName}</span>
                      <span className="text-[10px] uppercase tracking-[0.12em] text-steel">{sp.role}</span>
                    </label>
                  </li>
                );
              })
            )}
          </ul>
        </div>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={published} onChange={(e) => setPublished(e.target.checked)} />
          Published on the public site
        </label>
        <div className="flex flex-col gap-2 sm:flex-row">
          <Button type="button" variant="outline" disabled={save.isPending} onClick={() => save.mutate(false)}>
            Save draft
          </Button>
          <Button type="button" disabled={save.isPending} onClick={() => save.mutate(true)}>
            {save.isPending ? "Saving…" : "Save & publish"}
          </Button>
        </div>
      </form>
    </HqShell>
  );
}
