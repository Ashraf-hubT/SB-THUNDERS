import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { b as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { r as createServerFn } from "./ssr.mjs";
import { a as hasGateSessionMarker } from "./server-BBjBCFBM.mjs";
import { v as createSsrRpc } from "./router-BqvUT-Ki.mjs";
import { i as signOut } from "./client-B40BzJxt.mjs";
import { t as authMiddleware } from "./middleware-Cf7rZssf.mjs";
import { t as useCurrentUser } from "./use-current-user-DG6UNzh9.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hq-DLvonivC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
var adminMw = [authMiddleware];
var getHqAccess = createServerFn({ method: "GET" }).middleware(adminMw).handler(createSsrRpc("55b831d6848f812dc5b5a05cf7a4b2bb92468ab8446e65b671494f15f556dcbd"));
var getHqDashboard = createServerFn({ method: "GET" }).middleware(adminMw).handler(createSsrRpc("f2dbe3e5afc3eb59ed9ad8f690ea14c3e36c53ff1ac80b8ef609feff4f49f92f"));
var getHqSeasons = createServerFn({ method: "GET" }).middleware(adminMw).handler(createSsrRpc("790730fe9ca755eb98e6cc527e695ea2dac00024234117699e649b8b39a009e4"));
var saveSeason = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(createSsrRpc("70fd2d3d3c68dbb0e006a0c3b7b4800c725df91242e5356f20ed6aa4a863df90"));
var setActiveSeason = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(createSsrRpc("fcdd5f31b1cabb90f6ff0a6ace28370e6e44cc0d893ab592d9115ba586d35676"));
var getHqPlayers = createServerFn({ method: "GET" }).middleware(adminMw).validator((data) => data).handler(createSsrRpc("73be6c4e27dfd064b9cb05f937f64822ddfdf0d6dae21998676e0479b1727c63"));
var savePlayer = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(createSsrRpc("ef99f77754bcf8f391766c4a2e18743637265b480c3affcd00bc8108cc6dc38b"));
var setPlayerSeason = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(createSsrRpc("799ee1dfbdcaeca4a8a923499c4ec4b057785998aaee78cf4068777351addbc5"));
var archivePlayer = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(createSsrRpc("4821bfc76543745c82f74604cff39cd4d67e0f4566982a16cbb6f646c4fba2e5"));
var getHqMatches = createServerFn({ method: "GET" }).middleware(adminMw).validator((data) => data).handler(createSsrRpc("7a7299c85d0c08303a88d60b87c983b1523a6b64d2157b25f011dd90226ca028"));
createServerFn({ method: "GET" }).middleware(adminMw).validator((data) => data).handler(createSsrRpc("68bbcac48f2b99702f7d03c9f336cc8788f7843d1ea2cd98f399cae101530bcc"));
var saveMatch = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(createSsrRpc("57c4aca885bd0b041838a74a25066321dd285e579c11e4912e09fea0bd26c442"));
var getHqMatchDay = createServerFn({ method: "GET" }).middleware(adminMw).handler(createSsrRpc("4552bb385fefed5b3758d3066abe1169327399d0e722ec6d142028b96f8b8149"));
var saveMedia = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(createSsrRpc("918c25a603ca31cde0e7b3047d909f6d82c853444a4dbe78d9bc232320680581"));
var getHqGallery = createServerFn({ method: "GET" }).middleware(adminMw).handler(createSsrRpc("b8f3af460956e7e243fd86bafb306ac4d69fac7cd5365d42227f2dfaedae8b02"));
var saveGalleryItem = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(createSsrRpc("cf914fc017eea846dc99b446889bb44b27c0ec2b0afdd0c6f8f75d212f5409e5"));
var deleteGalleryItem = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(createSsrRpc("d1642aa28dc70d3ecf8a243eba2ee0c4631003b19f0dfae0fb4f6b7d52aeeed2"));
var getHqAchievements = createServerFn({ method: "GET" }).middleware(adminMw).handler(createSsrRpc("bb220fafa420ed780873ec770da77b0330db4b9d75ff893d7aa0fd520d0a6f4a"));
var saveAchievement = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(createSsrRpc("f7d26abe2fdda37ed6274a6522366ea1165794273daf81f0b2534499fc5a819b"));
var deleteAchievement = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(createSsrRpc("6c99992ab8eb44dc119ee678ae09ec3eb73ee80c4610112c773baf7289f6d2cb"));
var saveSettings = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(createSsrRpc("2d5e0e59bf1ef53bd9426d9bce9e9e25814276eb0cb578f1df87ede0a1ca5438"));
var getHqSettings = createServerFn({ method: "GET" }).middleware(adminMw).handler(createSsrRpc("786536c47ce2eb4b10eba83486543983c5789b67316abef14c05f7fd4c7d9615"));
var addAllowlistEmail = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(createSsrRpc("7fde70b2ae28dffcdbc60a98548823f02a38a667c5444ee30d912059484a962e"));
var getHqInsights = createServerFn({ method: "GET" }).middleware(adminMw).validator((data) => data).handler(createSsrRpc("f36ad1aeb375c614daf9586e5b8b0b25c3e6bc054874b68af50009b374bd8390"));
//#endregion
export { saveSettings as C, saveSeason as S, setPlayerSeason as T, saveAchievement as _, deleteAchievement as a, saveMedia as b, getHqAchievements as c, getHqInsights as d, getHqMatchDay as f, getHqSettings as g, getHqSeasons as h, archivePlayer as i, getHqDashboard as l, getHqPlayers as m, UserButton as n, deleteGalleryItem as o, getHqMatches as p, addAllowlistEmail as r, getHqAccess as s, RedirectToSignIn as t, getHqGallery as u, saveGalleryItem as v, setActiveSeason as w, savePlayer as x, saveMatch as y };
