const MAX_CHARS = 1_200_000;

export async function compressImage(file: File, maxEdge = 1600, quality = 0.82): Promise<string> {
  if (!file.type.startsWith("image/")) {
    throw new Error("Please choose an image file.");
  }
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height));
  const w = Math.max(1, Math.round(bitmap.width * scale));
  const h = Math.max(1, Math.round(bitmap.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not process image.");
  ctx.drawImage(bitmap, 0, 0, w, h);
  let q = quality;
  let out = canvas.toDataURL("image/jpeg", q);
  while (out.length > MAX_CHARS && q > 0.5) {
    q -= 0.08;
    out = canvas.toDataURL("image/jpeg", q);
  }
  if (out.length > MAX_CHARS) {
    throw new Error("Image is still too large. Try a smaller photo.");
  }
  return out;
}
