import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 font-medium tracking-wide transition-transform duration-150 ease-out active:not-disabled:scale-[0.96] disabled:opacity-50 disabled:pointer-events-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-thunder/80",
  {
    variants: {
      variant: {
        thunder:
          "bg-thunder text-ivory hover:bg-thunder-dim uppercase text-sm",
        outline:
          "border border-ivory/20 text-ivory hover:border-thunder hover:text-thunder bg-transparent uppercase text-sm",
        ghost: "text-steel hover:text-ivory bg-transparent",
        ivory: "bg-ivory text-ink hover:bg-ivory/90 uppercase text-sm",
        danger: "bg-thunder/20 text-thunder border border-thunder/40 hover:bg-thunder/30",
      },
      size: {
        sm: "h-9 px-3 text-xs",
        md: "h-11 px-5",
        lg: "h-12 px-7 text-sm",
        icon: "h-11 w-11",
      },
    },
    defaultVariants: { variant: "thunder", size: "md" },
  },
);

export function Button({
  className,
  variant,
  size,
  asChild,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants> & { asChild?: boolean }) {
  const Comp = asChild ? Slot : "button";
  return <Comp className={cn(buttonVariants({ variant, size }), className)} {...props} />;
}
