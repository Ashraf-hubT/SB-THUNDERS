export function EmptyState({
  title,
  copy,
}: {
  title: string;
  copy: string;
}) {
  return (
    <div className="panel relative overflow-hidden px-6 py-14 text-center">
      <div className="pointer-events-none absolute inset-0 opacity-40 bg-[radial-gradient(ellipse_at_top,rgba(227,27,35,0.18),transparent_55%)]" />
      <p className="relative font-display text-4xl text-ivory">{title}</p>
      <p className="relative mx-auto mt-3 max-w-md text-sm leading-relaxed text-steel">{copy}</p>
    </div>
  );
}
