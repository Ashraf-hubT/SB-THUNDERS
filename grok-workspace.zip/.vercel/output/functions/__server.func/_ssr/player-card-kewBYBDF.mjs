import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as SafeImg } from "./safe-img-BxRY9_YA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/player-card-kewBYBDF.js
var import_jsx_runtime = require_jsx_runtime();
function PlayerCard({ entry }) {
	const p = entry.player;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/squad/$playerId",
		params: { playerId: p.id },
		className: "group block",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative aspect-[3/4] overflow-hidden bg-navy-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SafeImg, {
					src: p.photoUrl,
					alt: p.displayName,
					className: "h-full w-full object-cover object-top transition-transform duration-500 group-hover:scale-[1.04]",
					fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-full items-end p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-7xl text-ivory/10",
							children: entry.jerseyNumber ? `#${entry.jerseyNumber}` : "SB"
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-gradient-to-t from-ink via-transparent to-transparent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-0 bottom-0 p-4",
					children: [
						entry.jerseyNumber ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-display text-3xl leading-none text-thunder",
							children: ["#", entry.jerseyNumber]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-1 font-display text-2xl leading-none text-ivory",
							children: p.displayName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-[11px] uppercase tracking-[0.18em] text-steel",
							children: entry.role
						}),
						entry.isCaptain ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-[10px] uppercase tracking-[0.2em] text-thunder",
							children: "Captain"
						}) : null
					]
				})
			]
		})
	});
}
//#endregion
export { PlayerCard as t };
