import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { d as GALLERY_CATEGORIES, f as GALLERY_LABELS } from "./router-BqvUT-Ki.mjs";
import { n as Input, r as Select, t as Field } from "./field-Cnn-JkFT.mjs";
import { b as saveMedia, o as deleteGalleryItem, u as getHqGallery, v as saveGalleryItem } from "./hq-DLvonivC.mjs";
import { t as HqShell } from "./hq-shell-dMuZsJhJ.mjs";
import { t as compressImage } from "./image-BpjZNsak.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/gallery-bc9NjE1T.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function GalleryHq() {
	const qc = useQueryClient();
	const q = useQuery({
		queryKey: ["hq-gallery"],
		queryFn: () => getHqGallery()
	});
	const [title, setTitle] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("moments");
	const [seasonId, setSeasonId] = (0, import_react.useState)("");
	const [published, setPublished] = (0, import_react.useState)(true);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const del = useMutation({
		mutationFn: (id) => deleteGalleryItem({ data: { id } }),
		onSuccess: async () => {
			toast.success("Removed");
			await qc.invalidateQueries();
		}
	});
	async function onFiles(files) {
		if (!files?.length) return;
		setBusy(true);
		try {
			for (const file of Array.from(files)) {
				const dataUrl = await compressImage(file);
				const media = await saveMedia({ data: {
					dataUrl,
					alt: title || file.name
				} });
				await saveGalleryItem({ data: {
					title,
					category,
					imageUrl: media.url,
					altText: title || "SB Thunders",
					seasonId: seasonId || null,
					published
				} });
			}
			toast.success("Photos uploaded");
			await qc.invalidateQueries();
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Upload failed");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HqShell, {
		title: "Gallery",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "panel grid gap-4 p-5 sm:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Title",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: title,
						onChange: (e) => setTitle(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Category",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						value: category,
						onChange: (e) => setCategory(e.target.value),
						children: GALLERY_CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: c,
							children: GALLERY_LABELS[c]
						}, c))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Season",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: seasonId,
						onChange: (e) => setSeasonId(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "All seasons"
						}), (q.data?.seasons ?? []).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s.id,
							children: s.name
						}, s.id))]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 self-end text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: published,
						onChange: (e) => setPublished(e.target.checked)
					}), "Publish immediately"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "sm:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mb-1.5 block text-[11px] uppercase tracking-[0.16em] text-steel",
							children: "Photos"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "file",
							accept: "image/*",
							multiple: true,
							disabled: busy,
							onChange: (e) => void onFiles(e.target.files)
						}),
						busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-steel",
							children: "Uploading…"
						}) : null
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4",
			children: (q.data?.items ?? []).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figure", {
				className: "panel overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: item.imageUrl,
					alt: "",
					className: "aspect-square w-full object-cover"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("figcaption", {
					className: "flex items-center justify-between gap-2 p-2 text-xs text-steel",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [item.title || GALLERY_LABELS[item.category] || item.category, item.published ? "" : " · draft"] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "text-thunder",
						onClick: () => del.mutate(item.id),
						children: "Delete"
					})]
				})]
			}, item.id))
		})]
	});
}
//#endregion
export { GalleryHq as component };
