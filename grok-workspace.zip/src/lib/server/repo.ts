import { getSql } from "@/lib/db";
import { EMPTY_INSIGHTS } from "@/lib/defaults";
import type {
  Achievement,
  GalleryItem,
  Match,
  MatchSquadMember,
  Player,
  Season,
  SeasonPlayer,
  SiteSettings,
  TeamInsights,
} from "@/lib/types";
import {
  computeInsights,
  mapAchievement,
  mapGallery,
  mapMatch,
  mapPlayer,
  mapSeason,
  mapSeasonPlayer,
  mapSettings,
} from "./map";

export async function fetchSettings(): Promise<SiteSettings> {
  const sql = await getSql();
  const rows = await sql<Record<string, unknown>>`select * from site_settings where id = 'site'`;
  return mapSettings(rows[0]);
}

export async function fetchSeasons(): Promise<Season[]> {
  const sql = await getSql();
  const rows = await sql<Record<string, unknown>>`
    select * from seasons order by start_year desc, name desc
  `;
  return rows.map(mapSeason);
}

export async function fetchSeasonBySlugOrActive(slug?: string): Promise<Season | null> {
  const sql = await getSql();
  if (slug) {
    const rows = await sql<Record<string, unknown>>`select * from seasons where slug = ${slug} limit 1`;
    if (rows[0]) return mapSeason(rows[0]);
  }
  const active = await sql<Record<string, unknown>>`
    select * from seasons where is_active = true order by start_year desc limit 1
  `;
  return active[0] ? mapSeason(active[0]) : null;
}

export async function fetchSquad(seasonId: string, opts?: { includeArchived?: boolean }): Promise<SeasonPlayer[]> {
  const sql = await getSql();
  const rows = await sql<Record<string, unknown>>`
    select
      sp.*,
      p.id as p_id,
      p.full_name as p_full_name,
      p.display_name as p_display_name,
      p.photo_url as p_photo_url,
      p.batting_style as p_batting_style,
      p.bowling_style as p_bowling_style,
      p.bio as p_bio,
      p.cricheroes_url as p_cricheroes_url,
      p.instagram_url as p_instagram_url,
      p.twitter_url as p_twitter_url,
      p.status as p_status
    from season_players sp
    join players p on p.id = sp.player_id
    where sp.season_id = ${seasonId}
    order by sp.display_order asc, p.display_name asc
  `;
  const mapped = rows.map(mapSeasonPlayer);
  if (opts?.includeArchived) return mapped;
  return mapped.filter((sp) => sp.status === "active" && sp.player.status === "active");
}

export async function fetchPlayer(id: string): Promise<Player | null> {
  const sql = await getSql();
  const rows = await sql<Record<string, unknown>>`select * from players where id = ${id}`;
  return rows[0] ? mapPlayer(rows[0]) : null;
}

export async function fetchPlayerSeasons(playerId: string): Promise<SeasonPlayer[]> {
  const sql = await getSql();
  const rows = await sql<Record<string, unknown>>`
    select
      sp.*,
      p.id as p_id,
      p.full_name as p_full_name,
      p.display_name as p_display_name,
      p.photo_url as p_photo_url,
      p.batting_style as p_batting_style,
      p.bowling_style as p_bowling_style,
      p.bio as p_bio,
      p.cricheroes_url as p_cricheroes_url,
      p.instagram_url as p_instagram_url,
      p.twitter_url as p_twitter_url,
      p.status as p_status
    from season_players sp
    join players p on p.id = sp.player_id
    where sp.player_id = ${playerId}
    order by sp.id
  `;
  return rows.map(mapSeasonPlayer);
}

export async function fetchMatches(
  seasonId: string,
  opts?: { publishedOnly?: boolean },
): Promise<Match[]> {
  const sql = await getSql();
  const rows = await sql<Record<string, unknown>>`
    select m.*, pom.display_name as pom_name
    from matches m
    left join players pom on pom.id = m.player_of_match_id
    where m.season_id = ${seasonId}
    order by m.match_date desc nulls last, m.created_at desc
  `;
  const mapped = rows.map(mapMatch);
  if (opts?.publishedOnly) return mapped.filter((m) => m.published);
  return mapped;
}

export async function fetchMatch(id: string): Promise<Match | null> {
  const sql = await getSql();
  const rows = await sql<Record<string, unknown>>`
    select m.*, pom.display_name as pom_name
    from matches m
    left join players pom on pom.id = m.player_of_match_id
    where m.id = ${id}
  `;
  return rows[0] ? mapMatch(rows[0]) : null;
}

export async function fetchMatchSquad(matchId: string): Promise<MatchSquadMember[]> {
  const sql = await getSql();
  const rows = await sql<Record<string, unknown>>`
    select
      ms.match_id, ms.player_id, ms.is_playing, ms.batting_order,
      p.id as p_id,
      p.full_name as p_full_name,
      p.display_name as p_display_name,
      p.photo_url as p_photo_url,
      p.batting_style as p_batting_style,
      p.bowling_style as p_bowling_style,
      p.bio as p_bio,
      p.cricheroes_url as p_cricheroes_url,
      p.instagram_url as p_instagram_url,
      p.twitter_url as p_twitter_url,
      p.status as p_status,
      sp.role as role,
      sp.jersey_number as jersey_number
    from match_squad ms
    join players p on p.id = ms.player_id
    left join matches m on m.id = ms.match_id
    left join season_players sp on sp.player_id = ms.player_id and sp.season_id = m.season_id
    where ms.match_id = ${matchId} and ms.is_playing = true
    order by ms.batting_order asc, p.display_name asc
  `;
  return rows.map((row) => ({
    playerId: String(row.player_id),
    isPlaying: Boolean(row.is_playing),
    battingOrder: Number(row.batting_order ?? 0),
    role: String(row.role ?? ""),
    jerseyNumber: String(row.jersey_number ?? ""),
    player: mapPlayer(row, "p_"),
  }));
}

export async function fetchGallery(
  seasonId: string | null,
  opts?: { publishedOnly?: boolean; limit?: number },
): Promise<GalleryItem[]> {
  const sql = await getSql();
  const rows = seasonId
    ? await sql<Record<string, unknown>>`
        select * from gallery_items
        where season_id = ${seasonId} or season_id is null
        order by display_order asc, created_at desc
      `
    : await sql<Record<string, unknown>>`
        select * from gallery_items
        order by display_order asc, created_at desc
      `;
  let mapped = rows.map(mapGallery);
  if (opts?.publishedOnly) mapped = mapped.filter((g) => g.published);
  if (opts?.limit) mapped = mapped.slice(0, opts.limit);
  return mapped;
}

export async function fetchAchievements(
  seasonId: string | null,
  opts?: { publishedOnly?: boolean },
): Promise<Achievement[]> {
  const sql = await getSql();
  const rows = seasonId
    ? await sql<Record<string, unknown>>`
        select * from achievements
        where season_id = ${seasonId} or season_id is null
        order by display_order asc, year desc, created_at desc
      `
    : await sql<Record<string, unknown>>`
        select * from achievements
        order by display_order asc, year desc, created_at desc
      `;
  const mapped = rows.map(mapAchievement);
  if (opts?.publishedOnly) return mapped.filter((a) => a.published);
  return mapped;
}

export async function fetchInsights(seasonId: string): Promise<TeamInsights> {
  const matches = (await fetchMatches(seasonId, { publishedOnly: true })).filter(
    (m) => m.status === "completed",
  );
  const sql = await getSql();
  const runRows = await sql<{ name: string; runs: number }>`
    select p.display_name as name, sum(s.runs)::int as runs
    from player_match_stats s
    join players p on p.id = s.player_id
    join matches m on m.id = s.match_id
    where m.season_id = ${seasonId} and m.published = true and s.runs is not null
    group by p.display_name
    having sum(s.runs) > 0
    order by sum(s.runs) desc
    limit 5
  `;
  const wicketRows = await sql<{ name: string; wickets: number }>`
    select p.display_name as name, sum(s.wickets)::int as wickets
    from player_match_stats s
    join players p on p.id = s.player_id
    join matches m on m.id = s.match_id
    where m.season_id = ${seasonId} and m.published = true and s.wickets is not null
    group by p.display_name
    having sum(s.wickets) > 0
    order by sum(s.wickets) desc
    limit 5
  `;
  const best = await sql<{ best: number | null }>`
    select max(s.runs)::int as best
    from player_match_stats s
    join matches m on m.id = s.match_id
    where m.season_id = ${seasonId} and m.published = true
  `;
  return computeInsights(matches, runRows, wicketRows, best[0]?.best ?? null);
}

export function pickFeaturedMatch(matches: Match[]): {
  featured: Match | null;
  next: Match | null;
  recent: Match | null;
} {
  const published = matches.filter((m) => m.published);
  const live = published.find((m) => m.status === "live");
  const flagged = published.find((m) => m.isFeatured);
  const upcoming = published
    .filter((m) => m.status === "upcoming")
    .slice()
    .sort((a, b) => String(a.matchDate ?? "9999").localeCompare(String(b.matchDate ?? "9999")));
  const completed = published
    .filter((m) => m.status === "completed")
    .slice()
    .sort((a, b) => String(b.matchDate ?? "").localeCompare(String(a.matchDate ?? "")));

  const today = new Date().toISOString().slice(0, 10);
  const todayMatch = published.find((m) => m.matchDate === today);

  return {
    featured: live ?? flagged ?? todayMatch ?? upcoming[0] ?? null,
    next: upcoming[0] ?? null,
    recent: completed[0] ?? null,
  };
}

export { EMPTY_INSIGHTS };
