import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { a as Route$15 } from "./router-BqvUT-Ki.mjs";
import { t as PublicShell } from "./public-shell-BOyI-Zlg.mjs";
import { t as EmptyState } from "./empty-state-BMSD6eul.mjs";
import { t as SectionHead } from "./section-head-v7RAHbAM.mjs";
import { t as SeasonSwitch } from "./season-switch-BULz71yR.mjs";
import { n as MatchCard, t as FeaturedMatch } from "./featured-match-DcnasVJS.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/matches-RMOg5Pfr.js
var import_jsx_runtime = require_jsx_runtime();
function MatchesPage() {
	const data = Route$15.useLoaderData();
	const upcoming = data.matches.filter((m) => m.status === "upcoming" || m.status === "live");
	const completed = data.matches.filter((m) => m.status === "completed");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PublicShell, {
		settings: data.settings,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto max-w-7xl px-4 py-14 sm:px-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
						overline: data.season?.name ?? "Fixtures",
						title: "Matches"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeasonSwitch, {
						seasons: data.seasons,
						current: data.season,
						path: "/matches"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeaturedMatch, {
				match: data.featured ?? data.next,
				squad: []
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-7xl px-4 py-16 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-4xl text-ivory",
						children: "Upcoming"
					}),
					upcoming.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
							title: "No upcoming fixtures",
							copy: "The next match will be published from HQ when it is locked."
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3",
						children: upcoming.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, { match: m }, m.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-16 font-display text-4xl text-ivory",
						children: "Recent"
					}),
					completed.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
							title: "No published results",
							copy: "Completed matches appear after they are reviewed and published."
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3",
						children: completed.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, { match: m }, m.id))
					})
				]
			})
		]
	});
}
//#endregion
export { MatchesPage as component };
