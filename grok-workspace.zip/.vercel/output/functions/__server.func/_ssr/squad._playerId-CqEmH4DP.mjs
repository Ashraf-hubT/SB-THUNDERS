import { n as isHttpUrl } from "./utils-4Kkadyjj.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as Route$2 } from "./router-BqvUT-Ki.mjs";
import { t as PublicShell } from "./public-shell-BOyI-Zlg.mjs";
import { t as EmptyState } from "./empty-state-BMSD6eul.mjs";
import { t as Button } from "./button-CiAG7yUi.mjs";
import { t as SafeImg } from "./safe-img-BxRY9_YA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/squad._playerId-CqEmH4DP.js
var import_jsx_runtime = require_jsx_runtime();
function PlayerPage() {
	const data = Route$2.useLoaderData();
	const p = data.player;
	if (!p) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicShell, {
		settings: data.settings,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-3xl px-4 py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "Player not found",
				copy: "This profile is unavailable or has been archived."
			})
		})
	});
	const latestRole = data.seasons[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicShell, {
		settings: data.settings,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[0.9fr_1.1fr] lg:py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative aspect-[3/4] overflow-hidden bg-navy-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SafeImg, {
					src: p.photoUrl,
					alt: p.displayName,
					className: "h-full w-full object-cover object-top",
					fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex h-full items-end p-6",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-8xl text-ivory/10",
							children: "SB"
						})
					})
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-[11px] uppercase tracking-[0.28em] text-thunder",
					children: [latestRole?.role ?? "SB Thunders", latestRole?.jerseyNumber ? `  ·  #${latestRole.jerseyNumber}` : ""]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 font-display text-6xl leading-none text-ivory sm:text-7xl",
					children: p.displayName
				}),
				p.fullName !== p.displayName ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-steel",
					children: p.fullName
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-8 grid gap-4 sm:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "panel p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-[10px] uppercase tracking-[0.18em] text-steel",
							children: "Batting"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 text-ivory",
							children: p.battingStyle || "—"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "panel p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-[10px] uppercase tracking-[0.18em] text-steel",
							children: "Bowling"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 text-ivory",
							children: p.bowlingStyle || "—"
						})]
					})]
				}),
				p.bio ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 max-w-xl text-sm leading-relaxed text-steel",
					children: p.bio
				}) : null,
				data.seasons.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.18em] text-steel",
						children: "Seasons"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2",
						children: data.seasons.map((sp) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex flex-wrap items-center justify-between gap-2 border-b border-white/5 py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-ivory",
								children: sp.seasonId.replace("season-", "")
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-steel",
								children: [
									sp.role,
									sp.managementTitle ? ` · ${sp.managementTitle}` : "",
									sp.jerseyNumber ? ` · #${sp.jerseyNumber}` : ""
								]
							})]
						}, sp.id))
					})]
				}) : null,
				data.appearances.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.18em] text-steel",
						children: "Match performances"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 divide-y divide-white/5 border border-white/5",
						children: data.appearances.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex justify-between gap-3 px-4 py-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-ivory",
								children: ["vs ", a.opponent]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular text-steel",
								children: [
									a.runs !== null ? `${a.runs} runs` : "",
									a.runs !== null && a.wickets !== null ? " · " : "",
									a.wickets !== null ? `${a.wickets} wkts` : ""
								]
							})]
						}, a.matchId))
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-sm text-steel",
					children: "Statistics will appear when match performances are recorded."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-wrap gap-3",
					children: [isHttpUrl(p.cricheroesUrl) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: p.cricheroesUrl,
							target: "_blank",
							rel: "noreferrer",
							children: "View on CricHeroes ↗"
						})
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/squad",
							children: "Back to squad"
						})
					})]
				})
			] })]
		})
	});
}
//#endregion
export { PlayerPage as component };
