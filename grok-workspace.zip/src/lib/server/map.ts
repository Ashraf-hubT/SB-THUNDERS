import { DEFAULT_SETTINGS } from "@/lib/defaults";
import { winPct } from "@/lib/utils";
import type {
  Achievement,
  GalleryItem,
  Match,
  Player,
  Season,
  SeasonPlayer,
  SiteSettings,
  TeamInsights,
} from "@/lib/types";
import { EMPTY_INSIGHTS } from "@/lib/defaults";

export function mapSettings(row: Record<string, unknown> | undefined): SiteSettings {
  if (!row) return DEFAULT_SETTINGS;
  return {
    id: String(row.id ?? "site"),
    teamName: String(row.team_name ?? DEFAULT_SETTINGS.teamName),
    tagline: String(row.tagline ?? DEFAULT_SETTINGS.tagline),
    supportingCopy: String(row.supporting_copy ?? DEFAULT_SETTINGS.supportingCopy),
    heroLine1: String(row.hero_line_1 ?? DEFAULT_SETTINGS.heroLine1),
    heroLine2: String(row.hero_line_2 ?? DEFAULT_SETTINGS.heroLine2),
    quoteLine: String(row.quote_line ?? ""),
    story: String(row.story ?? ""),
    origin: String(row.origin ?? ""),
    valuesText: String(row.values_text ?? ""),
    philosophy: String(row.philosophy ?? ""),
    milestones: String(row.milestones ?? ""),
    culture: String(row.culture ?? ""),
    email: String(row.email ?? DEFAULT_SETTINGS.email),
    instagramUrl: String(row.instagram_url ?? ""),
    twitterUrl: String(row.twitter_url ?? ""),
    facebookUrl: String(row.facebook_url ?? ""),
    youtubeUrl: String(row.youtube_url ?? ""),
    whatsappUrl: String(row.whatsapp_url ?? ""),
    cricheroesTeamUrl: String(row.cricheroes_team_url ?? ""),
    adminName: String(row.admin_name ?? DEFAULT_SETTINGS.adminName),
    adminRole: String(row.admin_role ?? DEFAULT_SETTINGS.adminRole),
    adminPhotoUrl: String(row.admin_photo_url ?? DEFAULT_SETTINGS.adminPhotoUrl),
    adminBio: String(row.admin_bio ?? ""),
    adminDeepDiveUrl: String(row.admin_deep_dive_url ?? ""),
    logoUrl: String(row.logo_url ?? DEFAULT_SETTINGS.logoUrl),
    seoTitle: String(row.seo_title ?? DEFAULT_SETTINGS.seoTitle),
    seoDescription: String(row.seo_description ?? DEFAULT_SETTINGS.seoDescription),
  };
}

export function mapSeason(row: Record<string, unknown>): Season {
  return {
    id: String(row.id),
    name: String(row.name ?? ""),
    slug: String(row.slug ?? ""),
    startYear: Number(row.start_year ?? 0),
    endYear: Number(row.end_year ?? 0),
    isActive: Boolean(row.is_active),
    isArchived: Boolean(row.is_archived),
    tagline: String(row.tagline ?? ""),
    notes: String(row.notes ?? ""),
  };
}

export function mapPlayer(row: Record<string, unknown>, prefix = ""): Player {
  const g = (k: string) => row[prefix + k];
  return {
    id: String(g("id") ?? row.player_id ?? ""),
    fullName: String(g("full_name") ?? ""),
    displayName: String(g("display_name") ?? ""),
    photoUrl: String(g("photo_url") ?? ""),
    battingStyle: String(g("batting_style") ?? ""),
    bowlingStyle: String(g("bowling_style") ?? ""),
    bio: String(g("bio") ?? ""),
    cricheroesUrl: String(g("cricheroes_url") ?? ""),
    instagramUrl: String(g("instagram_url") ?? ""),
    twitterUrl: String(g("twitter_url") ?? ""),
    status: g("status") === "archived" ? "archived" : "active",
  };
}

export function mapSeasonPlayer(row: Record<string, unknown>): SeasonPlayer {
  return {
    id: String(row.id),
    seasonId: String(row.season_id),
    playerId: String(row.player_id),
    role: String(row.role ?? "Batter"),
    managementTitle: String(row.management_title ?? ""),
    jerseyNumber: String(row.jersey_number ?? ""),
    isCaptain: Boolean(row.is_captain),
    isViceCaptain: Boolean(row.is_vice_captain),
    displayOrder: Number(row.display_order ?? 0),
    status: row.status === "archived" ? "archived" : "active",
    player: mapPlayer(row, "p_"),
  };
}

export function mapMatch(row: Record<string, unknown>): Match {
  return {
    id: String(row.id),
    seasonId: String(row.season_id),
    opponent: String(row.opponent ?? ""),
    venue: String(row.venue ?? ""),
    matchDate: row.match_date ? String(row.match_date) : null,
    matchTime: String(row.match_time ?? ""),
    status: String(row.status ?? "upcoming"),
    isFeatured: Boolean(row.is_featured),
    published: Boolean(row.published),
    ourScoreText: String(row.our_score_text ?? ""),
    oppScoreText: String(row.opp_score_text ?? ""),
    ourRuns: row.our_runs === null || row.our_runs === undefined ? null : Number(row.our_runs),
    oppRuns: row.opp_runs === null || row.opp_runs === undefined ? null : Number(row.opp_runs),
    result: String(row.result ?? ""),
    resultDescription: String(row.result_description ?? ""),
    playerOfMatchId: row.player_of_match_id ? String(row.player_of_match_id) : null,
    notes: String(row.notes ?? ""),
    cricheroesUrl: String(row.cricheroes_url ?? ""),
    competition: String(row.competition ?? ""),
    sourceNote: String(row.source_note ?? ""),
    playerOfMatchName: row.pom_name ? String(row.pom_name) : null,
  };
}

export function mapAchievement(row: Record<string, unknown>): Achievement {
  return {
    id: String(row.id),
    seasonId: row.season_id ? String(row.season_id) : null,
    matchId: row.match_id ? String(row.match_id) : null,
    title: String(row.title ?? ""),
    year: String(row.year ?? ""),
    result: String(row.result ?? ""),
    description: String(row.description ?? ""),
    imageUrl: String(row.image_url ?? ""),
    competition: String(row.competition ?? ""),
    published: Boolean(row.published),
    displayOrder: Number(row.display_order ?? 0),
  };
}

export function mapGallery(row: Record<string, unknown>): GalleryItem {
  return {
    id: String(row.id),
    seasonId: row.season_id ? String(row.season_id) : null,
    title: String(row.title ?? ""),
    category: String(row.category ?? "moments"),
    imageUrl: String(row.image_url ?? ""),
    altText: String(row.alt_text ?? ""),
    published: Boolean(row.published),
    displayOrder: Number(row.display_order ?? 0),
  };
}

export function computeInsights(
  matches: Match[],
  runRows: { name: string; runs: number }[],
  wicketRows: { name: string; wickets: number }[],
  bestScore: number | null,
): TeamInsights {
  const completed = matches.filter((m) => m.status === "completed");
  const played = completed.length;
  const wins = completed.filter((m) => m.result === "won").length;
  const losses = completed.filter((m) => m.result === "lost").length;
  const draws = completed.filter((m) => m.result === "draw" || m.result === "tie").length;
  const runValues = completed
    .map((m) => m.ourRuns)
    .filter((n): n is number => typeof n === "number" && Number.isFinite(n));
  return {
    played,
    wins,
    losses,
    draws,
    winPct: winPct(wins, played),
    highestScore: runValues.length ? Math.max(...runValues) : null,
    lowestScore: runValues.length ? Math.min(...runValues) : null,
    bestIndividualScore: bestScore,
    topRunScorer: runRows[0] ?? null,
    topWicketTaker: wicketRows[0] ?? null,
  };
}

export function emptyInsights(): TeamInsights {
  return { ...EMPTY_INSIGHTS };
}
