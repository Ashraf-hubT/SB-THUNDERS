import { useState, type ReactNode } from "react";
import { cn } from "@/lib/utils";

export function SafeImg({
  src,
  alt,
  className,
  fallback,
}: {
  src?: string | null;
  alt: string;
  className?: string;
  fallback?: ReactNode;
}) {
  const [ok, setOk] = useState(true);
  if (!src || !ok) {
    return (
      <div className={cn("bg-navy-3", className)} aria-hidden>
        {fallback ?? null}
      </div>
    );
  }
  return (
    <img
      src={src}
      alt={alt}
      className={className}
      loading="lazy"
      onError={() => setOk(false)}
    />
  );
}
