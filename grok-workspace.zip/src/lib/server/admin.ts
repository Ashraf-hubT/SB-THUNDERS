import { dbSource, getSql } from "@/lib/db";

export class ForbiddenError extends Error {
  readonly status = 403;
  constructor() {
    super("Forbidden");
    this.name = "ForbiddenError";
  }
}

export type AdminIdentity = {
  userId: string;
  email: string;
  displayName: string;
};

export async function assertAdmin(userId: string): Promise<AdminIdentity> {
  const sql = await getSql();

  const existing = await sql<{ user_id: string; email: string; display_name: string }>`
    select user_id, email, display_name from admins where user_id = ${userId}
  `;
  if (existing[0]) {
    return {
      userId,
      email: existing[0].email,
      displayName: existing[0].display_name,
    };
  }

  const users = await sql<{ email: string | null; name: string | null }>`
    select email, name from "user" where id = ${userId}
  `;
  const email = (users[0]?.email ?? "").toLowerCase();
  const displayName = users[0]?.name ?? "Administrator";

  const allowed = email
    ? await sql<{ email: string }>`
        select email from admin_allowlist where lower(email) = ${email}
      `
    : [];

  const counts = await sql<{ n: number }>`select count(*)::int as n from admins`;
  const adminCount = counts[0]?.n ?? 0;

  const canBootstrap = adminCount === 0 && dbSource === "pglite";
  if (allowed[0] || canBootstrap) {
    await sql`
      insert into admins (user_id, email, display_name)
      values (${userId}, ${email || "unknown"}, ${displayName})
      on conflict (user_id) do nothing
    `;
    return { userId, email: email || "unknown", displayName };
  }

  throw new ForbiddenError();
}
