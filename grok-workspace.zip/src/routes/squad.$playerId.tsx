import { createFileRoute, Link } from "@tanstack/react-router";
import { EmptyState } from "@/components/brand/empty-state";
import { PublicShell } from "@/components/public/public-shell";
import { SafeImg } from "@/components/brand/safe-img";
import { Button } from "@/components/ui/button";
import { isHttpUrl } from "@/lib/utils";
import { getPlayerPage } from "@/lib/server/public";

export const Route = createFileRoute("/squad/$playerId")({
  loader: ({ params }) => getPlayerPage({ data: { id: params.playerId } }),
  component: PlayerPage,
  head: ({ loaderData }) => ({
    meta: [
      {
        title: loaderData?.player
          ? `${loaderData.player.displayName} — SB THUNDERS`
          : "Player — SB THUNDERS",
      },
    ],
  }),
});

function PlayerPage() {
  const data = Route.useLoaderData();
  const p = data.player;
  if (!p) {
    return (
      <PublicShell settings={data.settings}>
        <div className="mx-auto max-w-3xl px-4 py-24">
          <EmptyState title="Player not found" copy="This profile is unavailable or has been archived." />
        </div>
      </PublicShell>
    );
  }

  const latestRole = data.seasons[0];

  return (
    <PublicShell settings={data.settings}>
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[0.9fr_1.1fr] lg:py-16">
        <div className="relative aspect-[3/4] overflow-hidden bg-navy-3">
          <SafeImg
            src={p.photoUrl}
            alt={p.displayName}
            className="h-full w-full object-cover object-top"
            fallback={
              <div className="flex h-full items-end p-6">
                <span className="font-display text-8xl text-ivory/10">SB</span>
              </div>
            }
          />
        </div>
        <div>
          <p className="text-[11px] uppercase tracking-[0.28em] text-thunder">
            {latestRole?.role ?? "SB Thunders"}
            {latestRole?.jerseyNumber ? `  ·  #${latestRole.jerseyNumber}` : ""}
          </p>
          <h1 className="mt-3 font-display text-6xl leading-none text-ivory sm:text-7xl">{p.displayName}</h1>
          {p.fullName !== p.displayName ? (
            <p className="mt-2 text-sm text-steel">{p.fullName}</p>
          ) : null}
          <dl className="mt-8 grid gap-4 sm:grid-cols-2">
            <div className="panel p-4">
              <dt className="text-[10px] uppercase tracking-[0.18em] text-steel">Batting</dt>
              <dd className="mt-1 text-ivory">{p.battingStyle || "—"}</dd>
            </div>
            <div className="panel p-4">
              <dt className="text-[10px] uppercase tracking-[0.18em] text-steel">Bowling</dt>
              <dd className="mt-1 text-ivory">{p.bowlingStyle || "—"}</dd>
            </div>
          </dl>
          {p.bio ? <p className="mt-6 max-w-xl text-sm leading-relaxed text-steel">{p.bio}</p> : null}

          {data.seasons.length > 0 ? (
            <div className="mt-8">
              <p className="text-[11px] uppercase tracking-[0.18em] text-steel">Seasons</p>
              <ul className="mt-3 space-y-2">
                {data.seasons.map((sp) => (
                  <li key={sp.id} className="flex flex-wrap items-center justify-between gap-2 border-b border-white/5 py-2 text-sm">
                    <span className="text-ivory">{sp.seasonId.replace("season-", "")}</span>
                    <span className="text-steel">
                      {sp.role}
                      {sp.managementTitle ? ` · ${sp.managementTitle}` : ""}
                      {sp.jerseyNumber ? ` · #${sp.jerseyNumber}` : ""}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ) : null}

          {data.appearances.length > 0 ? (
            <div className="mt-8">
              <p className="text-[11px] uppercase tracking-[0.18em] text-steel">Match performances</p>
              <ul className="mt-3 divide-y divide-white/5 border border-white/5">
                {data.appearances.map((a) => (
                  <li key={a.matchId} className="flex justify-between gap-3 px-4 py-3 text-sm">
                    <span className="text-ivory">vs {a.opponent}</span>
                    <span className="tabular text-steel">
                      {a.runs !== null ? `${a.runs} runs` : ""}
                      {a.runs !== null && a.wickets !== null ? " · " : ""}
                      {a.wickets !== null ? `${a.wickets} wkts` : ""}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          ) : (
            <p className="mt-8 text-sm text-steel">Statistics will appear when match performances are recorded.</p>
          )}

          <div className="mt-8 flex flex-wrap gap-3">
            {isHttpUrl(p.cricheroesUrl) ? (
              <Button asChild>
                <a href={p.cricheroesUrl} target="_blank" rel="noreferrer">
                  View on CricHeroes ↗
                </a>
              </Button>
            ) : null}
            <Button asChild variant="outline">
              <Link to="/squad">Back to squad</Link>
            </Button>
          </div>
        </div>
      </div>
    </PublicShell>
  );
}
