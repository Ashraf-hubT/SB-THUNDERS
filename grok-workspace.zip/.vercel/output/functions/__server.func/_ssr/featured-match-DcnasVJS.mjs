import { n as isHttpUrl } from "./utils-4Kkadyjj.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { t as Button } from "./button-CiAG7yUi.mjs";
import { n as StatusPill, t as ResultMark } from "./status-pill-BO5B8Jkq.mjs";
import { t as format } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/featured-match-DcnasVJS.js
var import_jsx_runtime = require_jsx_runtime();
function prettyDate$1(value) {
	if (!value) return "Date TBC";
	try {
		return format(/* @__PURE__ */ new Date(value + "T12:00:00"), "EEE d MMM yyyy");
	} catch {
		return value;
	}
}
function MatchCard({ match }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/matches/$matchId",
		params: { matchId: match.id },
		className: "panel group block p-5 transition-colors hover:border-thunder/50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: match.status }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultMark, { result: match.result })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-[11px] uppercase tracking-[0.2em] text-steel",
				children: "SB Thunders vs"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-1 font-display text-3xl leading-none text-ivory group-hover:text-thunder",
				children: match.opponent || "Opponent TBC"
			}),
			match.competition ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs uppercase tracking-[0.16em] text-thunder/80",
				children: match.competition
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-wrap gap-x-4 gap-y-1 text-sm text-steel",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: prettyDate$1(match.matchDate) }),
					match.matchTime ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: match.matchTime }) : null,
					match.venue ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: match.venue }) : null
				]
			}),
			match.status === "completed" && (match.resultDescription || match.ourScoreText) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm text-ivory",
				children: match.resultDescription || `${match.ourScoreText} — ${match.oppScoreText}`
			}) : null
		]
	});
}
function prettyDate(value) {
	if (!value) return "Date TBC";
	try {
		return format(/* @__PURE__ */ new Date(value + "T12:00:00"), "EEEE d MMMM yyyy");
	} catch {
		return value;
	}
}
function FeaturedMatch({ match, squad }) {
	if (!match) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-7xl px-4 py-16 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.28em] text-thunder",
				children: "Match centre"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 font-display text-5xl text-ivory",
				children: "The next thunder"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-xl text-sm leading-relaxed text-steel",
				children: "When the fixture is locked, it will land here — opponent, venue, and the XI."
			})
		]
	});
	const live = match.status === "live";
	const done = match.status === "completed";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "relative overflow-hidden border-y border-white/5 bg-navy-2",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1.2fr_0.8fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: match.status }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-5 text-[12px] uppercase tracking-[0.24em] text-steel",
					children: live ? "Live now" : done ? "Match result" : "Next fixture"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 flex flex-wrap items-end gap-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-6xl leading-[0.85] text-ivory sm:text-7xl",
						children: "SB THUNDERS"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-[12px] uppercase tracking-[0.3em] text-thunder",
					children: "versus"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-2 font-display text-5xl leading-none text-ivory sm:text-6xl",
					children: match.opponent || "Opponent TBC"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-8 grid gap-3 text-sm text-steel sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-[10px] uppercase tracking-[0.18em] text-steel-2",
							children: "Date"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 text-ivory",
							children: prettyDate(match.matchDate)
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-[10px] uppercase tracking-[0.18em] text-steel-2",
							children: "Time"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 text-ivory",
							children: match.matchTime || "TBC"
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-[10px] uppercase tracking-[0.18em] text-steel-2",
							children: "Venue"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "mt-1 text-ivory",
							children: match.venue || "TBC"
						})] })
					]
				}),
				done ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 border-l-2 border-thunder pl-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl text-ivory",
							children: match.result === "won" ? "SB THUNDERS WON" : match.result === "lost" ? "SB THUNDERS LOST" : match.resultDescription || "Result recorded"
						}),
						(match.ourScoreText || match.oppScoreText) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-steel",
							children: [
								match.ourScoreText,
								match.ourScoreText && match.oppScoreText ? "  ·  " : "",
								match.oppScoreText
							]
						}),
						match.resultDescription ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-ivory",
							children: match.resultDescription
						}) : null,
						match.playerOfMatchName ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-xs uppercase tracking-[0.18em] text-thunder",
							children: ["Player of the match — ", match.playerOfMatchName]
						}) : null
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-wrap gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/matches/$matchId",
							params: { matchId: match.id },
							children: "Match details"
						})
					}), isHttpUrl(match.cricheroesUrl) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "ghost",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: match.cricheroesUrl,
							target: "_blank",
							rel: "noreferrer",
							children: "View on CricHeroes ↗"
						})
					}) : null]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.22em] text-steel",
				children: "Today's squad"
			}), squad.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-sm leading-relaxed text-steel",
				children: "Playing XI will appear here once selected."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-4 divide-y divide-white/5 border border-white/5",
				children: squad.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between gap-3 px-4 py-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/squad/$playerId",
						params: { playerId: m.playerId },
						className: "flex items-center gap-3 text-sm text-ivory hover:text-thunder",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular w-5 text-steel",
							children: String(i + 1).padStart(2, "0")
						}), m.player.displayName]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[10px] uppercase tracking-[0.14em] text-steel",
						children: m.jerseyNumber ? `#${m.jerseyNumber}` : m.role
					})]
				}, m.playerId))
			})] })]
		})
	});
}
//#endregion
export { MatchCard as n, FeaturedMatch as t };
