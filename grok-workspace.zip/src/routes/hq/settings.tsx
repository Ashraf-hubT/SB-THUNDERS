import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState, type ChangeEvent } from "react";

import { toast } from "sonner";
import { HqShell } from "@/components/hq/hq-shell";
import { ImageField } from "@/components/hq/image-field";
import { Button } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/field";
import { addAllowlistEmail, getHqSettings, saveSettings } from "@/lib/server/hq";
import { DEFAULT_SETTINGS } from "@/lib/defaults";

export const Route = createFileRoute("/hq/settings")({ component: SettingsHq });

function SettingsHq() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["hq-settings"], queryFn: () => getHqSettings() });
  const [form, setForm] = useState(DEFAULT_SETTINGS);
  const [email, setEmail] = useState("");

  useEffect(() => {
    if (q.data?.settings) setForm(q.data.settings);
  }, [q.data]);

  const save = useMutation({
    mutationFn: () =>
      saveSettings({
        data: {
          teamName: form.teamName,
          tagline: form.tagline,
          supportingCopy: form.supportingCopy,
          heroLine1: form.heroLine1,
          heroLine2: form.heroLine2,
          quoteLine: form.quoteLine,
          story: form.story,
          origin: form.origin,
          valuesText: form.valuesText,
          philosophy: form.philosophy,
          milestones: form.milestones,
          culture: form.culture,
          email: form.email,
          instagramUrl: form.instagramUrl,
          twitterUrl: form.twitterUrl,
          facebookUrl: form.facebookUrl,
          youtubeUrl: form.youtubeUrl,
          whatsappUrl: form.whatsappUrl,
          cricheroesTeamUrl: form.cricheroesTeamUrl,
          adminName: form.adminName,
          adminRole: form.adminRole,
          adminPhotoUrl: form.adminPhotoUrl,
          adminBio: form.adminBio,
          adminDeepDiveUrl: form.adminDeepDiveUrl,
          logoUrl: form.logoUrl,
          seoTitle: form.seoTitle,
          seoDescription: form.seoDescription,
        },
      }),
    onSuccess: () => toast.success("Settings published"),
    onError: (e: Error) => toast.error(e.message),
  });

  const set = (k: keyof typeof form) => (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm({ ...form, [k]: e.target.value });

  return (
    <HqShell title="Website settings">
      <form
        className="grid gap-4 sm:grid-cols-2"
        onSubmit={(e) => {
          e.preventDefault();
          save.mutate();
        }}
      >
        <Field label="Team name"><Input value={form.teamName} onChange={set("teamName")} /></Field>
        <Field label="Public email"><Input value={form.email} onChange={set("email")} /></Field>
        <Field label="Hero line 1"><Input value={form.heroLine1} onChange={set("heroLine1")} /></Field>
        <Field label="Hero line 2"><Input value={form.heroLine2} onChange={set("heroLine2")} /></Field>
        <Field label="Tagline" className="sm:col-span-2"><Input value={form.tagline} onChange={set("tagline")} /></Field>
        <Field label="Supporting copy" className="sm:col-span-2"><Textarea value={form.supportingCopy} onChange={set("supportingCopy")} /></Field>
        <Field label="Quote" className="sm:col-span-2"><Input value={form.quoteLine} onChange={set("quoteLine")} /></Field>
        <Field label="Origin" className="sm:col-span-2"><Textarea value={form.origin} onChange={set("origin")} /></Field>
        <Field label="Story" className="sm:col-span-2"><Textarea value={form.story} onChange={set("story")} /></Field>
        <Field label="Values" className="sm:col-span-2"><Textarea value={form.valuesText} onChange={set("valuesText")} /></Field>
        <Field label="Philosophy" className="sm:col-span-2"><Textarea value={form.philosophy} onChange={set("philosophy")} /></Field>
        <Field label="Milestones" className="sm:col-span-2"><Textarea value={form.milestones} onChange={set("milestones")} /></Field>
        <Field label="Culture" className="sm:col-span-2"><Textarea value={form.culture} onChange={set("culture")} /></Field>
        <Field label="Instagram"><Input value={form.instagramUrl} onChange={set("instagramUrl")} /></Field>
        <Field label="X / Twitter"><Input value={form.twitterUrl} onChange={set("twitterUrl")} /></Field>
        <Field label="Facebook"><Input value={form.facebookUrl} onChange={set("facebookUrl")} /></Field>
        <Field label="YouTube"><Input value={form.youtubeUrl} onChange={set("youtubeUrl")} /></Field>
        <Field label="CricHeroes team URL" className="sm:col-span-2"><Input value={form.cricheroesTeamUrl} onChange={set("cricheroesTeamUrl")} /></Field>
        <Field label="SEO title"><Input value={form.seoTitle} onChange={set("seoTitle")} /></Field>
        <Field label="SEO description" className="sm:col-span-2"><Textarea value={form.seoDescription} onChange={set("seoDescription")} /></Field>
        <div className="sm:col-span-2">
          <ImageField label="Logo" value={form.logoUrl} onChange={(logoUrl) => setForm({ ...form, logoUrl })} />
        </div>
        <div className="sm:col-span-2">
          <Button type="submit" disabled={save.isPending}>{save.isPending ? "Saving…" : "Publish settings"}</Button>
        </div>
      </form>
      <div className="panel mt-10 p-5">
        <p className="text-[11px] uppercase tracking-[0.16em] text-steel">Administrator allowlist</p>
        <ul className="mt-3 text-sm text-ivory">
          {(q.data?.allowlist ?? []).map((e) => (
            <li key={e}>{e}</li>
          ))}
        </ul>
        <form
          className="mt-4 flex gap-2"
          onSubmit={async (e) => {
            e.preventDefault();
            await addAllowlistEmail({ data: { email } });
            setEmail("");
            toast.success("Email added");
            await qc.invalidateQueries({ queryKey: ["hq-settings"] });
          }}
        >
          <Input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} placeholder="new admin email" />
          <Button type="submit">Add</Button>
        </form>
      </div>
    </HqShell>
  );
}
