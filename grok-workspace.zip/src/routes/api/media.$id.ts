import { createFileRoute } from "@tanstack/react-router";
import { getSql } from "@/lib/db";

export const Route = createFileRoute("/api/media/$id")({
  server: {
    handlers: {
      GET: async ({ params }) => {
        try {
          const id = params.id;
          if (!id || !/^[0-9a-f-]{16,}$/i.test(id)) {
            return new Response("Not found", { status: 404 });
          }
          const sql = await getSql();
          const rows = await sql<{ mime_type: string; data_url: string }>`
            select mime_type, data_url from media where id = ${id}
          `;
          const row = rows[0];
          if (!row) return new Response("Not found", { status: 404 });
          const comma = row.data_url.indexOf(",");
          if (comma < 0) return new Response("Not found", { status: 404 });
          const buf = Buffer.from(row.data_url.slice(comma + 1), "base64");
          return new Response(buf, {
            headers: {
              "Content-Type": row.mime_type || "image/jpeg",
              "Cache-Control": "public, max-age=31536000, immutable",
            },
          });
        } catch {
          return new Response("Not found", { status: 404 });
        }
      },
    },
  },
});
