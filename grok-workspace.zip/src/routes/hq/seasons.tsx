import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { HqShell } from "@/components/hq/hq-shell";
import { Button } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/field";
import { getHqSeasons, saveSeason, setActiveSeason } from "@/lib/server/hq";
import type { Season } from "@/lib/types";

export const Route = createFileRoute("/hq/seasons")({ component: SeasonsPage });

function SeasonsPage() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["hq-seasons"], queryFn: () => getHqSeasons() });
  const [editing, setEditing] = useState<Partial<Season> | null>(null);

  const save = useMutation({
    mutationFn: (data: Parameters<typeof saveSeason>[0]["data"]) => saveSeason({ data }),
    onSuccess: async () => {
      toast.success("Season saved");
      setEditing(null);
      await qc.invalidateQueries();
    },
    onError: (e: Error) => toast.error(e.message),
  });
  const activate = useMutation({
    mutationFn: (id: string) => setActiveSeason({ data: { id } }),
    onSuccess: async () => {
      toast.success("Active season updated");
      await qc.invalidateQueries();
    },
  });

  return (
    <HqShell title="Season manager">
      <p className="max-w-2xl text-sm text-steel">
        The public website always reads the active season. Previous seasons stay archived with their own
        squads, matches, and gallery.
      </p>
      <div className="mt-6">
        <Button type="button" onClick={() => setEditing({ name: "", slug: "", startYear: 2027, endYear: 2028, tagline: "", notes: "", isActive: false, isArchived: false })}>
          New season
        </Button>
      </div>
      <div className="mt-6 space-y-3">
        {(q.data ?? []).map((s) => (
          <div key={s.id} className="panel flex flex-wrap items-center justify-between gap-3 p-4">
            <div>
              <p className="font-display text-2xl text-ivory">{s.name}</p>
              <p className="text-xs uppercase tracking-[0.14em] text-steel">
                {s.isActive ? "Active" : s.isArchived ? "Archived" : "Draft"} · {s.slug}
              </p>
            </div>
            <div className="flex gap-2">
              {!s.isActive ? (
                <Button type="button" size="sm" variant="outline" onClick={() => activate.mutate(s.id)}>
                  Make active
                </Button>
              ) : null}
              <Button type="button" size="sm" variant="ghost" onClick={() => setEditing(s)}>
                Edit
              </Button>
            </div>
          </div>
        ))}
      </div>
      {editing ? (
        <form
          className="panel mt-8 grid gap-4 p-5 sm:grid-cols-2"
          onSubmit={(e) => {
            e.preventDefault();
            if (!editing.name || !editing.slug) return;
            save.mutate({
              id: editing.id,
              name: editing.name,
              slug: editing.slug,
              startYear: Number(editing.startYear),
              endYear: Number(editing.endYear),
              tagline: editing.tagline,
              notes: editing.notes,
              isActive: editing.isActive,
              isArchived: editing.isArchived,
            });
          }}
        >
          <Field label="Name">
            <Input value={editing.name ?? ""} onChange={(e) => setEditing({ ...editing, name: e.target.value })} required />
          </Field>
          <Field label="Slug">
            <Input value={editing.slug ?? ""} onChange={(e) => setEditing({ ...editing, slug: e.target.value })} required />
          </Field>
          <Field label="Start year">
            <Input type="number" value={editing.startYear ?? 2026} onChange={(e) => setEditing({ ...editing, startYear: Number(e.target.value) })} />
          </Field>
          <Field label="End year">
            <Input type="number" value={editing.endYear ?? 2027} onChange={(e) => setEditing({ ...editing, endYear: Number(e.target.value) })} />
          </Field>
          <Field label="Tagline" className="sm:col-span-2">
            <Input value={editing.tagline ?? ""} onChange={(e) => setEditing({ ...editing, tagline: e.target.value })} />
          </Field>
          <Field label="Notes" className="sm:col-span-2">
            <Textarea value={editing.notes ?? ""} onChange={(e) => setEditing({ ...editing, notes: e.target.value })} />
          </Field>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={Boolean(editing.isActive)} onChange={(e) => setEditing({ ...editing, isActive: e.target.checked })} />
            Active season
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={Boolean(editing.isArchived)} onChange={(e) => setEditing({ ...editing, isArchived: e.target.checked })} />
            Archived
          </label>
          <div className="flex gap-2 sm:col-span-2">
            <Button type="submit" disabled={save.isPending}>{save.isPending ? "Saving…" : "Save"}</Button>
            <Button type="button" variant="ghost" onClick={() => setEditing(null)}>Cancel</Button>
          </div>
        </form>
      ) : null}
    </HqShell>
  );
}
