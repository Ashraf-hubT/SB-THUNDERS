import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime, n as useQuery, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as Textarea, n as Input, t as Field } from "./field-Cnn-JkFT.mjs";
import { t as useCurrentUser } from "./use-current-user-DG6UNzh9.mjs";
import { C as saveSettings, g as getHqSettings, n as UserButton } from "./hq-DLvonivC.mjs";
import { t as HqShell } from "./hq-shell-dMuZsJhJ.mjs";
import { t as Button } from "./button-CiAG7yUi.mjs";
import { t as ImageField } from "./image-field-DyYab_pI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/profile-BScZmuvu.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProfileHq() {
	const user = useCurrentUser();
	const q = useQuery({
		queryKey: ["hq-settings"],
		queryFn: () => getHqSettings()
	});
	const [adminName, setAdminName] = (0, import_react.useState)("Ashraf");
	const [adminRole, setAdminRole] = (0, import_react.useState)("Team / Website Administrator");
	const [adminPhotoUrl, setAdminPhotoUrl] = (0, import_react.useState)("/team/ashraf.jpg");
	const [adminBio, setAdminBio] = (0, import_react.useState)("");
	const [adminDeepDiveUrl, setAdminDeepDiveUrl] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		const s = q.data?.settings;
		if (!s) return;
		setAdminName(s.adminName);
		setAdminRole(s.adminRole);
		setAdminPhotoUrl(s.adminPhotoUrl);
		setAdminBio(s.adminBio);
		setAdminDeepDiveUrl(s.adminDeepDiveUrl);
	}, [q.data]);
	const save = useMutation({
		mutationFn: () => {
			const s = q.data?.settings;
			if (!s) throw new Error("Settings not loaded");
			return saveSettings({ data: {
				teamName: s.teamName,
				tagline: s.tagline,
				supportingCopy: s.supportingCopy,
				heroLine1: s.heroLine1,
				heroLine2: s.heroLine2,
				quoteLine: s.quoteLine,
				story: s.story,
				origin: s.origin,
				valuesText: s.valuesText,
				philosophy: s.philosophy,
				milestones: s.milestones,
				culture: s.culture,
				email: s.email,
				instagramUrl: s.instagramUrl,
				twitterUrl: s.twitterUrl,
				facebookUrl: s.facebookUrl,
				youtubeUrl: s.youtubeUrl,
				whatsappUrl: s.whatsappUrl,
				cricheroesTeamUrl: s.cricheroesTeamUrl,
				adminName,
				adminRole,
				adminPhotoUrl,
				adminBio,
				adminDeepDiveUrl,
				logoUrl: s.logoUrl,
				seoTitle: s.seoTitle,
				seoDescription: s.seoDescription
			} });
		},
		onSuccess: () => toast.success("Profile updated"),
		onError: (e) => toast.error(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HqShell, {
		title: "Admin profile",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "panel mb-6 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.16em] text-steel",
					children: "Signed in"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-ivory",
					children: user?.displayName ?? "Administrator"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-steel",
					children: user?.primaryEmail
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-4",
			onSubmit: (e) => {
				e.preventDefault();
				save.mutate();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Public name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: adminName,
						onChange: (e) => setAdminName(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Public role",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: adminRole,
						onChange: (e) => setAdminRole(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageField, {
					label: "Public photo",
					value: adminPhotoUrl,
					onChange: setAdminPhotoUrl
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Bio",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: adminBio,
						onChange: (e) => setAdminBio(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Deep dive URL (optional)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: adminDeepDiveUrl,
						onChange: (e) => setAdminDeepDiveUrl(e.target.value),
						placeholder: "Leave empty until ready"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: save.isPending,
					children: "Save public admin section"
				})
			]
		})]
	});
}
//#endregion
export { ProfileHq as component };
