import { createFileRoute, Link } from "@tanstack/react-router";
import { format } from "date-fns";
import { EmptyState } from "@/components/brand/empty-state";
import { StatusPill } from "@/components/brand/status-pill";
import { PublicShell } from "@/components/public/public-shell";
import { Button } from "@/components/ui/button";
import { isHttpUrl } from "@/lib/utils";
import { getMatchPage } from "@/lib/server/public";

export const Route = createFileRoute("/matches/$matchId")({
  loader: ({ params }) => getMatchPage({ data: { id: params.matchId } }),
  component: MatchPage,
  head: ({ loaderData }) => ({
    meta: [
      {
        title: loaderData?.match
          ? `vs ${loaderData.match.opponent} — SB THUNDERS`
          : "Match — SB THUNDERS",
      },
    ],
  }),
});

function MatchPage() {
  const data = Route.useLoaderData();
  const m = data.match;
  if (!m) {
    return (
      <PublicShell settings={data.settings}>
        <div className="mx-auto max-w-3xl px-4 py-24">
          <EmptyState title="Match not found" copy="This fixture is unpublished or does not exist." />
        </div>
      </PublicShell>
    );
  }
  const dateLabel = m.matchDate
    ? (() => {
        try {
          return format(new Date(m.matchDate + "T12:00:00"), "EEEE d MMMM yyyy");
        } catch {
          return m.matchDate;
        }
      })()
    : "Date TBC";

  return (
    <PublicShell settings={data.settings}>
      <div className="mx-auto max-w-4xl px-4 py-14 sm:px-6">
        <StatusPill status={m.status} />
        <p className="mt-6 text-[12px] uppercase tracking-[0.24em] text-steel">SB Thunders versus</p>
        <h1 className="mt-2 font-display text-6xl leading-none text-ivory sm:text-7xl">{m.opponent}</h1>
        {m.competition ? (
          <p className="mt-3 text-xs uppercase tracking-[0.18em] text-thunder">{m.competition}</p>
        ) : null}
        <dl className="mt-8 grid gap-4 sm:grid-cols-3">
          <div className="panel p-4">
            <dt className="text-[10px] uppercase tracking-[0.16em] text-steel">Date</dt>
            <dd className="mt-1 text-ivory">{dateLabel}</dd>
          </div>
          <div className="panel p-4">
            <dt className="text-[10px] uppercase tracking-[0.16em] text-steel">Time</dt>
            <dd className="mt-1 text-ivory">{m.matchTime || "TBC"}</dd>
          </div>
          <div className="panel p-4">
            <dt className="text-[10px] uppercase tracking-[0.16em] text-steel">Venue</dt>
            <dd className="mt-1 text-ivory">{m.venue || "TBC"}</dd>
          </div>
        </dl>
        {m.status === "completed" ? (
          <div className="mt-8 border-l-2 border-thunder pl-5">
            <p className="font-display text-4xl text-ivory">
              {m.result === "won" ? "SB THUNDERS WON" : m.result === "lost" ? "SB THUNDERS LOST" : "Result"}
            </p>
            <p className="mt-2 text-steel">
              {m.ourScoreText}
              {m.ourScoreText && m.oppScoreText ? "  —  " : ""}
              {m.oppScoreText}
            </p>
            {m.resultDescription ? <p className="mt-2 text-ivory">{m.resultDescription}</p> : null}
            {m.playerOfMatchName ? (
              <p className="mt-4 text-xs uppercase tracking-[0.16em] text-thunder">
                Player of the match — {m.playerOfMatchName}
              </p>
            ) : null}
          </div>
        ) : null}
        {m.notes ? <p className="mt-6 text-sm leading-relaxed text-steel">{m.notes}</p> : null}

        <h2 className="mt-12 font-display text-4xl text-ivory">Match-day squad</h2>
        {data.squad.length === 0 ? (
          <p className="mt-4 text-sm text-steel">Playing XI has not been selected for this match.</p>
        ) : (
          <ol className="mt-4 divide-y divide-white/5 border border-white/5">
            {data.squad.map((row, i) => (
              <li key={row.playerId}>
                <Link
                  to="/squad/$playerId"
                  params={{ playerId: row.playerId }}
                  className="flex items-center justify-between px-4 py-3 text-sm text-ivory hover:text-thunder"
                >
                  <span>
                    <span className="mr-3 tabular text-steel">{String(i + 1).padStart(2, "0")}</span>
                    {row.player.displayName}
                  </span>
                  <span className="text-[10px] uppercase tracking-[0.14em] text-steel">
                    {row.jerseyNumber ? `#${row.jerseyNumber}` : row.role}
                  </span>
                </Link>
              </li>
            ))}
          </ol>
        )}

        <div className="mt-8 flex flex-wrap gap-3">
          {isHttpUrl(m.cricheroesUrl) ? (
            <Button asChild>
              <a href={m.cricheroesUrl} target="_blank" rel="noreferrer">
                View on CricHeroes ↗
              </a>
            </Button>
          ) : null}
          <Button asChild variant="outline">
            <Link to="/matches">All matches</Link>
          </Button>
        </div>
      </div>
    </PublicShell>
  );
}
