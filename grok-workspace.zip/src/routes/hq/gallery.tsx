import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { HqShell } from "@/components/hq/hq-shell";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { GALLERY_CATEGORIES, GALLERY_LABELS } from "@/lib/constants";
import { compressImage } from "@/lib/image";
import { deleteGalleryItem, getHqGallery, saveGalleryItem, saveMedia } from "@/lib/server/hq";

export const Route = createFileRoute("/hq/gallery")({ component: GalleryHq });

function GalleryHq() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["hq-gallery"], queryFn: () => getHqGallery() });
  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("moments");
  const [seasonId, setSeasonId] = useState<string>("");
  const [published, setPublished] = useState(true);
  const [busy, setBusy] = useState(false);

  const del = useMutation({
    mutationFn: (id: string) => deleteGalleryItem({ data: { id } }),
    onSuccess: async () => {
      toast.success("Removed");
      await qc.invalidateQueries();
    },
  });

  async function onFiles(files: FileList | null) {
    if (!files?.length) return;
    setBusy(true);
    try {
      for (const file of Array.from(files)) {
        const dataUrl = await compressImage(file);
        const media = await saveMedia({ data: { dataUrl, alt: title || file.name } });
        await saveGalleryItem({
          data: {
            title,
            category,
            imageUrl: media.url,
            altText: title || "SB Thunders",
            seasonId: seasonId || null,
            published,
          },
        });
      }
      toast.success("Photos uploaded");
      await qc.invalidateQueries();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <HqShell title="Gallery">
      <div className="panel grid gap-4 p-5 sm:grid-cols-2">
        <Field label="Title">
          <Input value={title} onChange={(e) => setTitle(e.target.value)} />
        </Field>
        <Field label="Category">
          <Select value={category} onChange={(e) => setCategory(e.target.value)}>
            {GALLERY_CATEGORIES.map((c) => (
              <option key={c} value={c}>
                {GALLERY_LABELS[c]}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Season">
          <Select value={seasonId} onChange={(e) => setSeasonId(e.target.value)}>
            <option value="">All seasons</option>
            {(q.data?.seasons ?? []).map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </Select>
        </Field>
        <label className="flex items-center gap-2 self-end text-sm">
          <input type="checkbox" checked={published} onChange={(e) => setPublished(e.target.checked)} />
          Publish immediately
        </label>
        <label className="sm:col-span-2">
          <span className="mb-1.5 block text-[11px] uppercase tracking-[0.16em] text-steel">Photos</span>
          <input
            type="file"
            accept="image/*"
            multiple
            disabled={busy}
            onChange={(e) => void onFiles(e.target.files)}
          />
          {busy ? <p className="mt-2 text-sm text-steel">Uploading…</p> : null}
        </label>
      </div>
      <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
        {(q.data?.items ?? []).map((item) => (
          <figure key={item.id} className="panel overflow-hidden">
            <img src={item.imageUrl} alt="" className="aspect-square w-full object-cover" />
            <figcaption className="flex items-center justify-between gap-2 p-2 text-xs text-steel">
              <span>
                {item.title || GALLERY_LABELS[item.category as keyof typeof GALLERY_LABELS] || item.category}
                {item.published ? "" : " · draft"}
              </span>
              <button type="button" className="text-thunder" onClick={() => del.mutate(item.id)}>
                Delete
              </button>
            </figcaption>
          </figure>
        ))}
      </div>
    </HqShell>
  );
}
