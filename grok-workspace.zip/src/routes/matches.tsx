import { createFileRoute } from "@tanstack/react-router";
import { EmptyState } from "@/components/brand/empty-state";
import { MatchCard } from "@/components/brand/match-card";
import { SectionHead } from "@/components/brand/section-head";
import { FeaturedMatch } from "@/components/public/featured-match";
import { PublicShell } from "@/components/public/public-shell";
import { SeasonSwitch } from "@/components/public/season-switch";
import { getMatchesPage } from "@/lib/server/public";
import { seasonSearch } from "@/lib/search";

export const Route = createFileRoute("/matches")({
  validateSearch: seasonSearch,
  loaderDeps: ({ search }) => ({ season: search.season }),
  loader: ({ deps }) => getMatchesPage({ data: { season: deps.season } }),
  component: MatchesPage,
  head: () => ({
    meta: [{ title: "Matches — SB THUNDERS" }],
    links: [{ rel: "canonical", href: "https://sbthunders.com/matches" }],
  }),
});

function MatchesPage() {
  const data = Route.useLoaderData();
  const upcoming = data.matches.filter((m) => m.status === "upcoming" || m.status === "live");
  const completed = data.matches.filter((m) => m.status === "completed");

  return (
    <PublicShell settings={data.settings}>
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHead overline={data.season?.name ?? "Fixtures"} title="Matches" />
          <SeasonSwitch seasons={data.seasons} current={data.season} path="/matches" />
        </div>
      </div>
      <FeaturedMatch match={data.featured ?? data.next} squad={[]} />
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <h3 className="font-display text-4xl text-ivory">Upcoming</h3>
        {upcoming.length === 0 ? (
          <div className="mt-6">
            <EmptyState title="No upcoming fixtures" copy="The next match will be published from HQ when it is locked." />
          </div>
        ) : (
          <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {upcoming.map((m) => (
              <MatchCard key={m.id} match={m} />
            ))}
          </div>
        )}
        <h3 className="mt-16 font-display text-4xl text-ivory">Recent</h3>
        {completed.length === 0 ? (
          <div className="mt-6">
            <EmptyState title="No published results" copy="Completed matches appear after they are reviewed and published." />
          </div>
        ) : (
          <div className="mt-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {completed.map((m) => (
              <MatchCard key={m.id} match={m} />
            ))}
          </div>
        )}
      </div>
    </PublicShell>
  );
}
