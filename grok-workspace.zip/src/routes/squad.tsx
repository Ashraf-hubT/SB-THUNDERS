import { createFileRoute } from "@tanstack/react-router";
import { EmptyState } from "@/components/brand/empty-state";
import { PlayerCard } from "@/components/brand/player-card";
import { SectionHead } from "@/components/brand/section-head";
import { PublicShell } from "@/components/public/public-shell";
import { SeasonSwitch } from "@/components/public/season-switch";
import { getSquadPage } from "@/lib/server/public";
import { seasonSearch } from "@/lib/search";

export const Route = createFileRoute("/squad")({
  validateSearch: seasonSearch,
  loaderDeps: ({ search }) => ({ season: search.season }),
  loader: ({ deps }) => getSquadPage({ data: { season: deps.season } }),
  component: SquadPage,
  head: () => ({
    meta: [{ title: "Squad — SB THUNDERS" }],
    links: [{ rel: "canonical", href: "https://sbthunders.com/squad" }],
  }),
});

function SquadPage() {
  const data = Route.useLoaderData();
  const playing = data.squad.filter((s) => s.role !== "Management");
  const management = data.squad.filter((s) => s.role === "Management" || s.role === "Player + Management");

  return (
    <PublicShell settings={data.settings}>
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHead
            overline={data.season?.name ?? "Squad"}
            title="The Thunders"
            copy="A player can belong to one season and not another. Roles can change. This list is the active published roster for the selected season."
          />
          <SeasonSwitch seasons={data.seasons} current={data.season} path="/squad" />
        </div>
        {data.squad.length === 0 ? (
          <div className="mt-12">
            <EmptyState
              title="No published players"
              copy="The squad for this season has not been entered yet. HQ will add names, roles, and photographs before they appear here."
            />
          </div>
        ) : (
          <>
            <div className="mt-12 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {playing.map((entry) => (
                <PlayerCard key={entry.id} entry={entry} />
              ))}
            </div>
            {management.length > 0 ? (
              <div className="mt-16">
                <h3 className="font-display text-4xl text-ivory">Management</h3>
                <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
                  {management.map((entry) => (
                    <PlayerCard key={`m-${entry.id}`} entry={entry} />
                  ))}
                </div>
              </div>
            ) : null}
          </>
        )}
      </div>
    </PublicShell>
  );
}
