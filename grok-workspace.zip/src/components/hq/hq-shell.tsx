import { Link, useRouterState } from "@tanstack/react-router";
import {
  CalendarDays,
  Camera,
  Gauge,
  Image as ImageIcon,
  LayoutDashboard,
  List,
  Menu,
  Settings,
  Trophy,
  UserRound,
  Users,
  X,
  Zap,
} from "lucide-react";
import { useState, type ReactNode } from "react";
import { UserButton } from "@/lib/auth/gates";
import { HQ_NAV } from "@/lib/constants";
import { cn } from "@/lib/utils";

const ICONS: Record<string, typeof Zap> = {
  layout: LayoutDashboard,
  calendar: CalendarDays,
  users: Users,
  zap: Zap,
  list: List,
  chart: Gauge,
  image: ImageIcon,
  trophy: Trophy,
  settings: Settings,
  user: UserRound,
};

export function HqShell({ children, title }: { children: ReactNode; title: string }) {
  const [open, setOpen] = useState(false);
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  return (
    <div className="min-h-dvh bg-ink text-ivory">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-60 border-r border-white/5 bg-navy-2 lg:flex lg:flex-col">
        <Link to="/hq" className="flex items-center gap-2 border-b border-white/5 px-4 py-4">
          <img src="/team/logo.jpg" alt="" className="h-9 w-9 object-contain" />
          <div>
            <p className="font-display text-xl leading-none">SB THUNDERS</p>
            <p className="text-[10px] uppercase tracking-[0.2em] text-thunder">HQ</p>
          </div>
        </Link>
        <nav className="flex-1 overflow-y-auto px-2 py-3">
          {HQ_NAV.map((item) => {
            const Icon = ICONS[item.icon] ?? LayoutDashboard;
            const active = item.to === "/hq" ? pathname === "/hq" : pathname.startsWith(item.to);
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "mb-0.5 flex min-h-11 items-center gap-3 px-3 text-sm",
                  active ? "bg-thunder text-ivory" : "text-steel hover:bg-navy-3 hover:text-ivory",
                )}
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Link>
            );
          })}
        </nav>
        <div className="border-t border-white/5 p-3">
          <UserButton />
          <Link to="/" className="mt-3 block text-[11px] uppercase tracking-[0.16em] text-steel hover:text-ivory">
            View public site
          </Link>
        </div>
      </aside>

      <header className="sticky top-0 z-20 flex h-14 items-center justify-between border-b border-white/5 bg-ink px-4 lg:hidden">
        <button
          type="button"
          className="inline-flex h-11 w-11 items-center justify-center"
          aria-label="Open menu"
          onClick={() => setOpen(true)}
        >
          <Menu className="h-5 w-5" />
        </button>
        <p className="font-display text-xl">HQ · {title}</p>
        <Camera className="h-5 w-5 opacity-0" />
      </header>

      {open ? (
        <div className="fixed inset-0 z-40 lg:hidden">
          <button type="button" className="absolute inset-0 bg-ink/70" aria-label="Close" onClick={() => setOpen(false)} />
          <div className="relative h-full w-[82%] max-w-xs bg-navy-2 p-3">
            <div className="mb-3 flex items-center justify-between">
              <p className="font-display text-2xl">HQ</p>
              <button type="button" className="h-11 w-11" onClick={() => setOpen(false)} aria-label="Close menu">
                <X className="h-5 w-5" />
              </button>
            </div>
            {HQ_NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setOpen(false)}
                className="flex min-h-12 items-center px-2 text-sm text-ivory"
              >
                {item.label}
              </Link>
            ))}
          </div>
        </div>
      ) : null}

      <div className="lg:pl-60">
        <div className="hidden border-b border-white/5 px-8 py-5 lg:block">
          <p className="text-[11px] uppercase tracking-[0.22em] text-thunder">SB Thunders HQ</p>
          <h1 className="mt-1 font-display text-4xl">{title}</h1>
        </div>
        <div className="px-4 py-6 pb-28 sm:px-6 lg:px-8 lg:pb-12">{children}</div>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-4 border-t border-white/5 bg-ink lg:hidden">
        {[
          { to: "/hq", label: "Home" },
          { to: "/hq/match-day", label: "Match" },
          { to: "/hq/players", label: "Squad" },
          { to: "/hq/matches", label: "List" },
        ].map((item) => (
          <Link
            key={item.to}
            to={item.to}
            className={cn(
              "flex min-h-14 flex-col items-center justify-center text-[10px] uppercase tracking-[0.14em]",
              pathname === item.to || (item.to !== "/hq" && pathname.startsWith(item.to))
                ? "text-thunder"
                : "text-steel",
            )}
          >
            {item.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}
