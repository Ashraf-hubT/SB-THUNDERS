import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/status-pill-BO5B8Jkq.js
var import_jsx_runtime = require_jsx_runtime();
function StatusPill({ status }) {
	const s = status.toLowerCase();
	if (s === "live") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "inline-flex items-center gap-2 rounded-sm bg-thunder px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-ivory",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "live-dot" }), "Live now"]
	});
	if (s === "completed") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "inline-flex rounded-sm border border-ivory/15 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-steel",
		children: "Result"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "inline-flex rounded-sm border border-thunder/40 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-thunder",
		children: "Upcoming"
	});
}
function ResultMark({ result }) {
	if (result === "won") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-[11px] font-semibold uppercase tracking-[0.16em] text-emerald-400",
		children: "Won"
	});
	if (result === "lost") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-[11px] font-semibold uppercase tracking-[0.16em] text-thunder",
		children: "Lost"
	});
	if (!result) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-[11px] font-semibold uppercase tracking-[0.16em] text-steel",
		children: result
	});
}
//#endregion
export { StatusPill as n, ResultMark as t };
