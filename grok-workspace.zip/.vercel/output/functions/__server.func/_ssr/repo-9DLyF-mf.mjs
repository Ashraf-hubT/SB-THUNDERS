import { i as winPct } from "./utils-4Kkadyjj.mjs";
import { i as TSS_SERVER_FUNCTION } from "./ssr.mjs";
import { i as getSql } from "./db-Bi26CoM3.mjs";
import { t as DEFAULT_SETTINGS } from "./defaults-Dcf2xk_0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/repo-9DLyF-mf.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function mapSettings(row) {
	if (!row) return DEFAULT_SETTINGS;
	return {
		id: String(row.id ?? "site"),
		teamName: String(row.team_name ?? DEFAULT_SETTINGS.teamName),
		tagline: String(row.tagline ?? DEFAULT_SETTINGS.tagline),
		supportingCopy: String(row.supporting_copy ?? DEFAULT_SETTINGS.supportingCopy),
		heroLine1: String(row.hero_line_1 ?? DEFAULT_SETTINGS.heroLine1),
		heroLine2: String(row.hero_line_2 ?? DEFAULT_SETTINGS.heroLine2),
		quoteLine: String(row.quote_line ?? ""),
		story: String(row.story ?? ""),
		origin: String(row.origin ?? ""),
		valuesText: String(row.values_text ?? ""),
		philosophy: String(row.philosophy ?? ""),
		milestones: String(row.milestones ?? ""),
		culture: String(row.culture ?? ""),
		email: String(row.email ?? DEFAULT_SETTINGS.email),
		instagramUrl: String(row.instagram_url ?? ""),
		twitterUrl: String(row.twitter_url ?? ""),
		facebookUrl: String(row.facebook_url ?? ""),
		youtubeUrl: String(row.youtube_url ?? ""),
		whatsappUrl: String(row.whatsapp_url ?? ""),
		cricheroesTeamUrl: String(row.cricheroes_team_url ?? ""),
		adminName: String(row.admin_name ?? DEFAULT_SETTINGS.adminName),
		adminRole: String(row.admin_role ?? DEFAULT_SETTINGS.adminRole),
		adminPhotoUrl: String(row.admin_photo_url ?? DEFAULT_SETTINGS.adminPhotoUrl),
		adminBio: String(row.admin_bio ?? ""),
		adminDeepDiveUrl: String(row.admin_deep_dive_url ?? ""),
		logoUrl: String(row.logo_url ?? DEFAULT_SETTINGS.logoUrl),
		seoTitle: String(row.seo_title ?? DEFAULT_SETTINGS.seoTitle),
		seoDescription: String(row.seo_description ?? DEFAULT_SETTINGS.seoDescription)
	};
}
function mapSeason(row) {
	return {
		id: String(row.id),
		name: String(row.name ?? ""),
		slug: String(row.slug ?? ""),
		startYear: Number(row.start_year ?? 0),
		endYear: Number(row.end_year ?? 0),
		isActive: Boolean(row.is_active),
		isArchived: Boolean(row.is_archived),
		tagline: String(row.tagline ?? ""),
		notes: String(row.notes ?? "")
	};
}
function mapPlayer(row, prefix = "") {
	const g = (k) => row[prefix + k];
	return {
		id: String(g("id") ?? row.player_id ?? ""),
		fullName: String(g("full_name") ?? ""),
		displayName: String(g("display_name") ?? ""),
		photoUrl: String(g("photo_url") ?? ""),
		battingStyle: String(g("batting_style") ?? ""),
		bowlingStyle: String(g("bowling_style") ?? ""),
		bio: String(g("bio") ?? ""),
		cricheroesUrl: String(g("cricheroes_url") ?? ""),
		instagramUrl: String(g("instagram_url") ?? ""),
		twitterUrl: String(g("twitter_url") ?? ""),
		status: g("status") === "archived" ? "archived" : "active"
	};
}
function mapSeasonPlayer(row) {
	return {
		id: String(row.id),
		seasonId: String(row.season_id),
		playerId: String(row.player_id),
		role: String(row.role ?? "Batter"),
		managementTitle: String(row.management_title ?? ""),
		jerseyNumber: String(row.jersey_number ?? ""),
		isCaptain: Boolean(row.is_captain),
		isViceCaptain: Boolean(row.is_vice_captain),
		displayOrder: Number(row.display_order ?? 0),
		status: row.status === "archived" ? "archived" : "active",
		player: mapPlayer(row, "p_")
	};
}
function mapMatch(row) {
	return {
		id: String(row.id),
		seasonId: String(row.season_id),
		opponent: String(row.opponent ?? ""),
		venue: String(row.venue ?? ""),
		matchDate: row.match_date ? String(row.match_date) : null,
		matchTime: String(row.match_time ?? ""),
		status: String(row.status ?? "upcoming"),
		isFeatured: Boolean(row.is_featured),
		published: Boolean(row.published),
		ourScoreText: String(row.our_score_text ?? ""),
		oppScoreText: String(row.opp_score_text ?? ""),
		ourRuns: row.our_runs === null || row.our_runs === void 0 ? null : Number(row.our_runs),
		oppRuns: row.opp_runs === null || row.opp_runs === void 0 ? null : Number(row.opp_runs),
		result: String(row.result ?? ""),
		resultDescription: String(row.result_description ?? ""),
		playerOfMatchId: row.player_of_match_id ? String(row.player_of_match_id) : null,
		notes: String(row.notes ?? ""),
		cricheroesUrl: String(row.cricheroes_url ?? ""),
		competition: String(row.competition ?? ""),
		sourceNote: String(row.source_note ?? ""),
		playerOfMatchName: row.pom_name ? String(row.pom_name) : null
	};
}
function mapAchievement(row) {
	return {
		id: String(row.id),
		seasonId: row.season_id ? String(row.season_id) : null,
		matchId: row.match_id ? String(row.match_id) : null,
		title: String(row.title ?? ""),
		year: String(row.year ?? ""),
		result: String(row.result ?? ""),
		description: String(row.description ?? ""),
		imageUrl: String(row.image_url ?? ""),
		competition: String(row.competition ?? ""),
		published: Boolean(row.published),
		displayOrder: Number(row.display_order ?? 0)
	};
}
function mapGallery(row) {
	return {
		id: String(row.id),
		seasonId: row.season_id ? String(row.season_id) : null,
		title: String(row.title ?? ""),
		category: String(row.category ?? "moments"),
		imageUrl: String(row.image_url ?? ""),
		altText: String(row.alt_text ?? ""),
		published: Boolean(row.published),
		displayOrder: Number(row.display_order ?? 0)
	};
}
function computeInsights(matches, runRows, wicketRows, bestScore) {
	const completed = matches.filter((m) => m.status === "completed");
	const played = completed.length;
	const wins = completed.filter((m) => m.result === "won").length;
	const losses = completed.filter((m) => m.result === "lost").length;
	const draws = completed.filter((m) => m.result === "draw" || m.result === "tie").length;
	const runValues = completed.map((m) => m.ourRuns).filter((n) => typeof n === "number" && Number.isFinite(n));
	return {
		played,
		wins,
		losses,
		draws,
		winPct: winPct(wins, played),
		highestScore: runValues.length ? Math.max(...runValues) : null,
		lowestScore: runValues.length ? Math.min(...runValues) : null,
		bestIndividualScore: bestScore,
		topRunScorer: runRows[0] ?? null,
		topWicketTaker: wicketRows[0] ?? null
	};
}
async function fetchSettings() {
	return mapSettings((await (await getSql())`select * from site_settings where id = 'site'`)[0]);
}
async function fetchSeasons() {
	return (await (await getSql())`
    select * from seasons order by start_year desc, name desc
  `).map(mapSeason);
}
async function fetchSeasonBySlugOrActive(slug) {
	const sql = await getSql();
	if (slug) {
		const rows = await sql`select * from seasons where slug = ${slug} limit 1`;
		if (rows[0]) return mapSeason(rows[0]);
	}
	const active = await sql`
    select * from seasons where is_active = true order by start_year desc limit 1
  `;
	return active[0] ? mapSeason(active[0]) : null;
}
async function fetchSquad(seasonId, opts) {
	const mapped = (await (await getSql())`
    select
      sp.*,
      p.id as p_id,
      p.full_name as p_full_name,
      p.display_name as p_display_name,
      p.photo_url as p_photo_url,
      p.batting_style as p_batting_style,
      p.bowling_style as p_bowling_style,
      p.bio as p_bio,
      p.cricheroes_url as p_cricheroes_url,
      p.instagram_url as p_instagram_url,
      p.twitter_url as p_twitter_url,
      p.status as p_status
    from season_players sp
    join players p on p.id = sp.player_id
    where sp.season_id = ${seasonId}
    order by sp.display_order asc, p.display_name asc
  `).map(mapSeasonPlayer);
	if (opts?.includeArchived) return mapped;
	return mapped.filter((sp) => sp.status === "active" && sp.player.status === "active");
}
async function fetchPlayer(id) {
	const rows = await (await getSql())`select * from players where id = ${id}`;
	return rows[0] ? mapPlayer(rows[0]) : null;
}
async function fetchPlayerSeasons(playerId) {
	return (await (await getSql())`
    select
      sp.*,
      p.id as p_id,
      p.full_name as p_full_name,
      p.display_name as p_display_name,
      p.photo_url as p_photo_url,
      p.batting_style as p_batting_style,
      p.bowling_style as p_bowling_style,
      p.bio as p_bio,
      p.cricheroes_url as p_cricheroes_url,
      p.instagram_url as p_instagram_url,
      p.twitter_url as p_twitter_url,
      p.status as p_status
    from season_players sp
    join players p on p.id = sp.player_id
    where sp.player_id = ${playerId}
    order by sp.id
  `).map(mapSeasonPlayer);
}
async function fetchMatches(seasonId, opts) {
	const mapped = (await (await getSql())`
    select m.*, pom.display_name as pom_name
    from matches m
    left join players pom on pom.id = m.player_of_match_id
    where m.season_id = ${seasonId}
    order by m.match_date desc nulls last, m.created_at desc
  `).map(mapMatch);
	if (opts?.publishedOnly) return mapped.filter((m) => m.published);
	return mapped;
}
async function fetchMatch(id) {
	const rows = await (await getSql())`
    select m.*, pom.display_name as pom_name
    from matches m
    left join players pom on pom.id = m.player_of_match_id
    where m.id = ${id}
  `;
	return rows[0] ? mapMatch(rows[0]) : null;
}
async function fetchMatchSquad(matchId) {
	return (await (await getSql())`
    select
      ms.match_id, ms.player_id, ms.is_playing, ms.batting_order,
      p.id as p_id,
      p.full_name as p_full_name,
      p.display_name as p_display_name,
      p.photo_url as p_photo_url,
      p.batting_style as p_batting_style,
      p.bowling_style as p_bowling_style,
      p.bio as p_bio,
      p.cricheroes_url as p_cricheroes_url,
      p.instagram_url as p_instagram_url,
      p.twitter_url as p_twitter_url,
      p.status as p_status,
      sp.role as role,
      sp.jersey_number as jersey_number
    from match_squad ms
    join players p on p.id = ms.player_id
    left join matches m on m.id = ms.match_id
    left join season_players sp on sp.player_id = ms.player_id and sp.season_id = m.season_id
    where ms.match_id = ${matchId} and ms.is_playing = true
    order by ms.batting_order asc, p.display_name asc
  `).map((row) => ({
		playerId: String(row.player_id),
		isPlaying: Boolean(row.is_playing),
		battingOrder: Number(row.batting_order ?? 0),
		role: String(row.role ?? ""),
		jerseyNumber: String(row.jersey_number ?? ""),
		player: mapPlayer(row, "p_")
	}));
}
async function fetchGallery(seasonId, opts) {
	const sql = await getSql();
	let mapped = (seasonId ? await sql`
        select * from gallery_items
        where season_id = ${seasonId} or season_id is null
        order by display_order asc, created_at desc
      ` : await sql`
        select * from gallery_items
        order by display_order asc, created_at desc
      `).map(mapGallery);
	if (opts?.publishedOnly) mapped = mapped.filter((g) => g.published);
	if (opts?.limit) mapped = mapped.slice(0, opts.limit);
	return mapped;
}
async function fetchAchievements(seasonId, opts) {
	const sql = await getSql();
	const mapped = (seasonId ? await sql`
        select * from achievements
        where season_id = ${seasonId} or season_id is null
        order by display_order asc, year desc, created_at desc
      ` : await sql`
        select * from achievements
        order by display_order asc, year desc, created_at desc
      `).map(mapAchievement);
	if (opts?.publishedOnly) return mapped.filter((a) => a.published);
	return mapped;
}
async function fetchInsights(seasonId) {
	const matches = (await fetchMatches(seasonId, { publishedOnly: true })).filter((m) => m.status === "completed");
	const sql = await getSql();
	return computeInsights(matches, await sql`
    select p.display_name as name, sum(s.runs)::int as runs
    from player_match_stats s
    join players p on p.id = s.player_id
    join matches m on m.id = s.match_id
    where m.season_id = ${seasonId} and m.published = true and s.runs is not null
    group by p.display_name
    having sum(s.runs) > 0
    order by sum(s.runs) desc
    limit 5
  `, await sql`
    select p.display_name as name, sum(s.wickets)::int as wickets
    from player_match_stats s
    join players p on p.id = s.player_id
    join matches m on m.id = s.match_id
    where m.season_id = ${seasonId} and m.published = true and s.wickets is not null
    group by p.display_name
    having sum(s.wickets) > 0
    order by sum(s.wickets) desc
    limit 5
  `, (await sql`
    select max(s.runs)::int as best
    from player_match_stats s
    join matches m on m.id = s.match_id
    where m.season_id = ${seasonId} and m.published = true
  `)[0]?.best ?? null);
}
function pickFeaturedMatch(matches) {
	const published = matches.filter((m) => m.published);
	const live = published.find((m) => m.status === "live");
	const flagged = published.find((m) => m.isFeatured);
	const upcoming = published.filter((m) => m.status === "upcoming").slice().sort((a, b) => String(a.matchDate ?? "9999").localeCompare(String(b.matchDate ?? "9999")));
	const completed = published.filter((m) => m.status === "completed").slice().sort((a, b) => String(b.matchDate ?? "").localeCompare(String(a.matchDate ?? "")));
	const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	const todayMatch = published.find((m) => m.matchDate === today);
	return {
		featured: live ?? flagged ?? todayMatch ?? upcoming[0] ?? null,
		next: upcoming[0] ?? null,
		recent: completed[0] ?? null
	};
}
//#endregion
export { fetchMatch as a, fetchPlayer as c, fetchSeasons as d, fetchSettings as f, pickFeaturedMatch as g, mapSeason as h, fetchInsights as i, fetchPlayerSeasons as l, mapPlayer as m, fetchAchievements as n, fetchMatchSquad as o, fetchSquad as p, fetchGallery as r, fetchMatches as s, createServerRpc as t, fetchSeasonBySlugOrActive as u };
