import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { EmptyState } from "@/components/brand/empty-state";
import { MatchCard } from "@/components/brand/match-card";
import { PlayerCard } from "@/components/brand/player-card";
import { SectionHead } from "@/components/brand/section-head";
import { FeaturedMatch } from "@/components/public/featured-match";
import { PublicShell } from "@/components/public/public-shell";
import { SafeImg } from "@/components/brand/safe-img";
import { isHttpUrl } from "@/lib/utils";
import { getHomeData } from "@/lib/server/public";

export const Route = createFileRoute("/")({
  loader: () => getHomeData(),
  component: Home,
  head: () => ({
    meta: [{ title: "SB THUNDERS — Official Team Portfolio" }],
    links: [{ rel: "canonical", href: "https://sbthunders.com/" }],
  }),
});

function Home() {
  const data = Route.useLoaderData();
  const s = data.settings;
  const insightCells = [
    { label: "Matches", value: data.insights.played ? String(data.insights.played) : "—" },
    { label: "Wins", value: data.insights.played ? String(data.insights.wins) : "—" },
    { label: "Losses", value: data.insights.played ? String(data.insights.losses) : "—" },
    { label: "Win %", value: data.insights.winPct === null ? "—" : `${data.insights.winPct}` },
  ];

  return (
    <PublicShell settings={s}>
      <section className="relative min-h-[88dvh] overflow-hidden hero-storm">
        <div className="lightning-veil" />
        <div className="lightning-flash" />
        <div className="relative mx-auto flex min-h-[88dvh] max-w-7xl flex-col justify-end px-4 pb-16 pt-24 sm:px-6 sm:pb-20">
          <div className="stagger-in max-w-4xl">
            <img src={s.logoUrl || "/team/logo.jpg"} alt="SB Thunders" className="h-20 w-20 object-contain sm:h-24 sm:w-24" />
            <p className="mt-8 text-[12px] uppercase tracking-[0.36em] text-thunder">Official team portfolio</p>
            <h1 className="mt-3 font-display leading-[0.8] text-ivory">
              <span className="block text-[22vw] sm:text-[9.5rem]">{s.heroLine1 || "SB"}</span>
              <span className="block text-[14vw] text-thunder sm:text-[7.5rem]">{s.heroLine2 || "THUNDERS"}</span>
            </h1>
            <p className="mt-6 max-w-xl text-lg tracking-[0.12em] text-ivory sm:text-xl">
              {s.tagline}
            </p>
            <p className="mt-4 max-w-xl text-sm leading-relaxed text-steel">{s.supportingCopy}</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button asChild size="lg">
                <Link to="/squad">Meet the squad</Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/matches">Latest match</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      <FeaturedMatch match={data.featuredMatch ?? data.nextMatch} squad={data.todaysSquad} />

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHead overline="The brotherhood" title="Meet the Thunders" copy="The active-season squad. Roles move with the season — players, management, or both." />
          <Button asChild variant="outline">
            <Link to="/squad">Full squad</Link>
          </Button>
        </div>
        {data.squad.length === 0 ? (
          <div className="mt-10">
            <EmptyState
              title="Squad forthcoming"
              copy="The current season list is being assembled in HQ. Names will appear here when published — we will not invent them."
            />
          </div>
        ) : (
          <div className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {data.squad.slice(0, 8).map((entry) => (
              <PlayerCard key={entry.id} entry={entry} />
            ))}
          </div>
        )}
      </section>

      <section className="border-y border-white/5 bg-navy-2">
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
          <SectionHead overline="Numbers that are earned" title="Team insights" copy="Only published, confirmed matches count. Empty cells stay empty until the data is real." />
          <div className="mt-10 grid grid-cols-2 gap-3 lg:grid-cols-4">
            {insightCells.map((c) => (
              <div key={c.label} className="panel p-5">
                <p className="text-[11px] uppercase tracking-[0.18em] text-steel">{c.label}</p>
                <p className="mt-3 font-display text-5xl tabular text-ivory">{c.value}</p>
              </div>
            ))}
          </div>
          <div className="mt-8">
            <Button asChild variant="ghost">
              <Link to="/insights">
                Open insights <ArrowUpRight className="h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHead overline="Thunder moments" title="Gallery" />
          <Button asChild variant="outline">
            <Link to="/gallery">All photos</Link>
          </Button>
        </div>
        {data.gallery.length === 0 ? (
          <div className="mt-10">
            <EmptyState title="Moments incoming" copy="Match-day frames and graphics will hang here after they are uploaded from HQ." />
          </div>
        ) : (
          <div className="mt-10 grid grid-cols-2 gap-3 md:grid-cols-4">
            {data.gallery.map((g) => (
              <SafeImg
                key={g.id}
                src={g.imageUrl}
                alt={g.altText || g.title || "SB Thunders"}
                className="aspect-[4/5] w-full object-cover"
              />
            ))}
          </div>
        )}
      </section>

      <section className="border-y border-white/5 bg-ink">
        <div className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
          <SectionHead overline="Silverware & scars" title="Achievements" />
          {data.achievements.length === 0 ? (
            <div className="mt-10">
              <EmptyState title="The ledger is open" copy="Titles and milestones will be recorded here once confirmed." />
            </div>
          ) : (
            <div className="mt-10 grid gap-4 md:grid-cols-3">
              {data.achievements.slice(0, 3).map((a) => (
                <article key={a.id} className="panel p-6">
                  <p className="text-[11px] uppercase tracking-[0.18em] text-thunder">{a.year || a.competition}</p>
                  <h3 className="mt-3 font-display text-3xl text-ivory">{a.title}</h3>
                  {a.result ? <p className="mt-2 text-sm text-steel">{a.result}</p> : null}
                </article>
              ))}
            </div>
          )}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHead overline="Archive" title="Match history" />
          <Button asChild variant="outline">
            <Link to="/matches">All matches</Link>
          </Button>
        </div>
        {data.recentMatches.length === 0 ? (
          <div className="mt-10">
            <EmptyState title="No published results yet" copy="Completed matches appear here after they are published from HQ." />
          </div>
        ) : (
          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {data.recentMatches.map((m) => (
              <MatchCard key={m.id} match={m} />
            ))}
          </div>
        )}
      </section>

      <section className="relative overflow-hidden border-y border-white/5">
        <div className="hero-storm absolute inset-0 opacity-30" />
        <div className="relative mx-auto max-w-7xl px-4 py-24 sm:px-6">
          <p className="text-[11px] uppercase tracking-[0.28em] text-thunder">Our story</p>
          <h2 className="mt-3 max-w-3xl font-display text-6xl leading-[0.9] text-ivory sm:text-7xl">
            This is more than cricket.
          </h2>
          <p className="mt-6 max-w-2xl text-base leading-relaxed text-steel">
            {s.story ||
              "The origin, values, and milestones of SB THUNDERS will be written here by the team — not invented for the website."}
          </p>
          <div className="mt-8">
            <Button asChild variant="outline">
              <Link to="/about">Read about the Thunders</Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-20 sm:px-6">
        <div className="grid items-center gap-10 lg:grid-cols-[0.9fr_1.1fr]">
          <div className="relative aspect-[4/5] overflow-hidden bg-navy-3 sm:aspect-[3/4]">
            <SafeImg
              src={s.adminPhotoUrl || "/team/ashraf.jpg"}
              alt={s.adminName}
              className="h-full w-full object-cover object-top"
            />
          </div>
          <div>
            <p className="text-[11px] uppercase tracking-[0.28em] text-thunder">The one behind the Thunders</p>
            <h2 className="mt-3 font-display text-6xl text-ivory">{s.adminName}</h2>
            <p className="mt-2 text-sm uppercase tracking-[0.16em] text-steel">{s.adminRole}</p>
            {s.adminBio ? <p className="mt-6 max-w-xl text-sm leading-relaxed text-steel">{s.adminBio}</p> : null}
            <a href={`mailto:${s.email}`} className="mt-6 inline-block text-ivory hover:text-thunder">
              {s.email}
            </a>
            {isHttpUrl(s.adminDeepDiveUrl) ? (
              <p className="mt-6">
                <a
                  href={s.adminDeepDiveUrl}
                  className="text-sm uppercase tracking-[0.16em] text-thunder hover:text-ivory"
                >
                  Deep dive into Admin world → Know more about Admin
                </a>
              </p>
            ) : (
              <p className="mt-6 text-sm text-steel-2">Deep dive into Admin world — link reserved.</p>
            )}
          </div>
        </div>
      </section>
    </PublicShell>
  );
}
