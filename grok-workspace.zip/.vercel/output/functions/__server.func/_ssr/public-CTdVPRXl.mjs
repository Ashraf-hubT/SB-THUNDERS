import { r as createServerFn } from "./ssr.mjs";
import { i as getSql } from "./db-Bi26CoM3.mjs";
import { n as EMPTY_HOME, r as EMPTY_INSIGHTS } from "./defaults-Dcf2xk_0.mjs";
import { a as fetchMatch, c as fetchPlayer, d as fetchSeasons, f as fetchSettings, g as pickFeaturedMatch, h as mapSeason, i as fetchInsights, l as fetchPlayerSeasons, n as fetchAchievements, o as fetchMatchSquad, p as fetchSquad, r as fetchGallery, s as fetchMatches, t as createServerRpc, u as fetchSeasonBySlugOrActive } from "./repo-9DLyF-mf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/public-CTdVPRXl.js
async function safe(fn, fallback) {
	try {
		return await fn();
	} catch (err) {
		console.error("[public]", err);
		return fallback;
	}
}
var getSiteSettings_createServerFn_handler = createServerRpc({
	id: "2fd89eecc2f03d5fb702e845f67dfffa483a618a11c74a30e8a139788e0f59c2",
	name: "getSiteSettings",
	filename: "src/lib/server/public.ts"
}, (opts) => getSiteSettings.__executeServer(opts));
var getSiteSettings = createServerFn({ method: "GET" }).handler(getSiteSettings_createServerFn_handler, async () => safe(() => fetchSettings(), EMPTY_HOME.settings));
var getSeasonsPublic_createServerFn_handler = createServerRpc({
	id: "c1a404d242cf182d4d95db16d7c3ba34225ce1e2ed601cc635ef9f2876b96ddb",
	name: "getSeasonsPublic",
	filename: "src/lib/server/public.ts"
}, (opts) => getSeasonsPublic.__executeServer(opts));
var getSeasonsPublic = createServerFn({ method: "GET" }).handler(getSeasonsPublic_createServerFn_handler, async () => safe(() => fetchSeasons(), []));
var getHomeData_createServerFn_handler = createServerRpc({
	id: "8e516e6c233a5b7ed69769059de3433e6aaa7835b16e18357cec1779bd83c31e",
	name: "getHomeData",
	filename: "src/lib/server/public.ts"
}, (opts) => getHomeData.__executeServer(opts));
var getHomeData = createServerFn({ method: "GET" }).handler(getHomeData_createServerFn_handler, async () => {
	return safe(async () => {
		const settings = await fetchSettings();
		const seasons = await fetchSeasons();
		const activeSeason = seasons.find((s) => s.isActive) ?? seasons[0] ?? null;
		if (!activeSeason) return {
			...EMPTY_HOME,
			settings,
			seasons
		};
		const [squad, matches, gallery, achievements, insights] = await Promise.all([
			fetchSquad(activeSeason.id),
			fetchMatches(activeSeason.id, { publishedOnly: true }),
			fetchGallery(activeSeason.id, {
				publishedOnly: true,
				limit: 8
			}),
			fetchAchievements(activeSeason.id, { publishedOnly: true }),
			fetchInsights(activeSeason.id)
		]);
		const { featured, next, recent } = pickFeaturedMatch(matches);
		const todaysSquad = featured ? await fetchMatchSquad(featured.id) : [];
		const announcements = await (await getSql())`
      select id, title, body, published, pinned, created_at
      from announcements
      where published = true
      order by pinned desc, created_at desc
      limit 3
    `;
		return {
			settings,
			seasons,
			activeSeason,
			featuredMatch: featured,
			nextMatch: next,
			recentMatch: recent,
			todaysSquad,
			squad,
			insights,
			gallery,
			achievements,
			recentMatches: matches.filter((m) => m.status === "completed").slice(0, 6),
			announcements: announcements.map((a) => ({
				id: a.id,
				title: a.title,
				body: a.body,
				published: a.published,
				pinned: a.pinned,
				createdAt: String(a.created_at)
			}))
		};
	}, EMPTY_HOME);
});
var getSquadPage_createServerFn_handler = createServerRpc({
	id: "9c8e5f431450b7c0104fdcd45e47eb114fddcecc1172f78b611195de0584ab2a",
	name: "getSquadPage",
	filename: "src/lib/server/public.ts"
}, (opts) => getSquadPage.__executeServer(opts));
var getSquadPage = createServerFn({ method: "GET" }).validator((data) => data).handler(getSquadPage_createServerFn_handler, async ({ data }) => {
	return safe(async () => {
		const settings = await fetchSettings();
		const seasons = await fetchSeasons();
		const season = await fetchSeasonBySlugOrActive(data.season);
		return {
			settings,
			seasons,
			season,
			squad: season ? await fetchSquad(season.id) : []
		};
	}, {
		settings: EMPTY_HOME.settings,
		seasons: [],
		season: null,
		squad: []
	});
});
var getPlayerPage_createServerFn_handler = createServerRpc({
	id: "08049ab9daac3ed4b5224cf33d8607df4844f9b26d24fc1a5b884095fba30634",
	name: "getPlayerPage",
	filename: "src/lib/server/public.ts"
}, (opts) => getPlayerPage.__executeServer(opts));
var getPlayerPage = createServerFn({ method: "GET" }).validator((data) => data).handler(getPlayerPage_createServerFn_handler, async ({ data }) => {
	return safe(async () => {
		const settings = await fetchSettings();
		const player = await fetchPlayer(data.id);
		if (!player || player.status === "archived") return {
			settings,
			player: null,
			seasons: [],
			appearances: []
		};
		return {
			settings,
			player,
			seasons: await fetchPlayerSeasons(player.id),
			appearances: (await (await getSql())`
        select s.*, m.opponent, m.match_date, m.result, m.published, m.status
        from player_match_stats s
        join matches m on m.id = s.match_id
        where s.player_id = ${player.id} and m.published = true
        order by m.match_date desc nulls last
      `).map((row) => ({
				matchId: String(row.match_id),
				opponent: String(row.opponent ?? ""),
				matchDate: row.match_date ? String(row.match_date) : null,
				result: String(row.result ?? ""),
				runs: row.runs === null || row.runs === void 0 ? null : Number(row.runs),
				wickets: row.wickets === null || row.wickets === void 0 ? null : Number(row.wickets)
			}))
		};
	}, {
		settings: EMPTY_HOME.settings,
		player: null,
		seasons: [],
		appearances: []
	});
});
var getMatchesPage_createServerFn_handler = createServerRpc({
	id: "c6d9fddd9077d4661bfc8ed37bc5a74db9bd4eca52552725bc205e3245bcf63f",
	name: "getMatchesPage",
	filename: "src/lib/server/public.ts"
}, (opts) => getMatchesPage.__executeServer(opts));
var getMatchesPage = createServerFn({ method: "GET" }).validator((data) => data).handler(getMatchesPage_createServerFn_handler, async ({ data }) => {
	return safe(async () => {
		const settings = await fetchSettings();
		const seasons = await fetchSeasons();
		const season = await fetchSeasonBySlugOrActive(data.season);
		const matches = season ? await fetchMatches(season.id, { publishedOnly: true }) : [];
		const { featured, next, recent } = pickFeaturedMatch(matches);
		return {
			settings,
			seasons,
			season,
			matches,
			featured,
			next,
			recent
		};
	}, {
		settings: EMPTY_HOME.settings,
		seasons: [],
		season: null,
		matches: [],
		featured: null,
		next: null,
		recent: null
	});
});
var getMatchPage_createServerFn_handler = createServerRpc({
	id: "7ede41b85ed74030e5c63088fb31e0a83211ae96683191c36250848cc8d50734",
	name: "getMatchPage",
	filename: "src/lib/server/public.ts"
}, (opts) => getMatchPage.__executeServer(opts));
var getMatchPage = createServerFn({ method: "GET" }).validator((data) => data).handler(getMatchPage_createServerFn_handler, async ({ data }) => {
	return safe(async () => {
		const settings = await fetchSettings();
		const match = await fetchMatch(data.id);
		if (!match || !match.published) return {
			settings,
			match: null,
			squad: [],
			season: null
		};
		const squad = await fetchMatchSquad(match.id);
		const seasonRows = await (await getSql())`select * from seasons where id = ${match.seasonId}`;
		return {
			settings,
			match,
			squad,
			season: seasonRows[0] ? mapSeason(seasonRows[0]) : null
		};
	}, {
		settings: EMPTY_HOME.settings,
		match: null,
		squad: [],
		season: null
	});
});
var getInsightsPage_createServerFn_handler = createServerRpc({
	id: "9ca3ef9aa8398875c083fe295a833bb7ec3b3c6b8549a76d7d9801ce9bcd8b8b",
	name: "getInsightsPage",
	filename: "src/lib/server/public.ts"
}, (opts) => getInsightsPage.__executeServer(opts));
var getInsightsPage = createServerFn({ method: "GET" }).validator((data) => data).handler(getInsightsPage_createServerFn_handler, async ({ data }) => {
	return safe(async () => {
		const settings = await fetchSettings();
		const seasons = await fetchSeasons();
		const season = await fetchSeasonBySlugOrActive(data.season);
		return {
			settings,
			seasons,
			season,
			insights: season ? await fetchInsights(season.id) : EMPTY_INSIGHTS,
			matches: season ? await fetchMatches(season.id, { publishedOnly: true }) : []
		};
	}, {
		settings: EMPTY_HOME.settings,
		seasons: [],
		season: null,
		insights: EMPTY_INSIGHTS,
		matches: []
	});
});
var getGalleryPage_createServerFn_handler = createServerRpc({
	id: "c9b9c635a5dc433cbcd3f852aeb1fa6bc0cc972fb4688f3e7cb841dd60a372e9",
	name: "getGalleryPage",
	filename: "src/lib/server/public.ts"
}, (opts) => getGalleryPage.__executeServer(opts));
var getGalleryPage = createServerFn({ method: "GET" }).validator((data) => data).handler(getGalleryPage_createServerFn_handler, async ({ data }) => {
	return safe(async () => {
		const settings = await fetchSettings();
		const seasons = await fetchSeasons();
		const season = await fetchSeasonBySlugOrActive(data.season);
		return {
			settings,
			seasons,
			season,
			items: await fetchGallery(season?.id ?? null, { publishedOnly: true })
		};
	}, {
		settings: EMPTY_HOME.settings,
		seasons: [],
		season: null,
		items: []
	});
});
var getAchievementsPage_createServerFn_handler = createServerRpc({
	id: "b2671cff0385584045fce9a67498b1d2dfadcb805352f2066f36b82acf8a6f55",
	name: "getAchievementsPage",
	filename: "src/lib/server/public.ts"
}, (opts) => getAchievementsPage.__executeServer(opts));
var getAchievementsPage = createServerFn({ method: "GET" }).validator((data) => data).handler(getAchievementsPage_createServerFn_handler, async ({ data }) => {
	return safe(async () => {
		const settings = await fetchSettings();
		const seasons = await fetchSeasons();
		const season = await fetchSeasonBySlugOrActive(data.season);
		return {
			settings,
			seasons,
			season,
			items: await fetchAchievements(season?.id ?? null, { publishedOnly: true })
		};
	}, {
		settings: EMPTY_HOME.settings,
		seasons: [],
		season: null,
		items: []
	});
});
var getAboutPage_createServerFn_handler = createServerRpc({
	id: "9ae72003f95e5d7507b0c58bbd9279c3e67dc59ddd193f38f3d10b9be2c08517",
	name: "getAboutPage",
	filename: "src/lib/server/public.ts"
}, (opts) => getAboutPage.__executeServer(opts));
var getAboutPage = createServerFn({ method: "GET" }).handler(getAboutPage_createServerFn_handler, async () => safe(async () => {
	return { settings: await fetchSettings() };
}, { settings: EMPTY_HOME.settings }));
//#endregion
export { getAboutPage_createServerFn_handler, getAchievementsPage_createServerFn_handler, getGalleryPage_createServerFn_handler, getHomeData_createServerFn_handler, getInsightsPage_createServerFn_handler, getMatchPage_createServerFn_handler, getMatchesPage_createServerFn_handler, getPlayerPage_createServerFn_handler, getSeasonsPublic_createServerFn_handler, getSiteSettings_createServerFn_handler, getSquadPage_createServerFn_handler };
