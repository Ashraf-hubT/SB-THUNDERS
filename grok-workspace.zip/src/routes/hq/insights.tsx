import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { HqShell } from "@/components/hq/hq-shell";
import { Select } from "@/components/ui/field";
import { getHqInsights } from "@/lib/server/hq";

export const Route = createFileRoute("/hq/insights")({ component: InsightsHq });

function InsightsHq() {
  const [seasonId, setSeasonId] = useState("");
  const q = useQuery({
    queryKey: ["hq-insights", seasonId],
    queryFn: () => getHqInsights({ data: { seasonId: seasonId || undefined } }),
  });
  const i = q.data?.insights;

  return (
    <HqShell title="Team insights">
      <Select
        className="max-w-xs"
        value={q.data?.season?.id ?? seasonId}
        onChange={(e) => setSeasonId(e.target.value)}
      >
        {(q.data?.seasons ?? []).map((s) => (
          <option key={s.id} value={s.id}>
            {s.name}
          </option>
        ))}
      </Select>
      <p className="mt-4 max-w-xl text-sm text-steel">
        These numbers are computed from published completed matches only. Draft historical records do not count
        until you publish them.
      </p>
      <div className="mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Cell label="Played" value={i?.played ? String(i.played) : "—"} />
        <Cell label="Wins" value={i?.played ? String(i.wins) : "—"} />
        <Cell label="Losses" value={i?.played ? String(i.losses) : "—"} />
        <Cell label="Win %" value={i?.winPct === null || i?.winPct === undefined ? "—" : `${i.winPct}%`} />
      </div>
      <p className="mt-8 text-sm text-steel">
        {(q.data?.matches ?? []).filter((m) => !m.published).length} unpublished matches in this season.
      </p>
    </HqShell>
  );
}

function Cell({ label, value }: { label: string; value: string }) {
  return (
    <div className="panel p-4">
      <p className="text-[11px] uppercase tracking-[0.16em] text-steel">{label}</p>
      <p className="mt-2 font-display text-4xl text-ivory">{value}</p>
    </div>
  );
}
