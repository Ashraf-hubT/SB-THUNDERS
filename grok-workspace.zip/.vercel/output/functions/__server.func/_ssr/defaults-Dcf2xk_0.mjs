//#region node_modules/.nitro/vite/services/ssr/assets/defaults-Dcf2xk_0.js
var DEFAULT_SETTINGS = {
	id: "site",
	teamName: "SB THUNDERS",
	tagline: "MORE THAN A TEAM. ONE THUNDER.",
	supportingCopy: "Built on cricket. Driven by brotherhood. Powered by the fight to come back stronger.",
	heroLine1: "SB",
	heroLine2: "THUNDERS",
	quoteLine: "",
	story: "",
	origin: "",
	valuesText: "",
	philosophy: "",
	milestones: "",
	culture: "",
	email: "sbthunders@gmail.com",
	instagramUrl: "",
	twitterUrl: "",
	facebookUrl: "",
	youtubeUrl: "",
	whatsappUrl: "",
	cricheroesTeamUrl: "",
	adminName: "Ashraf",
	adminRole: "Team / Website Administrator",
	adminPhotoUrl: "/team/ashraf.jpg",
	adminBio: "",
	adminDeepDiveUrl: "",
	logoUrl: "/team/logo.jpg",
	seoTitle: "SB THUNDERS — Official Team Portfolio",
	seoDescription: "Official home of SB THUNDERS. More than a team. One thunder."
};
var EMPTY_INSIGHTS = {
	played: 0,
	wins: 0,
	losses: 0,
	draws: 0,
	winPct: null,
	highestScore: null,
	lowestScore: null,
	bestIndividualScore: null,
	topRunScorer: null,
	topWicketTaker: null
};
var EMPTY_HOME = {
	settings: DEFAULT_SETTINGS,
	seasons: [],
	activeSeason: null,
	featuredMatch: null,
	nextMatch: null,
	recentMatch: null,
	todaysSquad: [],
	squad: [],
	insights: EMPTY_INSIGHTS,
	gallery: [],
	achievements: [],
	recentMatches: [],
	announcements: []
};
//#endregion
export { EMPTY_HOME as n, EMPTY_INSIGHTS as r, DEFAULT_SETTINGS as t };
