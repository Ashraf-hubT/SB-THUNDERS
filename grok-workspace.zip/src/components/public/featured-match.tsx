import { Link } from "@tanstack/react-router";
import { format } from "date-fns";
import type { Match, MatchSquadMember } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { StatusPill } from "@/components/brand/status-pill";
import { isHttpUrl } from "@/lib/utils";

function prettyDate(value: string | null) {
  if (!value) return "Date TBC";
  try {
    return format(new Date(value + "T12:00:00"), "EEEE d MMMM yyyy");
  } catch {
    return value;
  }
}

export function FeaturedMatch({
  match,
  squad,
}: {
  match: Match | null;
  squad: MatchSquadMember[];
}) {
  if (!match) {
    return (
      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6">
        <p className="text-[11px] uppercase tracking-[0.28em] text-thunder">Match centre</p>
        <h2 className="mt-2 font-display text-5xl text-ivory">The next thunder</h2>
        <p className="mt-4 max-w-xl text-sm leading-relaxed text-steel">
          When the fixture is locked, it will land here — opponent, venue, and the XI.
        </p>
      </section>
    );
  }

  const live = match.status === "live";
  const done = match.status === "completed";

  return (
    <section className="relative overflow-hidden border-y border-white/5 bg-navy-2">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1.2fr_0.8fr]">
        <div>
          <StatusPill status={match.status} />
          <p className="mt-5 text-[12px] uppercase tracking-[0.24em] text-steel">
            {live ? "Live now" : done ? "Match result" : "Next fixture"}
          </p>
          <div className="mt-4 flex flex-wrap items-end gap-4">
            <h2 className="font-display text-6xl leading-[0.85] text-ivory sm:text-7xl">SB THUNDERS</h2>
          </div>
          <p className="mt-3 text-[12px] uppercase tracking-[0.3em] text-thunder">versus</p>
          <h3 className="mt-2 font-display text-5xl leading-none text-ivory sm:text-6xl">
            {match.opponent || "Opponent TBC"}
          </h3>
          <dl className="mt-8 grid gap-3 text-sm text-steel sm:grid-cols-3">
            <div>
              <dt className="text-[10px] uppercase tracking-[0.18em] text-steel-2">Date</dt>
              <dd className="mt-1 text-ivory">{prettyDate(match.matchDate)}</dd>
            </div>
            <div>
              <dt className="text-[10px] uppercase tracking-[0.18em] text-steel-2">Time</dt>
              <dd className="mt-1 text-ivory">{match.matchTime || "TBC"}</dd>
            </div>
            <div>
              <dt className="text-[10px] uppercase tracking-[0.18em] text-steel-2">Venue</dt>
              <dd className="mt-1 text-ivory">{match.venue || "TBC"}</dd>
            </div>
          </dl>
          {done ? (
            <div className="mt-8 border-l-2 border-thunder pl-4">
              <p className="font-display text-3xl text-ivory">
                {match.result === "won"
                  ? "SB THUNDERS WON"
                  : match.result === "lost"
                    ? "SB THUNDERS LOST"
                    : match.resultDescription || "Result recorded"}
              </p>
              {(match.ourScoreText || match.oppScoreText) && (
                <p className="mt-2 text-sm text-steel">
                  {match.ourScoreText}
                  {match.ourScoreText && match.oppScoreText ? "  ·  " : ""}
                  {match.oppScoreText}
                </p>
              )}
              {match.resultDescription ? (
                <p className="mt-1 text-sm text-ivory">{match.resultDescription}</p>
              ) : null}
              {match.playerOfMatchName ? (
                <p className="mt-3 text-xs uppercase tracking-[0.18em] text-thunder">
                  Player of the match — {match.playerOfMatchName}
                </p>
              ) : null}
            </div>
          ) : null}
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild variant="outline">
              <Link to="/matches/$matchId" params={{ matchId: match.id }}>
                Match details
              </Link>
            </Button>
            {isHttpUrl(match.cricheroesUrl) ? (
              <Button asChild variant="ghost">
                <a href={match.cricheroesUrl} target="_blank" rel="noreferrer">
                  View on CricHeroes ↗
                </a>
              </Button>
            ) : null}
          </div>
        </div>
        <div>
          <p className="text-[11px] uppercase tracking-[0.22em] text-steel">Today's squad</p>
          {squad.length === 0 ? (
            <p className="mt-4 text-sm leading-relaxed text-steel">
              Playing XI will appear here once selected.
            </p>
          ) : (
            <ol className="mt-4 divide-y divide-white/5 border border-white/5">
              {squad.map((m, i) => (
                <li key={m.playerId} className="flex items-center justify-between gap-3 px-4 py-3">
                  <Link
                    to="/squad/$playerId"
                    params={{ playerId: m.playerId }}
                    className="flex items-center gap-3 text-sm text-ivory hover:text-thunder"
                  >
                    <span className="tabular w-5 text-steel">{String(i + 1).padStart(2, "0")}</span>
                    {m.player.displayName}
                  </Link>
                  <span className="text-[10px] uppercase tracking-[0.14em] text-steel">
                    {m.jerseyNumber ? `#${m.jerseyNumber}` : m.role}
                  </span>
                </li>
              ))}
            </ol>
          )}
        </div>
      </div>
    </section>
  );
}
