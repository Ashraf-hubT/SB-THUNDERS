import { x as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { r as Select } from "./field-Cnn-JkFT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/season-switch-BULz71yR.js
var import_jsx_runtime = require_jsx_runtime();
function SeasonSwitch({ seasons, current, path }) {
	const router = useRouter();
	if (seasons.length < 2) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-[11px] uppercase tracking-[0.18em] text-steel",
			children: "Season"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
			"aria-label": "Select season",
			value: current?.slug ?? "",
			className: "h-10 w-auto min-w-40",
			onChange: (e) => {
				const slug = e.target.value;
				router.history.push(slug ? `${path}?season=${encodeURIComponent(slug)}` : path);
			},
			children: seasons.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
				value: s.slug,
				children: [s.name, s.isActive ? " · Active" : ""]
			}, s.id))
		})]
	});
}
//#endregion
export { SeasonSwitch as t };
