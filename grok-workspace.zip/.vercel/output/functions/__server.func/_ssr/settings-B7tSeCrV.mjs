import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as Textarea, n as Input, t as Field } from "./field-Cnn-JkFT.mjs";
import { C as saveSettings, g as getHqSettings, r as addAllowlistEmail } from "./hq-DLvonivC.mjs";
import { t as HqShell } from "./hq-shell-dMuZsJhJ.mjs";
import { t as Button } from "./button-CiAG7yUi.mjs";
import { t as ImageField } from "./image-field-DyYab_pI.mjs";
import { t as DEFAULT_SETTINGS } from "./defaults-Dcf2xk_0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-B7tSeCrV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SettingsHq() {
	const qc = useQueryClient();
	const q = useQuery({
		queryKey: ["hq-settings"],
		queryFn: () => getHqSettings()
	});
	const [form, setForm] = (0, import_react.useState)(DEFAULT_SETTINGS);
	const [email, setEmail] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (q.data?.settings) setForm(q.data.settings);
	}, [q.data]);
	const save = useMutation({
		mutationFn: () => saveSettings({ data: {
			teamName: form.teamName,
			tagline: form.tagline,
			supportingCopy: form.supportingCopy,
			heroLine1: form.heroLine1,
			heroLine2: form.heroLine2,
			quoteLine: form.quoteLine,
			story: form.story,
			origin: form.origin,
			valuesText: form.valuesText,
			philosophy: form.philosophy,
			milestones: form.milestones,
			culture: form.culture,
			email: form.email,
			instagramUrl: form.instagramUrl,
			twitterUrl: form.twitterUrl,
			facebookUrl: form.facebookUrl,
			youtubeUrl: form.youtubeUrl,
			whatsappUrl: form.whatsappUrl,
			cricheroesTeamUrl: form.cricheroesTeamUrl,
			adminName: form.adminName,
			adminRole: form.adminRole,
			adminPhotoUrl: form.adminPhotoUrl,
			adminBio: form.adminBio,
			adminDeepDiveUrl: form.adminDeepDiveUrl,
			logoUrl: form.logoUrl,
			seoTitle: form.seoTitle,
			seoDescription: form.seoDescription
		} }),
		onSuccess: () => toast.success("Settings published"),
		onError: (e) => toast.error(e.message)
	});
	const set = (k) => (e) => setForm({
		...form,
		[k]: e.target.value
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HqShell, {
		title: "Website settings",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "grid gap-4 sm:grid-cols-2",
			onSubmit: (e) => {
				e.preventDefault();
				save.mutate();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Team name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.teamName,
						onChange: set("teamName")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Public email",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.email,
						onChange: set("email")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Hero line 1",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.heroLine1,
						onChange: set("heroLine1")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Hero line 2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.heroLine2,
						onChange: set("heroLine2")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Tagline",
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.tagline,
						onChange: set("tagline")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Supporting copy",
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: form.supportingCopy,
						onChange: set("supportingCopy")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Quote",
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.quoteLine,
						onChange: set("quoteLine")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Origin",
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: form.origin,
						onChange: set("origin")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Story",
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: form.story,
						onChange: set("story")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Values",
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: form.valuesText,
						onChange: set("valuesText")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Philosophy",
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: form.philosophy,
						onChange: set("philosophy")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Milestones",
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: form.milestones,
						onChange: set("milestones")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Culture",
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: form.culture,
						onChange: set("culture")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Instagram",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.instagramUrl,
						onChange: set("instagramUrl")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "X / Twitter",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.twitterUrl,
						onChange: set("twitterUrl")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Facebook",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.facebookUrl,
						onChange: set("facebookUrl")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "YouTube",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.youtubeUrl,
						onChange: set("youtubeUrl")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "CricHeroes team URL",
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.cricheroesTeamUrl,
						onChange: set("cricheroesTeamUrl")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "SEO title",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: form.seoTitle,
						onChange: set("seoTitle")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "SEO description",
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: form.seoDescription,
						onChange: set("seoDescription")
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageField, {
						label: "Logo",
						value: form.logoUrl,
						onChange: (logoUrl) => setForm({
							...form,
							logoUrl
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: save.isPending,
						children: save.isPending ? "Saving…" : "Publish settings"
					})
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "panel mt-10 p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.16em] text-steel",
					children: "Administrator allowlist"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 text-sm text-ivory",
					children: (q.data?.allowlist ?? []).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: e }, e))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-4 flex gap-2",
					onSubmit: async (e) => {
						e.preventDefault();
						await addAllowlistEmail({ data: { email } });
						setEmail("");
						toast.success("Email added");
						await qc.invalidateQueries({ queryKey: ["hq-settings"] });
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "email",
						required: true,
						value: email,
						onChange: (e) => setEmail(e.target.value),
						placeholder: "new admin email"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Add"
					})]
				})
			]
		})]
	});
}
//#endregion
export { SettingsHq as component };
