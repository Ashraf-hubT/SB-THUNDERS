import { createRouter } from "@tanstack/react-router";
import { AppErrorComponent } from "@/lib/error-component";
import { routeTree } from "./routeTree.gen";

function NotFound() {
  return (
    <main className="grid min-h-dvh place-items-center bg-navy px-6 text-center text-ivory">
      <div>
        <p className="text-[11px] uppercase tracking-[0.28em] text-thunder">404</p>
        <h1 className="mt-3 font-display text-6xl">Lost in the storm</h1>
        <p className="mt-3 text-sm text-steel">That page is not on the SB THUNDERS site.</p>
        <a href="/" className="mt-8 inline-block text-xs uppercase tracking-[0.18em] text-ivory hover:text-thunder">
          Return home
        </a>
      </div>
    </main>
  );
}

export function getRouter() {
  return createRouter({
    routeTree,
    defaultErrorComponent: AppErrorComponent,
    defaultNotFoundComponent: NotFound,
    defaultPreload: "intent",
    scrollRestoration: true,
  });
}
