import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { b as saveMedia } from "./hq-DLvonivC.mjs";
import { t as Button } from "./button-CiAG7yUi.mjs";
import { t as compressImage } from "./image-BpjZNsak.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/image-field-DyYab_pI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ImageField({ label, value, onChange }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function onFile(file) {
		if (!file) return;
		setBusy(true);
		try {
			const dataUrl = await compressImage(file);
			onChange((await saveMedia({ data: {
				dataUrl,
				alt: label
			} })).url);
			toast.success("Photo saved");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Upload failed");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mb-1.5 text-[11px] font-medium uppercase tracking-[0.16em] text-steel",
			children: label
		}),
		value ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: value,
			alt: "",
			className: "mb-3 h-32 w-32 object-cover"
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
			className: "inline-flex",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				type: "file",
				accept: "image/jpeg,image/png,image/webp,image/gif",
				className: "sr-only",
				onChange: (e) => void onFile(e.target.files?.[0])
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				type: "button",
				variant: "outline",
				size: "sm",
				disabled: busy,
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: busy ? "Uploading…" : value ? "Replace photo" : "Upload photo" })
			})]
		})
	] });
}
//#endregion
export { ImageField as t };
