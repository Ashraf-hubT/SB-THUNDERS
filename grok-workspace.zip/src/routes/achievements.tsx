import { createFileRoute } from "@tanstack/react-router";
import { EmptyState } from "@/components/brand/empty-state";
import { SectionHead } from "@/components/brand/section-head";
import { PublicShell } from "@/components/public/public-shell";
import { SeasonSwitch } from "@/components/public/season-switch";
import { getAchievementsPage } from "@/lib/server/public";
import { seasonSearch } from "@/lib/search";

export const Route = createFileRoute("/achievements")({
  validateSearch: seasonSearch,
  loaderDeps: ({ search }) => ({ season: search.season }),
  loader: ({ deps }) => getAchievementsPage({ data: { season: deps.season } }),
  component: AchievementsPage,
  head: () => ({
    meta: [{ title: "Achievements — SB THUNDERS" }],
    links: [{ rel: "canonical", href: "https://sbthunders.com/achievements" }],
  }),
});

function AchievementsPage() {
  const data = Route.useLoaderData();
  return (
    <PublicShell settings={data.settings}>
      <div className="mx-auto max-w-5xl px-4 py-14 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHead overline="The ledger" title="Achievements" copy="Confirmed titles, runs, and scars. Nothing here is decorative." />
          <SeasonSwitch seasons={data.seasons} current={data.season} path="/achievements" />
        </div>
        {data.items.length === 0 ? (
          <div className="mt-12">
            <EmptyState title="No achievements published" copy="When a result is worth keeping, it will be added from HQ." />
          </div>
        ) : (
          <ol className="mt-12 space-y-0">
            {data.items.map((a, idx) => (
              <li key={a.id} className="grid gap-6 border-t border-white/10 py-10 md:grid-cols-[140px_1fr]">
                <p className="text-sm uppercase tracking-[0.18em] text-thunder">{a.year || `0${idx + 1}`}</p>
                <div>
                  {a.competition ? (
                    <p className="text-[11px] uppercase tracking-[0.18em] text-steel">{a.competition}</p>
                  ) : null}
                  <h3 className="mt-1 font-display text-4xl text-ivory">{a.title}</h3>
                  {a.result ? <p className="mt-2 text-ivory">{a.result}</p> : null}
                  {a.description ? <p className="mt-3 max-w-2xl text-sm leading-relaxed text-steel">{a.description}</p> : null}
                </div>
              </li>
            ))}
          </ol>
        )}
      </div>
    </PublicShell>
  );
}
