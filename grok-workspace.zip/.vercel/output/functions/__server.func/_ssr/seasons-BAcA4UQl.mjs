import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as Textarea, n as Input, t as Field } from "./field-Cnn-JkFT.mjs";
import { S as saveSeason, h as getHqSeasons, w as setActiveSeason } from "./hq-DLvonivC.mjs";
import { t as HqShell } from "./hq-shell-dMuZsJhJ.mjs";
import { t as Button } from "./button-CiAG7yUi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/seasons-BAcA4UQl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SeasonsPage() {
	const qc = useQueryClient();
	const q = useQuery({
		queryKey: ["hq-seasons"],
		queryFn: () => getHqSeasons()
	});
	const [editing, setEditing] = (0, import_react.useState)(null);
	const save = useMutation({
		mutationFn: (data) => saveSeason({ data }),
		onSuccess: async () => {
			toast.success("Season saved");
			setEditing(null);
			await qc.invalidateQueries();
		},
		onError: (e) => toast.error(e.message)
	});
	const activate = useMutation({
		mutationFn: (id) => setActiveSeason({ data: { id } }),
		onSuccess: async () => {
			toast.success("Active season updated");
			await qc.invalidateQueries();
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HqShell, {
		title: "Season manager",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-2xl text-sm text-steel",
				children: "The public website always reads the active season. Previous seasons stay archived with their own squads, matches, and gallery."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: () => setEditing({
						name: "",
						slug: "",
						startYear: 2027,
						endYear: 2028,
						tagline: "",
						notes: "",
						isActive: false,
						isArchived: false
					}),
					children: "New season"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 space-y-3",
				children: (q.data ?? []).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "panel flex flex-wrap items-center justify-between gap-3 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl text-ivory",
						children: s.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs uppercase tracking-[0.14em] text-steel",
						children: [
							s.isActive ? "Active" : s.isArchived ? "Archived" : "Draft",
							" · ",
							s.slug
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [!s.isActive ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							size: "sm",
							variant: "outline",
							onClick: () => activate.mutate(s.id),
							children: "Make active"
						}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							size: "sm",
							variant: "ghost",
							onClick: () => setEditing(s),
							children: "Edit"
						})]
					})]
				}, s.id))
			}),
			editing ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "panel mt-8 grid gap-4 p-5 sm:grid-cols-2",
				onSubmit: (e) => {
					e.preventDefault();
					if (!editing.name || !editing.slug) return;
					save.mutate({
						id: editing.id,
						name: editing.name,
						slug: editing.slug,
						startYear: Number(editing.startYear),
						endYear: Number(editing.endYear),
						tagline: editing.tagline,
						notes: editing.notes,
						isActive: editing.isActive,
						isArchived: editing.isArchived
					});
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: editing.name ?? "",
							onChange: (e) => setEditing({
								...editing,
								name: e.target.value
							}),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Slug",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: editing.slug ?? "",
							onChange: (e) => setEditing({
								...editing,
								slug: e.target.value
							}),
							required: true
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Start year",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: editing.startYear ?? 2026,
							onChange: (e) => setEditing({
								...editing,
								startYear: Number(e.target.value)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "End year",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							type: "number",
							value: editing.endYear ?? 2027,
							onChange: (e) => setEditing({
								...editing,
								endYear: Number(e.target.value)
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Tagline",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: editing.tagline ?? "",
							onChange: (e) => setEditing({
								...editing,
								tagline: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Notes",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: editing.notes ?? "",
							onChange: (e) => setEditing({
								...editing,
								notes: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: Boolean(editing.isActive),
							onChange: (e) => setEditing({
								...editing,
								isActive: e.target.checked
							})
						}), "Active season"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: Boolean(editing.isArchived),
							onChange: (e) => setEditing({
								...editing,
								isArchived: e.target.checked
							})
						}), "Archived"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: save.isPending,
							children: save.isPending ? "Saving…" : "Save"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							onClick: () => setEditing(null),
							children: "Cancel"
						})]
					})
				]
			}) : null
		]
	});
}
//#endregion
export { SeasonsPage as component };
