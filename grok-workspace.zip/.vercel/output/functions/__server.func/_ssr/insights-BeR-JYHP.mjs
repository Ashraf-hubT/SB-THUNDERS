import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { o as Route$17 } from "./router-BqvUT-Ki.mjs";
import { t as PublicShell } from "./public-shell-BOyI-Zlg.mjs";
import { t as EmptyState } from "./empty-state-BMSD6eul.mjs";
import { t as SectionHead } from "./section-head-v7RAHbAM.mjs";
import { t as SeasonSwitch } from "./season-switch-BULz71yR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights-BeR-JYHP.js
var import_jsx_runtime = require_jsx_runtime();
function InsightsPage() {
	const data = Route$17.useLoaderData();
	const i = data.insights;
	const cells = [
		{
			label: "Matches",
			value: i.played ? String(i.played) : "—"
		},
		{
			label: "Wins",
			value: i.played ? String(i.wins) : "—"
		},
		{
			label: "Losses",
			value: i.played ? String(i.losses) : "—"
		},
		{
			label: "Win %",
			value: i.winPct === null ? "—" : `${i.winPct}%`
		},
		{
			label: "Highest score",
			value: i.highestScore === null ? "—" : String(i.highestScore)
		},
		{
			label: "Lowest score",
			value: i.lowestScore === null ? "—" : String(i.lowestScore)
		},
		{
			label: "Best individual",
			value: i.bestIndividualScore === null ? "—" : String(i.bestIndividualScore)
		},
		{
			label: "Top run scorer",
			value: i.topRunScorer ? `${i.topRunScorer.name} · ${i.topRunScorer.runs}` : "—"
		},
		{
			label: "Top wicket taker",
			value: i.topWicketTaker ? `${i.topWicketTaker.name} · ${i.topWicketTaker.wickets}` : "—"
		}
	];
	const chart = data.matches.filter((m) => m.status === "completed" && m.published).slice().reverse();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicShell, {
		settings: data.settings,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 py-14 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
						overline: data.season?.name ?? "Analytics",
						title: "Team insights",
						copy: "Every figure on this page is computed from published matches. If a cell is a dash, the data has not been entered yet."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeasonSwitch, {
						seasons: data.seasons,
						current: data.season,
						path: "/insights"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-12 grid grid-cols-2 gap-3 lg:grid-cols-3",
					children: cells.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "panel p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] uppercase tracking-[0.18em] text-steel",
							children: c.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-display text-3xl text-ivory sm:text-4xl",
							children: c.value
						})]
					}, c.label))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-16 font-display text-4xl text-ivory",
					children: "Form"
				}),
				chart.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						title: "No form to plot",
						copy: "A result strip appears after published completed matches exist."
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-6 flex flex-wrap gap-2",
					children: chart.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						title: `${m.opponent} — ${m.resultDescription || m.result}`,
						className: `grid h-11 w-11 place-items-center text-xs font-semibold ${m.result === "won" ? "bg-thunder text-ivory" : "border border-white/15 text-steel"}`,
						children: m.result === "won" ? "W" : m.result === "lost" ? "L" : "·"
					}, m.id))
				})
			]
		})
	});
}
//#endregion
export { InsightsPage as component };
