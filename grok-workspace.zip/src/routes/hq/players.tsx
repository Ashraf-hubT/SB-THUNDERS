import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { HqShell } from "@/components/hq/hq-shell";
import { ImageField } from "@/components/hq/image-field";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { PLAYER_ROLES } from "@/lib/constants";
import { archivePlayer, getHqPlayers, savePlayer, setPlayerSeason } from "@/lib/server/hq";
import type { Player } from "@/lib/types";

export const Route = createFileRoute("/hq/players")({ component: PlayersPage });

const empty = {
  fullName: "",
  displayName: "",
  photoUrl: "",
  battingStyle: "",
  bowlingStyle: "",
  bio: "",
  cricheroesUrl: "",
  instagramUrl: "",
  twitterUrl: "",
  role: "Batter",
  managementTitle: "",
  jerseyNumber: "",
  isCaptain: false,
  isViceCaptain: false,
};

function PlayersPage() {
  const qc = useQueryClient();
  const [seasonId, setSeasonId] = useState<string>("");
  const q = useQuery({
    queryKey: ["hq-players", seasonId],
    queryFn: () => getHqPlayers({ data: { seasonId: seasonId || undefined } }),
  });
  const [form, setForm] = useState<typeof empty & { id?: string }>(empty);
  const [open, setOpen] = useState(false);

  const save = useMutation({
    mutationFn: () =>
      savePlayer({
        data: {
          ...form,
          seasonId: q.data?.season?.id,
          attachToSeason: true,
        },
      }),
    onSuccess: async () => {
      toast.success("Player saved");
      setOpen(false);
      setForm(empty);
      await qc.invalidateQueries();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const rosterIds = useMemo(
    () => new Set((q.data?.squad ?? []).map((s) => s.playerId)),
    [q.data?.squad],
  );

  function edit(p: Player) {
    const sp = q.data?.squad.find((s) => s.playerId === p.id);
    setForm({
      id: p.id,
      fullName: p.fullName,
      displayName: p.displayName,
      photoUrl: p.photoUrl,
      battingStyle: p.battingStyle,
      bowlingStyle: p.bowlingStyle,
      bio: p.bio,
      cricheroesUrl: p.cricheroesUrl,
      instagramUrl: p.instagramUrl,
      twitterUrl: p.twitterUrl,
      role: sp?.role ?? "Batter",
      managementTitle: sp?.managementTitle ?? "",
      jerseyNumber: sp?.jerseyNumber ?? "",
      isCaptain: Boolean(sp?.isCaptain),
      isViceCaptain: Boolean(sp?.isViceCaptain),
    });
    setOpen(true);
  }

  return (
    <HqShell title="Players">
      <div className="flex flex-wrap items-center gap-3">
        <Select
          value={q.data?.season?.id ?? seasonId}
          onChange={(e) => setSeasonId(e.target.value)}
          className="max-w-xs"
        >
          {(q.data?.seasons ?? []).map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </Select>
        <Button
          type="button"
          onClick={() => {
            setForm(empty);
            setOpen(true);
          }}
        >
          Add player
        </Button>
      </div>
      <p className="mt-3 text-sm text-steel">
        Archive instead of deleting. Attach a person to this season with a role — including Management or
        Player + Management.
      </p>
      <div className="mt-6 overflow-x-auto">
        <table className="w-full min-w-[640px] text-left text-sm">
          <thead className="text-[11px] uppercase tracking-[0.14em] text-steel">
            <tr>
              <th className="py-2">Player</th>
              <th>Role</th>
              <th>#</th>
              <th>Season</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {(q.data?.players ?? []).map((p) => {
              const sp = q.data?.squad.find((s) => s.playerId === p.id);
              return (
                <tr key={p.id} className="border-t border-white/5">
                  <td className="py-3">
                    <p className="text-ivory">{p.displayName}</p>
                    <p className="text-xs text-steel">{p.status === "archived" ? "Archived" : p.fullName}</p>
                  </td>
                  <td>{sp?.role ?? "—"}</td>
                  <td>{sp?.jerseyNumber || "—"}</td>
                  <td>{rosterIds.has(p.id) ? "In squad" : "Not this season"}</td>
                  <td className="space-x-2 text-right">
                    <Button type="button" size="sm" variant="ghost" onClick={() => edit(p)}>
                      Edit
                    </Button>
                    <Button
                      type="button"
                      size="sm"
                      variant="ghost"
                      onClick={async () => {
                        await archivePlayer({ data: { id: p.id, archived: p.status !== "archived" } });
                        await qc.invalidateQueries();
                      }}
                    >
                      {p.status === "archived" ? "Restore" : "Archive"}
                    </Button>
                    {q.data?.season && rosterIds.has(p.id) ? (
                      <Button
                        type="button"
                        size="sm"
                        variant="ghost"
                        onClick={async () => {
                          await setPlayerSeason({
                            data: { playerId: p.id, seasonId: q.data!.season!.id, role: "Batter", remove: true },
                          });
                          await qc.invalidateQueries();
                        }}
                      >
                        Remove season
                      </Button>
                    ) : null}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {q.data?.players?.length === 0 ? (
          <p className="mt-6 text-sm text-steel">No players yet. Add the first Thunder.</p>
        ) : null}
      </div>

      {open ? (
        <form
          className="panel mt-8 grid gap-4 p-5 sm:grid-cols-2"
          onSubmit={(e) => {
            e.preventDefault();
            save.mutate();
          }}
        >
          <Field label="Full name">
            <Input required value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
          </Field>
          <Field label="Display name">
            <Input required value={form.displayName} onChange={(e) => setForm({ ...form, displayName: e.target.value })} />
          </Field>
          <div className="sm:col-span-2">
            <ImageField label="Profile photo" value={form.photoUrl} onChange={(photoUrl) => setForm({ ...form, photoUrl })} />
          </div>
          <Field label="Role this season">
            <Select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
              {PLAYER_ROLES.map((r) => (
                <option key={r}>{r}</option>
              ))}
            </Select>
          </Field>
          <Field label="Jersey number">
            <Input value={form.jerseyNumber} onChange={(e) => setForm({ ...form, jerseyNumber: e.target.value })} />
          </Field>
          <Field label="Management title">
            <Input value={form.managementTitle} onChange={(e) => setForm({ ...form, managementTitle: e.target.value })} />
          </Field>
          <Field label="Batting">
            <Input value={form.battingStyle} onChange={(e) => setForm({ ...form, battingStyle: e.target.value })} />
          </Field>
          <Field label="Bowling">
            <Input value={form.bowlingStyle} onChange={(e) => setForm({ ...form, bowlingStyle: e.target.value })} />
          </Field>
          <Field label="CricHeroes URL">
            <Input value={form.cricheroesUrl} onChange={(e) => setForm({ ...form, cricheroesUrl: e.target.value })} />
          </Field>
          <Field label="Bio" className="sm:col-span-2">
            <Textarea value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} />
          </Field>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={form.isCaptain} onChange={(e) => setForm({ ...form, isCaptain: e.target.checked })} />
            Captain
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={form.isViceCaptain} onChange={(e) => setForm({ ...form, isViceCaptain: e.target.checked })} />
            Vice captain
          </label>
          <div className="flex gap-2 sm:col-span-2">
            <Button type="submit" disabled={save.isPending}>{save.isPending ? "Saving…" : "Save player"}</Button>
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>Cancel</Button>
          </div>
        </form>
      ) : null}
    </HqShell>
  );
}
