import { h as Outlet } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime, n as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { n as useCurrentUserState } from "./use-current-user-DG6UNzh9.mjs";
import { s as getHqAccess, t as RedirectToSignIn } from "./hq-DLvonivC.mjs";
import { t as Button } from "./button-CiAG7yUi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/route-BKIfD3h1.js
var import_jsx_runtime = require_jsx_runtime();
function HqGate() {
	const { user, isPending } = useCurrentUserState();
	const access = useQuery({
		queryKey: ["hq-access"],
		queryFn: () => getHqAccess(),
		enabled: Boolean(user),
		retry: false
	});
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "min-h-dvh bg-ink" });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, { to: "/login" });
	if (access.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "min-h-dvh bg-ink" });
	const message = access.error instanceof Error ? access.error.message : "";
	if (message === "Unauthorized" || message.toLowerCase().includes("unauthorized")) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, { to: "/login" });
	if (access.error) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-ink px-6 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.24em] text-thunder",
				children: "Restricted"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-5xl text-ivory",
				children: "HQ is locked"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 max-w-md text-sm text-steel",
				children: [
					"Signed in as ",
					user.primaryEmail ?? user.displayName,
					". This account is not on the SB THUNDERS administrator list."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "outline",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						children: "Return to the public site"
					})
				})
			})
		] })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
}
//#endregion
export { HqGate as component };
