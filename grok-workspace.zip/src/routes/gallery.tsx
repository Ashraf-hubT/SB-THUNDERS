import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { EmptyState } from "@/components/brand/empty-state";
import { SectionHead } from "@/components/brand/section-head";
import { Lightbox } from "@/components/public/lightbox";
import { PublicShell } from "@/components/public/public-shell";
import { SeasonSwitch } from "@/components/public/season-switch";
import { GALLERY_CATEGORIES, GALLERY_LABELS } from "@/lib/constants";
import { getGalleryPage } from "@/lib/server/public";
import { seasonSearch } from "@/lib/search";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/gallery")({
  validateSearch: seasonSearch,
  loaderDeps: ({ search }) => ({ season: search.season }),
  loader: ({ deps }) => getGalleryPage({ data: { season: deps.season } }),
  component: GalleryPage,
  head: () => ({
    meta: [{ title: "Gallery — SB THUNDERS" }],
    links: [{ rel: "canonical", href: "https://sbthunders.com/gallery" }],
  }),
});

function GalleryPage() {
  const data = Route.useLoaderData();
  const [cat, setCat] = useState<string>("all");
  const [open, setOpen] = useState<number | null>(null);
  const filtered = useMemo(
    () => (cat === "all" ? data.items : data.items.filter((i) => i.category === cat)),
    [cat, data.items],
  );

  return (
    <PublicShell settings={data.settings}>
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHead overline="Frames" title="Thunder moments" />
          <SeasonSwitch seasons={data.seasons} current={data.season} path="/gallery" />
        </div>
        <div className="mt-8 flex flex-wrap gap-2">
          <button
            type="button"
            onClick={() => setCat("all")}
            className={cn(
              "h-10 px-3 text-[11px] uppercase tracking-[0.16em]",
              cat === "all" ? "bg-thunder text-ivory" : "border border-white/10 text-steel",
            )}
          >
            All
          </button>
          {GALLERY_CATEGORIES.map((c) => (
            <button
              key={c}
              type="button"
              onClick={() => setCat(c)}
              className={cn(
                "h-10 px-3 text-[11px] uppercase tracking-[0.16em]",
                cat === c ? "bg-thunder text-ivory" : "border border-white/10 text-steel",
              )}
            >
              {GALLERY_LABELS[c]}
            </button>
          ))}
        </div>
        {filtered.length === 0 ? (
          <div className="mt-10">
            <EmptyState title="No photographs yet" copy="Upload match-day and training frames from HQ to fill this wall." />
          </div>
        ) : (
          <div className="mt-10 columns-1 gap-3 sm:columns-2 lg:columns-3">
            {filtered.map((item, idx) => (
              <button
                key={item.id}
                type="button"
                className="mb-3 block w-full overflow-hidden"
                onClick={() => setOpen(idx)}
              >
                <img
                  src={item.imageUrl}
                  alt={item.altText || item.title || "SB Thunders"}
                  className="w-full object-cover"
                  loading="lazy"
                />
              </button>
            ))}
          </div>
        )}
      </div>
      {open !== null ? (
        <Lightbox items={filtered} index={open} onClose={() => setOpen(null)} onMove={setOpen} />
      ) : null}
    </PublicShell>
  );
}
