import { useState } from "react";
import { toast } from "sonner";
import { compressImage } from "@/lib/image";
import { saveMedia } from "@/lib/server/hq";
import { Button } from "@/components/ui/button";

export function ImageField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (url: string) => void;
}) {
  const [busy, setBusy] = useState(false);

  async function onFile(file?: File) {
    if (!file) return;
    setBusy(true);
    try {
      const dataUrl = await compressImage(file);
      const saved = await saveMedia({ data: { dataUrl, alt: label } });
      onChange(saved.url);
      toast.success("Photo saved");
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Upload failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      <p className="mb-1.5 text-[11px] font-medium uppercase tracking-[0.16em] text-steel">{label}</p>
      {value ? (
        <img src={value} alt="" className="mb-3 h-32 w-32 object-cover" />
      ) : null}
      <label className="inline-flex">
        <input
          type="file"
          accept="image/jpeg,image/png,image/webp,image/gif"
          className="sr-only"
          onChange={(e) => void onFile(e.target.files?.[0])}
        />
        <Button type="button" variant="outline" size="sm" disabled={busy} asChild>
          <span>{busy ? "Uploading…" : value ? "Replace photo" : "Upload photo"}</span>
        </Button>
      </label>
    </div>
  );
}
