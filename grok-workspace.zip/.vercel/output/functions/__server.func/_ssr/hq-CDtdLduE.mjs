import { r as nid } from "./utils-4Kkadyjj.mjs";
import { r as createServerFn } from "./ssr.mjs";
import { i as getSql, t as dbSource } from "./db-Bi26CoM3.mjs";
import { t as authMiddleware } from "./middleware-Cf7rZssf.mjs";
import { r as EMPTY_INSIGHTS } from "./defaults-Dcf2xk_0.mjs";
import { a as fetchMatch, d as fetchSeasons, f as fetchSettings, g as pickFeaturedMatch, i as fetchInsights, m as mapPlayer, n as fetchAchievements, o as fetchMatchSquad, p as fetchSquad, r as fetchGallery, s as fetchMatches, t as createServerRpc } from "./repo-9DLyF-mf.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hq-CDtdLduE.js
var ForbiddenError = class extends Error {
	status = 403;
	constructor() {
		super("Forbidden");
		this.name = "ForbiddenError";
	}
};
async function assertAdmin(userId) {
	const sql = await getSql();
	const existing = await sql`
    select user_id, email, display_name from admins where user_id = ${userId}
  `;
	if (existing[0]) return {
		userId,
		email: existing[0].email,
		displayName: existing[0].display_name
	};
	const users = await sql`
    select email, name from "user" where id = ${userId}
  `;
	const email = (users[0]?.email ?? "").toLowerCase();
	const displayName = users[0]?.name ?? "Administrator";
	const allowed = email ? await sql`
        select email from admin_allowlist where lower(email) = ${email}
      ` : [];
	const canBootstrap = ((await sql`select count(*)::int as n from admins`)[0]?.n ?? 0) === 0 && dbSource === "pglite";
	if (allowed[0] || canBootstrap) {
		await sql`
      insert into admins (user_id, email, display_name)
      values (${userId}, ${email || "unknown"}, ${displayName})
      on conflict (user_id) do nothing
    `;
		return {
			userId,
			email: email || "unknown",
			displayName
		};
	}
	throw new ForbiddenError();
}
var adminMw = [authMiddleware];
async function requireAdmin(userId) {
	return assertAdmin(userId);
}
var getHqAccess_createServerFn_handler = createServerRpc({
	id: "55b831d6848f812dc5b5a05cf7a4b2bb92468ab8446e65b671494f15f556dcbd",
	name: "getHqAccess",
	filename: "src/lib/server/hq.ts"
}, (opts) => getHqAccess.__executeServer(opts));
var getHqAccess = createServerFn({ method: "GET" }).middleware(adminMw).handler(getHqAccess_createServerFn_handler, async ({ context }) => {
	return {
		isAdmin: true,
		...await requireAdmin(context.userId)
	};
});
var getHqDashboard_createServerFn_handler = createServerRpc({
	id: "f2dbe3e5afc3eb59ed9ad8f690ea14c3e36c53ff1ac80b8ef609feff4f49f92f",
	name: "getHqDashboard",
	filename: "src/lib/server/hq.ts"
}, (opts) => getHqDashboard.__executeServer(opts));
var getHqDashboard = createServerFn({ method: "GET" }).middleware(adminMw).handler(getHqDashboard_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	const settings = await fetchSettings();
	const seasons = await fetchSeasons();
	const active = seasons.find((s) => s.isActive) ?? null;
	if (!active) return {
		settings,
		seasons,
		active,
		squadCount: 0,
		insights: EMPTY_INSIGHTS,
		featured: null,
		next: null,
		recent: null,
		gallery: [],
		draftMatches: 0
	};
	const [squad, matches, gallery, insights] = await Promise.all([
		fetchSquad(active.id, { includeArchived: true }),
		fetchMatches(active.id),
		fetchGallery(active.id, { limit: 6 }),
		fetchInsights(active.id)
	]);
	const { featured, next, recent } = pickFeaturedMatch(matches);
	return {
		settings,
		seasons,
		active,
		squadCount: squad.filter((s) => s.status === "active").length,
		insights,
		featured,
		next,
		recent,
		gallery,
		draftMatches: matches.filter((m) => !m.published).length
	};
});
var getHqSeasons_createServerFn_handler = createServerRpc({
	id: "790730fe9ca755eb98e6cc527e695ea2dac00024234117699e649b8b39a009e4",
	name: "getHqSeasons",
	filename: "src/lib/server/hq.ts"
}, (opts) => getHqSeasons.__executeServer(opts));
var getHqSeasons = createServerFn({ method: "GET" }).middleware(adminMw).handler(getHqSeasons_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	return fetchSeasons();
});
var saveSeason_createServerFn_handler = createServerRpc({
	id: "70fd2d3d3c68dbb0e006a0c3b7b4800c725df91242e5356f20ed6aa4a863df90",
	name: "saveSeason",
	filename: "src/lib/server/hq.ts"
}, (opts) => saveSeason.__executeServer(opts));
var saveSeason = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(saveSeason_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	const sql = await getSql();
	const id = data.id || nid();
	if (data.isActive) await sql`update seasons set is_active = false, updated_at = now()`;
	await sql`
      insert into seasons (id, name, slug, start_year, end_year, is_active, is_archived, tagline, notes, updated_at)
      values (
        ${id}, ${data.name.trim()}, ${data.slug.trim()}, ${data.startYear}, ${data.endYear},
        ${Boolean(data.isActive)}, ${Boolean(data.isArchived)}, ${data.tagline ?? ""}, ${data.notes ?? ""}, now()
      )
      on conflict (id) do update set
        name = excluded.name,
        slug = excluded.slug,
        start_year = excluded.start_year,
        end_year = excluded.end_year,
        is_active = excluded.is_active,
        is_archived = excluded.is_archived,
        tagline = excluded.tagline,
        notes = excluded.notes,
        updated_at = now()
    `;
	return { id };
});
var setActiveSeason_createServerFn_handler = createServerRpc({
	id: "fcdd5f31b1cabb90f6ff0a6ace28370e6e44cc0d893ab592d9115ba586d35676",
	name: "setActiveSeason",
	filename: "src/lib/server/hq.ts"
}, (opts) => setActiveSeason.__executeServer(opts));
var setActiveSeason = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(setActiveSeason_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	const sql = await getSql();
	await sql`update seasons set is_active = false, updated_at = now()`;
	await sql`update seasons set is_active = true, is_archived = false, updated_at = now() where id = ${data.id}`;
	return { ok: true };
});
var getHqPlayers_createServerFn_handler = createServerRpc({
	id: "73be6c4e27dfd064b9cb05f937f64822ddfdf0d6dae21998676e0479b1727c63",
	name: "getHqPlayers",
	filename: "src/lib/server/hq.ts"
}, (opts) => getHqPlayers.__executeServer(opts));
var getHqPlayers = createServerFn({ method: "GET" }).middleware(adminMw).validator((data) => data).handler(getHqPlayers_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	const seasons = await fetchSeasons();
	const season = data.seasonId ? seasons.find((s) => s.id === data.seasonId) ?? seasons.find((s) => s.isActive) : seasons.find((s) => s.isActive) ?? seasons[0];
	const allPlayers = await (await getSql())`
      select * from players order by display_name asc
    `;
	const squad = season ? await fetchSquad(season.id, { includeArchived: true }) : [];
	return {
		seasons,
		season,
		players: allPlayers.map((r) => mapPlayer(r)),
		squad
	};
});
var savePlayer_createServerFn_handler = createServerRpc({
	id: "ef99f77754bcf8f391766c4a2e18743637265b480c3affcd00bc8108cc6dc38b",
	name: "savePlayer",
	filename: "src/lib/server/hq.ts"
}, (opts) => savePlayer.__executeServer(opts));
var savePlayer = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(savePlayer_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	const sql = await getSql();
	const id = data.id || nid();
	await sql`
      insert into players (
        id, full_name, display_name, photo_url, batting_style, bowling_style, bio,
        cricheroes_url, instagram_url, twitter_url, status, updated_at
      ) values (
        ${id}, ${data.fullName.trim()}, ${data.displayName.trim()}, ${data.photoUrl ?? ""},
        ${data.battingStyle ?? ""}, ${data.bowlingStyle ?? ""}, ${data.bio ?? ""},
        ${data.cricheroesUrl ?? ""}, ${data.instagramUrl ?? ""}, ${data.twitterUrl ?? ""},
        ${data.status ?? "active"}, now()
      )
      on conflict (id) do update set
        full_name = excluded.full_name,
        display_name = excluded.display_name,
        photo_url = excluded.photo_url,
        batting_style = excluded.batting_style,
        bowling_style = excluded.bowling_style,
        bio = excluded.bio,
        cricheroes_url = excluded.cricheroes_url,
        instagram_url = excluded.instagram_url,
        twitter_url = excluded.twitter_url,
        status = excluded.status,
        updated_at = now()
    `;
	if (data.seasonId && data.attachToSeason !== false) await sql`
        insert into season_players (
          id, season_id, player_id, role, management_title, jersey_number,
          is_captain, is_vice_captain, status
        ) values (
          ${nid()}, ${data.seasonId}, ${id}, ${data.role ?? "Batter"}, ${data.managementTitle ?? ""},
          ${data.jerseyNumber ?? ""}, ${Boolean(data.isCaptain)}, ${Boolean(data.isViceCaptain)}, 'active'
        )
        on conflict (season_id, player_id) do update set
          role = excluded.role,
          management_title = excluded.management_title,
          jersey_number = excluded.jersey_number,
          is_captain = excluded.is_captain,
          is_vice_captain = excluded.is_vice_captain,
          status = 'active'
      `;
	return { id };
});
var setPlayerSeason_createServerFn_handler = createServerRpc({
	id: "799ee1dfbdcaeca4a8a923499c4ec4b057785998aaee78cf4068777351addbc5",
	name: "setPlayerSeason",
	filename: "src/lib/server/hq.ts"
}, (opts) => setPlayerSeason.__executeServer(opts));
var setPlayerSeason = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(setPlayerSeason_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	const sql = await getSql();
	if (data.remove) {
		await sql`delete from season_players where player_id = ${data.playerId} and season_id = ${data.seasonId}`;
		return { ok: true };
	}
	await sql`
      insert into season_players (
        id, season_id, player_id, role, management_title, jersey_number,
        is_captain, is_vice_captain, status
      ) values (
        ${nid()}, ${data.seasonId}, ${data.playerId}, ${data.role}, ${data.managementTitle ?? ""},
        ${data.jerseyNumber ?? ""}, ${Boolean(data.isCaptain)}, ${Boolean(data.isViceCaptain)},
        ${data.status ?? "active"}
      )
      on conflict (season_id, player_id) do update set
        role = excluded.role,
        management_title = excluded.management_title,
        jersey_number = excluded.jersey_number,
        is_captain = excluded.is_captain,
        is_vice_captain = excluded.is_vice_captain,
        status = excluded.status
    `;
	return { ok: true };
});
var archivePlayer_createServerFn_handler = createServerRpc({
	id: "4821bfc76543745c82f74604cff39cd4d67e0f4566982a16cbb6f646c4fba2e5",
	name: "archivePlayer",
	filename: "src/lib/server/hq.ts"
}, (opts) => archivePlayer.__executeServer(opts));
var archivePlayer = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(archivePlayer_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	await (await getSql())`update players set status = ${data.archived ? "archived" : "active"}, updated_at = now() where id = ${data.id}`;
	return { ok: true };
});
var getHqMatches_createServerFn_handler = createServerRpc({
	id: "7a7299c85d0c08303a88d60b87c983b1523a6b64d2157b25f011dd90226ca028",
	name: "getHqMatches",
	filename: "src/lib/server/hq.ts"
}, (opts) => getHqMatches.__executeServer(opts));
var getHqMatches = createServerFn({ method: "GET" }).middleware(adminMw).validator((data) => data).handler(getHqMatches_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	const seasons = await fetchSeasons();
	const season = data.seasonId ? seasons.find((s) => s.id === data.seasonId) : seasons.find((s) => s.isActive) ?? seasons[0];
	return {
		seasons,
		season,
		matches: season ? await fetchMatches(season.id) : []
	};
});
var getHqMatch_createServerFn_handler = createServerRpc({
	id: "68bbcac48f2b99702f7d03c9f336cc8788f7843d1ea2cd98f399cae101530bcc",
	name: "getHqMatch",
	filename: "src/lib/server/hq.ts"
}, (opts) => getHqMatch.__executeServer(opts));
var getHqMatch = createServerFn({ method: "GET" }).middleware(adminMw).validator((data) => data).handler(getHqMatch_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	const match = await fetchMatch(data.id);
	const squad = match ? await fetchMatchSquad(match.id) : [];
	const seasons = await fetchSeasons();
	const season = match ? seasons.find((s) => s.id === match.seasonId) ?? null : null;
	const roster = season ? await fetchSquad(season.id, { includeArchived: true }) : [];
	const sql = await getSql();
	return {
		match,
		squad,
		seasons,
		season,
		roster,
		selectedIds: (match ? await sql`select player_id from match_squad where match_id = ${match.id} and is_playing = true` : []).map((r) => r.player_id)
	};
});
var saveMatch_createServerFn_handler = createServerRpc({
	id: "57c4aca885bd0b041838a74a25066321dd285e579c11e4912e09fea0bd26c442",
	name: "saveMatch",
	filename: "src/lib/server/hq.ts"
}, (opts) => saveMatch.__executeServer(opts));
var saveMatch = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(saveMatch_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	const sql = await getSql();
	const id = data.id || nid();
	if (data.isFeatured) await sql`update matches set is_featured = false where season_id = ${data.seasonId}`;
	const dateVal = data.matchDate ? data.matchDate : null;
	await sql`
      insert into matches (
        id, season_id, opponent, venue, match_date, match_time, status, is_featured, published,
        our_score_text, opp_score_text, our_runs, opp_runs, result, result_description,
        player_of_match_id, notes, cricheroes_url, competition, source_note, updated_at
      ) values (
        ${id}, ${data.seasonId}, ${data.opponent.trim()}, ${data.venue ?? ""}, ${dateVal},
        ${data.matchTime ?? ""}, ${data.status ?? "upcoming"}, ${Boolean(data.isFeatured)},
        ${Boolean(data.published)}, ${data.ourScoreText ?? ""}, ${data.oppScoreText ?? ""},
        ${data.ourRuns ?? null}, ${data.oppRuns ?? null}, ${data.result ?? ""},
        ${data.resultDescription ?? ""}, ${data.playerOfMatchId ?? null}, ${data.notes ?? ""},
        ${data.cricheroesUrl ?? ""}, ${data.competition ?? ""}, ${data.sourceNote ?? ""}, now()
      )
      on conflict (id) do update set
        season_id = excluded.season_id,
        opponent = excluded.opponent,
        venue = excluded.venue,
        match_date = excluded.match_date,
        match_time = excluded.match_time,
        status = excluded.status,
        is_featured = excluded.is_featured,
        published = excluded.published,
        our_score_text = excluded.our_score_text,
        opp_score_text = excluded.opp_score_text,
        our_runs = excluded.our_runs,
        opp_runs = excluded.opp_runs,
        result = excluded.result,
        result_description = excluded.result_description,
        player_of_match_id = excluded.player_of_match_id,
        notes = excluded.notes,
        cricheroes_url = excluded.cricheroes_url,
        competition = excluded.competition,
        source_note = excluded.source_note,
        updated_at = now()
    `;
	if (data.squadIds) {
		await sql`delete from match_squad where match_id = ${id}`;
		for (let i = 0; i < data.squadIds.length; i++) await sql`
          insert into match_squad (match_id, player_id, is_playing, batting_order)
          values (${id}, ${data.squadIds[i]}, true, ${i})
        `;
	}
	return { id };
});
var getHqMatchDay_createServerFn_handler = createServerRpc({
	id: "4552bb385fefed5b3758d3066abe1169327399d0e722ec6d142028b96f8b8149",
	name: "getHqMatchDay",
	filename: "src/lib/server/hq.ts"
}, (opts) => getHqMatchDay.__executeServer(opts));
var getHqMatchDay = createServerFn({ method: "GET" }).middleware(adminMw).handler(getHqMatchDay_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	const seasons = await fetchSeasons();
	const active = seasons.find((s) => s.isActive) ?? seasons[0] ?? null;
	const matches = active ? await fetchMatches(active.id) : [];
	const { featured, next } = pickFeaturedMatch(matches);
	const current = featured ?? next ?? matches[0] ?? null;
	return {
		seasons,
		active,
		matches,
		current,
		roster: active ? await fetchSquad(active.id, { includeArchived: true }) : [],
		selected: current ? (await fetchMatchSquad(current.id)).map((s) => s.playerId) : []
	};
});
var saveMedia_createServerFn_handler = createServerRpc({
	id: "918c25a603ca31cde0e7b3047d909f6d82c853444a4dbe78d9bc232320680581",
	name: "saveMedia",
	filename: "src/lib/server/hq.ts"
}, (opts) => saveMedia.__executeServer(opts));
var saveMedia = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(saveMedia_createServerFn_handler, async ({ context, data }) => {
	const ident = await requireAdmin(context.userId);
	const url = data.dataUrl.trim();
	if (!url.startsWith("data:image/")) throw new Error("Only image uploads are allowed.");
	if (url.length > 14e5) throw new Error("Image is too large. Compress it under 1MB.");
	const mime = url.slice(5, url.indexOf(";")) || "image/jpeg";
	if (!/^image\/(jpeg|png|webp|gif)$/.test(mime)) throw new Error("Unsupported image type.");
	const id = nid();
	await (await getSql())`
      insert into media (id, mime_type, data_url, alt_text, created_by)
      values (${id}, ${mime}, ${url}, ${data.alt ?? ""}, ${ident.userId})
    `;
	return {
		id,
		url: `/api/media/${id}`
	};
});
var getHqGallery_createServerFn_handler = createServerRpc({
	id: "b8f3af460956e7e243fd86bafb306ac4d69fac7cd5365d42227f2dfaedae8b02",
	name: "getHqGallery",
	filename: "src/lib/server/hq.ts"
}, (opts) => getHqGallery.__executeServer(opts));
var getHqGallery = createServerFn({ method: "GET" }).middleware(adminMw).handler(getHqGallery_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	return {
		seasons: await fetchSeasons(),
		items: await fetchGallery(null)
	};
});
var saveGalleryItem_createServerFn_handler = createServerRpc({
	id: "cf914fc017eea846dc99b446889bb44b27c0ec2b0afdd0c6f8f75d212f5409e5",
	name: "saveGalleryItem",
	filename: "src/lib/server/hq.ts"
}, (opts) => saveGalleryItem.__executeServer(opts));
var saveGalleryItem = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(saveGalleryItem_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	const sql = await getSql();
	const id = data.id || nid();
	await sql`
      insert into gallery_items (
        id, season_id, title, category, image_url, alt_text, published, display_order, updated_at
      ) values (
        ${id}, ${data.seasonId ?? null}, ${data.title ?? ""}, ${data.category}, ${data.imageUrl},
        ${data.altText ?? ""}, ${Boolean(data.published)}, ${data.displayOrder ?? 0}, now()
      )
      on conflict (id) do update set
        season_id = excluded.season_id,
        title = excluded.title,
        category = excluded.category,
        image_url = excluded.image_url,
        alt_text = excluded.alt_text,
        published = excluded.published,
        display_order = excluded.display_order,
        updated_at = now()
    `;
	return { id };
});
var deleteGalleryItem_createServerFn_handler = createServerRpc({
	id: "d1642aa28dc70d3ecf8a243eba2ee0c4631003b19f0dfae0fb4f6b7d52aeeed2",
	name: "deleteGalleryItem",
	filename: "src/lib/server/hq.ts"
}, (opts) => deleteGalleryItem.__executeServer(opts));
var deleteGalleryItem = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(deleteGalleryItem_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	await (await getSql())`delete from gallery_items where id = ${data.id}`;
	return { ok: true };
});
var getHqAchievements_createServerFn_handler = createServerRpc({
	id: "bb220fafa420ed780873ec770da77b0330db4b9d75ff893d7aa0fd520d0a6f4a",
	name: "getHqAchievements",
	filename: "src/lib/server/hq.ts"
}, (opts) => getHqAchievements.__executeServer(opts));
var getHqAchievements = createServerFn({ method: "GET" }).middleware(adminMw).handler(getHqAchievements_createServerFn_handler, async ({ context }) => {
	await requireAdmin(context.userId);
	return {
		seasons: await fetchSeasons(),
		items: await fetchAchievements(null)
	};
});
var saveAchievement_createServerFn_handler = createServerRpc({
	id: "f7d26abe2fdda37ed6274a6522366ea1165794273daf81f0b2534499fc5a819b",
	name: "saveAchievement",
	filename: "src/lib/server/hq.ts"
}, (opts) => saveAchievement.__executeServer(opts));
var saveAchievement = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(saveAchievement_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	const sql = await getSql();
	const id = data.id || nid();
	await sql`
      insert into achievements (
        id, season_id, title, year, result, description, image_url, competition, published, display_order, updated_at
      ) values (
        ${id}, ${data.seasonId ?? null}, ${data.title.trim()}, ${data.year ?? ""}, ${data.result ?? ""},
        ${data.description ?? ""}, ${data.imageUrl ?? ""}, ${data.competition ?? ""},
        ${Boolean(data.published)}, ${data.displayOrder ?? 0}, now()
      )
      on conflict (id) do update set
        season_id = excluded.season_id,
        title = excluded.title,
        year = excluded.year,
        result = excluded.result,
        description = excluded.description,
        image_url = excluded.image_url,
        competition = excluded.competition,
        published = excluded.published,
        display_order = excluded.display_order,
        updated_at = now()
    `;
	return { id };
});
var deleteAchievement_createServerFn_handler = createServerRpc({
	id: "6c99992ab8eb44dc119ee678ae09ec3eb73ee80c4610112c773baf7289f6d2cb",
	name: "deleteAchievement",
	filename: "src/lib/server/hq.ts"
}, (opts) => deleteAchievement.__executeServer(opts));
var deleteAchievement = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(deleteAchievement_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	await (await getSql())`delete from achievements where id = ${data.id}`;
	return { ok: true };
});
var saveSettings_createServerFn_handler = createServerRpc({
	id: "2d5e0e59bf1ef53bd9426d9bce9e9e25814276eb0cb578f1df87ede0a1ca5438",
	name: "saveSettings",
	filename: "src/lib/server/hq.ts"
}, (opts) => saveSettings.__executeServer(opts));
var saveSettings = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(saveSettings_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	const sql = await getSql();
	const s = (k, fallback = "") => data[k] ?? fallback;
	await sql`
      update site_settings set
        team_name = ${s("teamName", "SB THUNDERS")},
        tagline = ${s("tagline")},
        supporting_copy = ${s("supportingCopy")},
        hero_line_1 = ${s("heroLine1", "SB")},
        hero_line_2 = ${s("heroLine2", "THUNDERS")},
        quote_line = ${s("quoteLine")},
        story = ${s("story")},
        origin = ${s("origin")},
        values_text = ${s("valuesText")},
        philosophy = ${s("philosophy")},
        milestones = ${s("milestones")},
        culture = ${s("culture")},
        email = ${s("email", "sbthunders@gmail.com")},
        instagram_url = ${s("instagramUrl")},
        twitter_url = ${s("twitterUrl")},
        facebook_url = ${s("facebookUrl")},
        youtube_url = ${s("youtubeUrl")},
        whatsapp_url = ${s("whatsappUrl")},
        cricheroes_team_url = ${s("cricheroesTeamUrl")},
        admin_name = ${s("adminName", "Ashraf")},
        admin_role = ${s("adminRole")},
        admin_photo_url = ${s("adminPhotoUrl")},
        admin_bio = ${s("adminBio")},
        admin_deep_dive_url = ${s("adminDeepDiveUrl")},
        logo_url = ${s("logoUrl", "/team/logo.jpg")},
        seo_title = ${s("seoTitle")},
        seo_description = ${s("seoDescription")},
        updated_at = now()
      where id = 'site'
    `;
	return { ok: true };
});
var getHqSettings_createServerFn_handler = createServerRpc({
	id: "786536c47ce2eb4b10eba83486543983c5789b67316abef14c05f7fd4c7d9615",
	name: "getHqSettings",
	filename: "src/lib/server/hq.ts"
}, (opts) => getHqSettings.__executeServer(opts));
var getHqSettings = createServerFn({ method: "GET" }).middleware(adminMw).handler(getHqSettings_createServerFn_handler, async ({ context }) => {
	const ident = await requireAdmin(context.userId);
	return {
		settings: await fetchSettings(),
		ident,
		allowlist: (await (await getSql())`select email from admin_allowlist order by email`).map((r) => r.email)
	};
});
var addAllowlistEmail_createServerFn_handler = createServerRpc({
	id: "7fde70b2ae28dffcdbc60a98548823f02a38a667c5444ee30d912059484a962e",
	name: "addAllowlistEmail",
	filename: "src/lib/server/hq.ts"
}, (opts) => addAllowlistEmail.__executeServer(opts));
var addAllowlistEmail = createServerFn({ method: "POST" }).middleware(adminMw).validator((data) => data).handler(addAllowlistEmail_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	const email = data.email.trim().toLowerCase();
	if (!email.includes("@")) throw new Error("Enter a valid email.");
	await (await getSql())`insert into admin_allowlist (email) values (${email}) on conflict do nothing`;
	return { ok: true };
});
var getHqInsights_createServerFn_handler = createServerRpc({
	id: "f36ad1aeb375c614daf9586e5b8b0b25c3e6bc054874b68af50009b374bd8390",
	name: "getHqInsights",
	filename: "src/lib/server/hq.ts"
}, (opts) => getHqInsights.__executeServer(opts));
var getHqInsights = createServerFn({ method: "GET" }).middleware(adminMw).validator((data) => data).handler(getHqInsights_createServerFn_handler, async ({ context, data }) => {
	await requireAdmin(context.userId);
	const seasons = await fetchSeasons();
	const season = data.seasonId ? seasons.find((s) => s.id === data.seasonId) : seasons.find((s) => s.isActive) ?? seasons[0];
	return {
		seasons,
		season,
		insights: season ? await fetchInsights(season.id) : EMPTY_INSIGHTS,
		matches: season ? await fetchMatches(season.id) : []
	};
});
//#endregion
export { addAllowlistEmail_createServerFn_handler, archivePlayer_createServerFn_handler, deleteAchievement_createServerFn_handler, deleteGalleryItem_createServerFn_handler, getHqAccess_createServerFn_handler, getHqAchievements_createServerFn_handler, getHqDashboard_createServerFn_handler, getHqGallery_createServerFn_handler, getHqInsights_createServerFn_handler, getHqMatchDay_createServerFn_handler, getHqMatch_createServerFn_handler, getHqMatches_createServerFn_handler, getHqPlayers_createServerFn_handler, getHqSeasons_createServerFn_handler, getHqSettings_createServerFn_handler, saveAchievement_createServerFn_handler, saveGalleryItem_createServerFn_handler, saveMatch_createServerFn_handler, saveMedia_createServerFn_handler, savePlayer_createServerFn_handler, saveSeason_createServerFn_handler, saveSettings_createServerFn_handler, setActiveSeason_createServerFn_handler, setPlayerSeason_createServerFn_handler };
