import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as createFileRoute, d as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, u as Scripts, v as createRootRoute, x as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime, r as QueryClientProvider } from "../_libs/react+tanstack__react-query.mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn, s as __exportAll } from "./ssr.mjs";
import { L as string, N as number, P as object, R as union, j as literal } from "../_libs/@better-auth/core+[...].mjs";
import { i as getSql } from "./db-Bi26CoM3.mjs";
import { n as auth } from "./server-BBjBCFBM.mjs";
import { o as TriangleAlert } from "../_libs/lucide-react.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/createSsrRpc-B2Izd0c7.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/public-DQBeyCRR.js
createServerFn({ method: "GET" }).handler(createSsrRpc("2fd89eecc2f03d5fb702e845f67dfffa483a618a11c74a30e8a139788e0f59c2"));
createServerFn({ method: "GET" }).handler(createSsrRpc("c1a404d242cf182d4d95db16d7c3ba34225ce1e2ed601cc635ef9f2876b96ddb"));
var getHomeData = createServerFn({ method: "GET" }).handler(createSsrRpc("8e516e6c233a5b7ed69769059de3433e6aaa7835b16e18357cec1779bd83c31e"));
var getSquadPage = createServerFn({ method: "GET" }).validator((data) => data).handler(createSsrRpc("9c8e5f431450b7c0104fdcd45e47eb114fddcecc1172f78b611195de0584ab2a"));
var getPlayerPage = createServerFn({ method: "GET" }).validator((data) => data).handler(createSsrRpc("08049ab9daac3ed4b5224cf33d8607df4844f9b26d24fc1a5b884095fba30634"));
var getMatchesPage = createServerFn({ method: "GET" }).validator((data) => data).handler(createSsrRpc("c6d9fddd9077d4661bfc8ed37bc5a74db9bd4eca52552725bc205e3245bcf63f"));
var getMatchPage = createServerFn({ method: "GET" }).validator((data) => data).handler(createSsrRpc("7ede41b85ed74030e5c63088fb31e0a83211ae96683191c36250848cc8d50734"));
var getInsightsPage = createServerFn({ method: "GET" }).validator((data) => data).handler(createSsrRpc("9ca3ef9aa8398875c083fe295a833bb7ec3b3c6b8549a76d7d9801ce9bcd8b8b"));
var getGalleryPage = createServerFn({ method: "GET" }).validator((data) => data).handler(createSsrRpc("c9b9c635a5dc433cbcd3f852aeb1fa6bc0cc972fb4688f3e7cb841dd60a372e9"));
var getAchievementsPage = createServerFn({ method: "GET" }).validator((data) => data).handler(createSsrRpc("b2671cff0385584045fce9a67498b1d2dfadcb805352f2066f36b82acf8a6f55"));
var getAboutPage = createServerFn({ method: "GET" }).handler(createSsrRpc("9ae72003f95e5d7507b0c58bbd9279c3e67dc59ddd193f38f3d10b9be2c08517"));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/search-Co7ylMuW.js
function seasonSearch(s) {
	return { season: typeof s.season === "string" ? s.season : void 0 };
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-BqvUT-Ki.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function QueryProvider({ children }) {
	const [client] = (0, import_react.useState)(() => new QueryClient({ defaultOptions: { queries: {
		staleTime: 2e4,
		retry: 1,
		refetchOnWindowFocus: false
	} } }));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client,
		children
	});
}
var SITE_TITLE = "SB THUNDERS — Official Team Portfolio";
var PLAYER_ROLES = [
	"Batter",
	"Bowler",
	"All-Rounder",
	"Wicket Keeper",
	"Management",
	"Player + Management"
];
var MATCH_STATUSES = [
	"upcoming",
	"live",
	"completed"
];
var MATCH_RESULTS = [
	"",
	"won",
	"lost",
	"draw",
	"tie",
	"no_result",
	"abandoned"
];
var GALLERY_CATEGORIES = [
	"squad",
	"match_day",
	"victories",
	"training",
	"moments",
	"graphics",
	"other"
];
var GALLERY_LABELS = {
	squad: "Squad",
	match_day: "Match Day",
	victories: "Victories",
	training: "Training",
	moments: "Moments",
	graphics: "Graphics",
	other: "Other"
};
var PUBLIC_NAV = [
	{
		to: "/",
		label: "Home"
	},
	{
		to: "/squad",
		label: "Squad"
	},
	{
		to: "/matches",
		label: "Matches"
	},
	{
		to: "/insights",
		label: "Insights"
	},
	{
		to: "/gallery",
		label: "Gallery"
	},
	{
		to: "/achievements",
		label: "Achievements"
	},
	{
		to: "/about",
		label: "About"
	}
];
var HQ_NAV = [
	{
		to: "/hq",
		label: "Dashboard",
		icon: "layout"
	},
	{
		to: "/hq/seasons",
		label: "Seasons",
		icon: "calendar"
	},
	{
		to: "/hq/players",
		label: "Players",
		icon: "users"
	},
	{
		to: "/hq/match-day",
		label: "Today's Match",
		icon: "zap"
	},
	{
		to: "/hq/matches",
		label: "Matches",
		icon: "list"
	},
	{
		to: "/hq/insights",
		label: "Insights",
		icon: "chart"
	},
	{
		to: "/hq/gallery",
		label: "Gallery",
		icon: "image"
	},
	{
		to: "/hq/achievements",
		label: "Achievements",
		icon: "trophy"
	},
	{
		to: "/hq/settings",
		label: "Settings",
		icon: "settings"
	},
	{
		to: "/hq/profile",
		label: "Admin Profile",
		icon: "user"
	}
];
var styles_default = "/assets/styles-DMQdIvKw.css";
var Route$23 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: SITE_TITLE },
			{
				name: "description",
				content: "Official home of SB THUNDERS. More than a team. One thunder."
			},
			{
				name: "theme-color",
				content: "#070B14"
			},
			{
				name: "robots",
				content: "index,follow"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "canonical",
				href: "https://sbthunders.com/"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Outfit:wght@300;400;500;600;700&display=swap"
			}
		]
	}),
	component: RootDocument
});
function RootDocument() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-navy text-ivory",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(QueryProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
					theme: "dark",
					position: "top-center",
					richColors: false
				})] }) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$20 = () => import("./routes-59ZznuHX.mjs");
var Route$22 = createFileRoute("/")({
	loader: () => getHomeData(),
	component: lazyRouteComponent($$splitComponentImporter$20, "component"),
	head: () => ({
		meta: [{ title: "SB THUNDERS — Official Team Portfolio" }],
		links: [{
			rel: "canonical",
			href: "https://sbthunders.com/"
		}]
	})
});
var $$splitComponentImporter$19 = () => import("./about-DQSDq6Nh.mjs");
var Route$21 = createFileRoute("/about")({
	loader: () => getAboutPage(),
	component: lazyRouteComponent($$splitComponentImporter$19, "component"),
	head: () => ({
		meta: [{ title: "About — SB THUNDERS" }],
		links: [{
			rel: "canonical",
			href: "https://sbthunders.com/about"
		}]
	})
});
var $$splitComponentImporter$18 = () => import("./achievements-3xZcZnmk.mjs");
var Route$20 = createFileRoute("/achievements")({
	validateSearch: seasonSearch,
	loaderDeps: ({ search }) => ({ season: search.season }),
	loader: ({ deps }) => getAchievementsPage({ data: { season: deps.season } }),
	component: lazyRouteComponent($$splitComponentImporter$18, "component"),
	head: () => ({
		meta: [{ title: "Achievements — SB THUNDERS" }],
		links: [{
			rel: "canonical",
			href: "https://sbthunders.com/achievements"
		}]
	})
});
var $$splitComponentImporter$17 = () => import("./gallery-CzxreuSx.mjs");
var Route$19 = createFileRoute("/gallery")({
	validateSearch: seasonSearch,
	loaderDeps: ({ search }) => ({ season: search.season }),
	loader: ({ deps }) => getGalleryPage({ data: { season: deps.season } }),
	component: lazyRouteComponent($$splitComponentImporter$17, "component"),
	head: () => ({
		meta: [{ title: "Gallery — SB THUNDERS" }],
		links: [{
			rel: "canonical",
			href: "https://sbthunders.com/gallery"
		}]
	})
});
var $$splitComponentImporter$16 = () => import("./route-BKIfD3h1.mjs");
var Route$18 = createFileRoute("/hq")({ component: lazyRouteComponent($$splitComponentImporter$16, "component") });
var $$splitComponentImporter$15 = () => import("./insights-BeR-JYHP.mjs");
var Route$17 = createFileRoute("/insights")({
	validateSearch: seasonSearch,
	loaderDeps: ({ search }) => ({ season: search.season }),
	loader: ({ deps }) => getInsightsPage({ data: { season: deps.season } }),
	component: lazyRouteComponent($$splitComponentImporter$15, "component"),
	head: () => ({
		meta: [{ title: "Insights — SB THUNDERS" }],
		links: [{
			rel: "canonical",
			href: "https://sbthunders.com/insights"
		}]
	})
});
var $$splitComponentImporter$14 = () => import("./login-BTyyVlG4.mjs");
var Route$16 = createFileRoute("/login")({ component: lazyRouteComponent($$splitComponentImporter$14, "component") });
var $$splitComponentImporter$13 = () => import("./matches-RMOg5Pfr.mjs");
var Route$15 = createFileRoute("/matches")({
	validateSearch: seasonSearch,
	loaderDeps: ({ search }) => ({ season: search.season }),
	loader: ({ deps }) => getMatchesPage({ data: { season: deps.season } }),
	component: lazyRouteComponent($$splitComponentImporter$13, "component"),
	head: () => ({
		meta: [{ title: "Matches — SB THUNDERS" }],
		links: [{
			rel: "canonical",
			href: "https://sbthunders.com/matches"
		}]
	})
});
var $$splitComponentImporter$12 = () => import("./squad-ChhT2Ioa.mjs");
var Route$14 = createFileRoute("/squad")({
	validateSearch: seasonSearch,
	loaderDeps: ({ search }) => ({ season: search.season }),
	loader: ({ deps }) => getSquadPage({ data: { season: deps.season } }),
	component: lazyRouteComponent($$splitComponentImporter$12, "component"),
	head: () => ({
		meta: [{ title: "Squad — SB THUNDERS" }],
		links: [{
			rel: "canonical",
			href: "https://sbthunders.com/squad"
		}]
	})
});
var $$splitComponentImporter$11 = () => import("./hq-BsGvgTgV.mjs");
var Route$13 = createFileRoute("/hq/")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./achievements-CIiklrmt.mjs");
var Route$12 = createFileRoute("/hq/achievements")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./gallery-bc9NjE1T.mjs");
var Route$11 = createFileRoute("/hq/gallery")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./insights-DgiL1HHY.mjs");
var Route$10 = createFileRoute("/hq/insights")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./match-day-BVRMQXUK.mjs");
var Route$9 = createFileRoute("/hq/match-day")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./matches-ChAODGmr.mjs");
var Route$8 = createFileRoute("/hq/matches")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./players-BCfGFLrC.mjs");
var Route$7 = createFileRoute("/hq/players")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./profile-BScZmuvu.mjs");
var Route$6 = createFileRoute("/hq/profile")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./seasons-BAcA4UQl.mjs");
var Route$5 = createFileRoute("/hq/seasons")({ component: lazyRouteComponent($$splitComponentImporter$3, "component") });
var $$splitComponentImporter$2 = () => import("./settings-B7tSeCrV.mjs");
var Route$4 = createFileRoute("/hq/settings")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./matches._matchId-BIfBwaUb.mjs");
var Route$3 = createFileRoute("/matches/$matchId")({
	loader: ({ params }) => getMatchPage({ data: { id: params.matchId } }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component"),
	head: ({ loaderData }) => ({ meta: [{ title: loaderData?.match ? `vs ${loaderData.match.opponent} — SB THUNDERS` : "Match — SB THUNDERS" }] })
});
var $$splitComponentImporter = () => import("./squad._playerId-CqEmH4DP.mjs");
var Route$2 = createFileRoute("/squad/$playerId")({
	loader: ({ params }) => getPlayerPage({ data: { id: params.playerId } }),
	component: lazyRouteComponent($$splitComponentImporter, "component"),
	head: ({ loaderData }) => ({ meta: [{ title: loaderData?.player ? `${loaderData.player.displayName} — SB THUNDERS` : "Player — SB THUNDERS" }] })
});
var Route$1 = createFileRoute("/api/auth/$")({ server: { handlers: {
	GET: ({ request }) => auth.handler(request),
	POST: ({ request }) => auth.handler(request)
} } });
var Route = createFileRoute("/api/media/$id")({ server: { handlers: { GET: async ({ params }) => {
	try {
		const id = params.id;
		if (!id || !/^[0-9a-f-]{16,}$/i.test(id)) return new Response("Not found", { status: 404 });
		const row = (await (await getSql())`
            select mime_type, data_url from media where id = ${id}
          `)[0];
		if (!row) return new Response("Not found", { status: 404 });
		const comma = row.data_url.indexOf(",");
		if (comma < 0) return new Response("Not found", { status: 404 });
		const buf = Buffer.from(row.data_url.slice(comma + 1), "base64");
		return new Response(buf, { headers: {
			"Content-Type": row.mime_type || "image/jpeg",
			"Cache-Control": "public, max-age=31536000, immutable"
		} });
	} catch {
		return new Response("Not found", { status: 404 });
	}
} } } });
var IndexRoute = Route$22.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$23
});
var AboutRoute = Route$21.update({
	id: "/about",
	path: "/about",
	getParentRoute: () => Route$23
});
var AchievementsRoute = Route$20.update({
	id: "/achievements",
	path: "/achievements",
	getParentRoute: () => Route$23
});
var GalleryRoute = Route$19.update({
	id: "/gallery",
	path: "/gallery",
	getParentRoute: () => Route$23
});
var HqRouteRoute = Route$18.update({
	id: "/hq",
	path: "/hq",
	getParentRoute: () => Route$23
});
var InsightsRoute = Route$17.update({
	id: "/insights",
	path: "/insights",
	getParentRoute: () => Route$23
});
var LoginRoute = Route$16.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$23
});
var MatchesRoute = Route$15.update({
	id: "/matches",
	path: "/matches",
	getParentRoute: () => Route$23
});
var SquadRoute = Route$14.update({
	id: "/squad",
	path: "/squad",
	getParentRoute: () => Route$23
});
var HqIndexRoute = Route$13.update({
	id: "/",
	path: "/",
	getParentRoute: () => HqRouteRoute
});
var HqAchievementsRoute = Route$12.update({
	id: "/achievements",
	path: "/achievements",
	getParentRoute: () => HqRouteRoute
});
var HqGalleryRoute = Route$11.update({
	id: "/gallery",
	path: "/gallery",
	getParentRoute: () => HqRouteRoute
});
var HqInsightsRoute = Route$10.update({
	id: "/insights",
	path: "/insights",
	getParentRoute: () => HqRouteRoute
});
var HqMatchDayRoute = Route$9.update({
	id: "/match-day",
	path: "/match-day",
	getParentRoute: () => HqRouteRoute
});
var HqMatchesRoute = Route$8.update({
	id: "/matches",
	path: "/matches",
	getParentRoute: () => HqRouteRoute
});
var HqPlayersRoute = Route$7.update({
	id: "/players",
	path: "/players",
	getParentRoute: () => HqRouteRoute
});
var HqProfileRoute = Route$6.update({
	id: "/profile",
	path: "/profile",
	getParentRoute: () => HqRouteRoute
});
var HqSeasonsRoute = Route$5.update({
	id: "/seasons",
	path: "/seasons",
	getParentRoute: () => HqRouteRoute
});
var HqSettingsRoute = Route$4.update({
	id: "/settings",
	path: "/settings",
	getParentRoute: () => HqRouteRoute
});
var MatchesMatchIdRoute = Route$3.update({
	id: "/$matchId",
	path: "/$matchId",
	getParentRoute: () => MatchesRoute
});
var SquadPlayerIdRoute = Route$2.update({
	id: "/$playerId",
	path: "/$playerId",
	getParentRoute: () => SquadRoute
});
var ApiAuthSplatRoute = Route$1.update({
	id: "/api/auth/$",
	path: "/api/auth/$",
	getParentRoute: () => Route$23
});
var ApiMediaIdRoute = Route.update({
	id: "/api/media/$id",
	path: "/api/media/$id",
	getParentRoute: () => Route$23
});
var HqRouteRouteChildren = {
	HqAchievementsRoute,
	HqGalleryRoute,
	HqInsightsRoute,
	HqMatchDayRoute,
	HqMatchesRoute,
	HqPlayersRoute,
	HqProfileRoute,
	HqSeasonsRoute,
	HqSettingsRoute,
	HqIndexRoute
};
var HqRouteRouteWithChildren = HqRouteRoute._addFileChildren(HqRouteRouteChildren);
var MatchesRouteChildren = { MatchesMatchIdRoute };
var MatchesRouteWithChildren = MatchesRoute._addFileChildren(MatchesRouteChildren);
var SquadRouteChildren = { SquadPlayerIdRoute };
var rootRouteChildren = {
	IndexRoute,
	HqRouteRoute: HqRouteRouteWithChildren,
	AboutRoute,
	AchievementsRoute,
	GalleryRoute,
	InsightsRoute,
	LoginRoute,
	MatchesRoute: MatchesRouteWithChildren,
	SquadRoute: SquadRoute._addFileChildren(SquadRouteChildren),
	ApiAuthSplatRoute,
	ApiMediaIdRoute
};
var routeTree = Route$23._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function NotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-navy px-6 text-center text-ivory",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.28em] text-thunder",
				children: "404"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-6xl",
				children: "Lost in the storm"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-steel",
				children: "That page is not on the SB THUNDERS site."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				href: "/",
				className: "mt-8 inline-block text-xs uppercase tracking-[0.18em] text-ivory hover:text-thunder",
				children: "Return home"
			})
		] })
	});
}
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent,
		defaultNotFoundComponent: NotFound,
		defaultPreload: "intent",
		scrollRestoration: true
	});
}
//#endregion
export { PUBLIC_NAV as _, Route$15 as a, Route$20 as c, GALLERY_CATEGORIES as d, GALLERY_LABELS as f, PLAYER_ROLES as g, MATCH_STATUSES as h, Route$14 as i, Route$21 as l, MATCH_RESULTS as m, Route$2 as n, Route$17 as o, HQ_NAV as p, Route$3 as r, Route$19 as s, router_exports as t, Route$22 as u, createSsrRpc as v };
