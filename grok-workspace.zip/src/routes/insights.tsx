import { createFileRoute } from "@tanstack/react-router";
import { EmptyState } from "@/components/brand/empty-state";
import { SectionHead } from "@/components/brand/section-head";
import { PublicShell } from "@/components/public/public-shell";
import { SeasonSwitch } from "@/components/public/season-switch";
import { getInsightsPage } from "@/lib/server/public";
import { seasonSearch } from "@/lib/search";

export const Route = createFileRoute("/insights")({
  validateSearch: seasonSearch,
  loaderDeps: ({ search }) => ({ season: search.season }),
  loader: ({ deps }) => getInsightsPage({ data: { season: deps.season } }),
  component: InsightsPage,
  head: () => ({
    meta: [{ title: "Insights — SB THUNDERS" }],
    links: [{ rel: "canonical", href: "https://sbthunders.com/insights" }],
  }),
});

function InsightsPage() {
  const data = Route.useLoaderData();
  const i = data.insights;
  const cells = [
    { label: "Matches", value: i.played ? String(i.played) : "—" },
    { label: "Wins", value: i.played ? String(i.wins) : "—" },
    { label: "Losses", value: i.played ? String(i.losses) : "—" },
    { label: "Win %", value: i.winPct === null ? "—" : `${i.winPct}%` },
    { label: "Highest score", value: i.highestScore === null ? "—" : String(i.highestScore) },
    { label: "Lowest score", value: i.lowestScore === null ? "—" : String(i.lowestScore) },
    { label: "Best individual", value: i.bestIndividualScore === null ? "—" : String(i.bestIndividualScore) },
    {
      label: "Top run scorer",
      value: i.topRunScorer ? `${i.topRunScorer.name} · ${i.topRunScorer.runs}` : "—",
    },
    {
      label: "Top wicket taker",
      value: i.topWicketTaker ? `${i.topWicketTaker.name} · ${i.topWicketTaker.wickets}` : "—",
    },
  ];

  const chart = data.matches
    .filter((m) => m.status === "completed" && m.published)
    .slice()
    .reverse();

  return (
    <PublicShell settings={data.settings}>
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHead
            overline={data.season?.name ?? "Analytics"}
            title="Team insights"
            copy="Every figure on this page is computed from published matches. If a cell is a dash, the data has not been entered yet."
          />
          <SeasonSwitch seasons={data.seasons} current={data.season} path="/insights" />
        </div>
        <div className="mt-12 grid grid-cols-2 gap-3 lg:grid-cols-3">
          {cells.map((c) => (
            <div key={c.label} className="panel p-5">
              <p className="text-[11px] uppercase tracking-[0.18em] text-steel">{c.label}</p>
              <p className="mt-3 font-display text-3xl text-ivory sm:text-4xl">{c.value}</p>
            </div>
          ))}
        </div>
        <h3 className="mt-16 font-display text-4xl text-ivory">Form</h3>
        {chart.length === 0 ? (
          <div className="mt-6">
            <EmptyState title="No form to plot" copy="A result strip appears after published completed matches exist." />
          </div>
        ) : (
          <ol className="mt-6 flex flex-wrap gap-2">
            {chart.map((m) => (
              <li
                key={m.id}
                title={`${m.opponent} — ${m.resultDescription || m.result}`}
                className={`grid h-11 w-11 place-items-center text-xs font-semibold ${
                  m.result === "won" ? "bg-thunder text-ivory" : "border border-white/15 text-steel"
                }`}
              >
                {m.result === "won" ? "W" : m.result === "lost" ? "L" : "·"}
              </li>
            ))}
          </ol>
        )}
      </div>
    </PublicShell>
  );
}
