import { createFileRoute } from "@tanstack/react-router";
import { PublicShell } from "@/components/public/public-shell";
import { isHttpUrl } from "@/lib/utils";
import { getAboutPage } from "@/lib/server/public";

export const Route = createFileRoute("/about")({
  loader: () => getAboutPage(),
  component: AboutPage,
  head: () => ({
    meta: [{ title: "About — SB THUNDERS" }],
    links: [{ rel: "canonical", href: "https://sbthunders.com/about" }],
  }),
});

function Block({ title, body }: { title: string; body: string }) {
  if (!body.trim()) return null;
  return (
    <section className="border-t border-white/10 py-10">
      <h2 className="font-display text-4xl text-ivory">{title}</h2>
      <p className="mt-4 max-w-2xl whitespace-pre-wrap text-sm leading-relaxed text-steel">{body}</p>
    </section>
  );
}

function AboutPage() {
  const { settings: s } = Route.useLoaderData();
  const hasStory = [s.origin, s.story, s.valuesText, s.philosophy, s.milestones, s.culture].some((v) => v.trim());

  return (
    <PublicShell settings={s}>
      <div className="relative overflow-hidden">
        <div className="hero-storm min-h-[42dvh]" />
        <div className="absolute inset-0 bg-gradient-to-t from-navy via-navy/40 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 mx-auto max-w-5xl px-4 pb-12 sm:px-6">
          <p className="text-[11px] uppercase tracking-[0.28em] text-thunder">About</p>
          <h1 className="mt-3 font-display text-6xl leading-[0.9] text-ivory sm:text-8xl">
            This is more than cricket.
          </h1>
        </div>
      </div>
      <div className="mx-auto max-w-5xl px-4 py-16 sm:px-6">
        <p className="max-w-2xl text-lg leading-relaxed text-ivory">{s.tagline}</p>
        <p className="mt-4 max-w-2xl text-sm leading-relaxed text-steel">{s.supportingCopy}</p>
        {s.quoteLine ? (
          <blockquote className="mt-10 border-l-2 border-thunder pl-5 font-display text-3xl text-ivory">
            {s.quoteLine}
          </blockquote>
        ) : null}
        {hasStory ? (
          <>
            <Block title="Origin" body={s.origin} />
            <Block title="Story" body={s.story} />
            <Block title="Values" body={s.valuesText} />
            <Block title="Philosophy" body={s.philosophy} />
            <Block title="Milestones" body={s.milestones} />
            <Block title="Culture" body={s.culture} />
          </>
        ) : (
          <p className="mt-12 max-w-xl text-sm leading-relaxed text-steel">
            The origin, values, and milestones of SB THUNDERS will be written here by the team. Until then, the
            field does the talking.
          </p>
        )}

        <section className="mt-16 grid items-center gap-10 border-t border-white/10 py-12 md:grid-cols-2">
          <img
            src={s.adminPhotoUrl || "/team/ashraf.jpg"}
            alt={s.adminName}
            className="aspect-[4/5] w-full object-cover object-top"
          />
          <div>
            <p className="text-[11px] uppercase tracking-[0.28em] text-thunder">The one behind the Thunders</p>
            <h2 className="mt-3 font-display text-5xl text-ivory">{s.adminName}</h2>
            <p className="mt-2 text-sm uppercase tracking-[0.14em] text-steel">{s.adminRole}</p>
            {s.adminBio ? <p className="mt-4 text-sm leading-relaxed text-steel">{s.adminBio}</p> : null}
            <a href={`mailto:${s.email}`} className="mt-6 inline-block text-ivory hover:text-thunder">
              {s.email}
            </a>
            {isHttpUrl(s.adminDeepDiveUrl) ? (
              <p className="mt-4">
                <a href={s.adminDeepDiveUrl} className="text-sm text-thunder">
                  Deep dive into Admin world →
                </a>
              </p>
            ) : null}
          </div>
        </section>
      </div>
    </PublicShell>
  );
}
