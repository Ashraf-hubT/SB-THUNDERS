import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { g as PLAYER_ROLES } from "./router-BqvUT-Ki.mjs";
import { i as Textarea, n as Input, r as Select, t as Field } from "./field-Cnn-JkFT.mjs";
import { T as setPlayerSeason, i as archivePlayer, m as getHqPlayers, x as savePlayer } from "./hq-DLvonivC.mjs";
import { t as HqShell } from "./hq-shell-dMuZsJhJ.mjs";
import { t as Button } from "./button-CiAG7yUi.mjs";
import { t as ImageField } from "./image-field-DyYab_pI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/players-BCfGFLrC.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var empty = {
	fullName: "",
	displayName: "",
	photoUrl: "",
	battingStyle: "",
	bowlingStyle: "",
	bio: "",
	cricheroesUrl: "",
	instagramUrl: "",
	twitterUrl: "",
	role: "Batter",
	managementTitle: "",
	jerseyNumber: "",
	isCaptain: false,
	isViceCaptain: false
};
function PlayersPage() {
	const qc = useQueryClient();
	const [seasonId, setSeasonId] = (0, import_react.useState)("");
	const q = useQuery({
		queryKey: ["hq-players", seasonId],
		queryFn: () => getHqPlayers({ data: { seasonId: seasonId || void 0 } })
	});
	const [form, setForm] = (0, import_react.useState)(empty);
	const [open, setOpen] = (0, import_react.useState)(false);
	const save = useMutation({
		mutationFn: () => savePlayer({ data: {
			...form,
			seasonId: q.data?.season?.id,
			attachToSeason: true
		} }),
		onSuccess: async () => {
			toast.success("Player saved");
			setOpen(false);
			setForm(empty);
			await qc.invalidateQueries();
		},
		onError: (e) => toast.error(e.message)
	});
	const rosterIds = (0, import_react.useMemo)(() => new Set((q.data?.squad ?? []).map((s) => s.playerId)), [q.data?.squad]);
	function edit(p) {
		const sp = q.data?.squad.find((s) => s.playerId === p.id);
		setForm({
			id: p.id,
			fullName: p.fullName,
			displayName: p.displayName,
			photoUrl: p.photoUrl,
			battingStyle: p.battingStyle,
			bowlingStyle: p.bowlingStyle,
			bio: p.bio,
			cricheroesUrl: p.cricheroesUrl,
			instagramUrl: p.instagramUrl,
			twitterUrl: p.twitterUrl,
			role: sp?.role ?? "Batter",
			managementTitle: sp?.managementTitle ?? "",
			jerseyNumber: sp?.jerseyNumber ?? "",
			isCaptain: Boolean(sp?.isCaptain),
			isViceCaptain: Boolean(sp?.isViceCaptain)
		});
		setOpen(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HqShell, {
		title: "Players",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
					value: q.data?.season?.id ?? seasonId,
					onChange: (e) => setSeasonId(e.target.value),
					className: "max-w-xs",
					children: (q.data?.seasons ?? []).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: s.id,
						children: s.name
					}, s.id))
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					onClick: () => {
						setForm(empty);
						setOpen(true);
					},
					children: "Add player"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-steel",
				children: "Archive instead of deleting. Attach a person to this season with a role — including Management or Player + Management."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 overflow-x-auto",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[640px] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-[11px] uppercase tracking-[0.14em] text-steel",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2",
								children: "Player"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Role" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "#" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { children: "Season" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {})
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: (q.data?.players ?? []).map((p) => {
						const sp = q.data?.squad.find((s) => s.playerId === p.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-white/5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "py-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-ivory",
										children: p.displayName
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-steel",
										children: p.status === "archived" ? "Archived" : p.fullName
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: sp?.role ?? "—" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: sp?.jerseyNumber || "—" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", { children: rosterIds.has(p.id) ? "In squad" : "Not this season" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
									className: "space-x-2 text-right",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											size: "sm",
											variant: "ghost",
											onClick: () => edit(p),
											children: "Edit"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											size: "sm",
											variant: "ghost",
											onClick: async () => {
												await archivePlayer({ data: {
													id: p.id,
													archived: p.status !== "archived"
												} });
												await qc.invalidateQueries();
											},
											children: p.status === "archived" ? "Restore" : "Archive"
										}),
										q.data?.season && rosterIds.has(p.id) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											type: "button",
											size: "sm",
											variant: "ghost",
											onClick: async () => {
												await setPlayerSeason({ data: {
													playerId: p.id,
													seasonId: q.data.season.id,
													role: "Batter",
													remove: true
												} });
												await qc.invalidateQueries();
											},
											children: "Remove season"
										}) : null
									]
								})
							]
						}, p.id);
					}) })]
				}), q.data?.players?.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-sm text-steel",
					children: "No players yet. Add the first Thunder."
				}) : null]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "panel mt-8 grid gap-4 p-5 sm:grid-cols-2",
				onSubmit: (e) => {
					e.preventDefault();
					save.mutate();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Full name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							value: form.fullName,
							onChange: (e) => setForm({
								...form,
								fullName: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Display name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							value: form.displayName,
							onChange: (e) => setForm({
								...form,
								displayName: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageField, {
							label: "Profile photo",
							value: form.photoUrl,
							onChange: (photoUrl) => setForm({
								...form,
								photoUrl
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Role this season",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: form.role,
							onChange: (e) => setForm({
								...form,
								role: e.target.value
							}),
							children: PLAYER_ROLES.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", { children: r }, r))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Jersey number",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: form.jerseyNumber,
							onChange: (e) => setForm({
								...form,
								jerseyNumber: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Management title",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: form.managementTitle,
							onChange: (e) => setForm({
								...form,
								managementTitle: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Batting",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: form.battingStyle,
							onChange: (e) => setForm({
								...form,
								battingStyle: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Bowling",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: form.bowlingStyle,
							onChange: (e) => setForm({
								...form,
								bowlingStyle: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "CricHeroes URL",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: form.cricheroesUrl,
							onChange: (e) => setForm({
								...form,
								cricheroesUrl: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Bio",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: form.bio,
							onChange: (e) => setForm({
								...form,
								bio: e.target.value
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: form.isCaptain,
							onChange: (e) => setForm({
								...form,
								isCaptain: e.target.checked
							})
						}), "Captain"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: form.isViceCaptain,
							onChange: (e) => setForm({
								...form,
								isViceCaptain: e.target.checked
							})
						}), "Vice captain"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: save.isPending,
							children: save.isPending ? "Saving…" : "Save player"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							onClick: () => setOpen(false),
							children: "Cancel"
						})]
					})
				]
			}) : null
		]
	});
}
//#endregion
export { PlayersPage as component };
