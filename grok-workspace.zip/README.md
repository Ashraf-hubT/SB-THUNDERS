# SB THUNDERS — Official Team Portfolio

The official digital home of **SB THUNDERS**.

Public site: [https://sbthunders.com](https://sbthunders.com)

Team email: sbthunders@gmail.com

---

## What this is

A living team portfolio — not a one-off landing page.

Visitors see the **active season**: squad, fixtures, live match status, results, gallery, insights, and achievements.

Ashraf updates everything from **SB THUNDERS HQ** (the private admin). No code edits are required on match day.

---

## Public pages

- Home
- Squad + player profiles
- Matches + match-day centre
- Insights (only from published results)
- Gallery
- Achievements
- About

Empty sections stay honest. The site will not invent player names, statistics, or history.

---

## SB THUNDERS HQ

Sign in at `/login` with Google or email + password.

Only allowlisted administrators can write. The public site is read-only.

HQ includes:

1. Dashboard
2. Season manager
3. Players (add / edit / archive / restore, per-season roles)
4. Today’s match (status, score, XI, player of the match)
5. Matches (draft / publish)
6. Insights
7. Gallery uploads
8. Achievements
9. Website settings
10. Admin profile

### Match-day flow

HQ → Today’s Match → set opponent / time / venue / status → select XI → Save draft or Save & publish.

Statuses: **Upcoming → Live → Completed**.

### Seasons

Players, roles, matches, and media belong to a season. Switch the active season without rebuilding the site. A person can be a player in one year and management in another — or both.

### Historical 2025–26 results

Eleven reference fixtures are stored as **unpublished drafts**. Review them in HQ and publish only after you confirm them. They are not shown as official records until then.

---

## Brand

Navy, thunder red, ivory, steel. Official shield logo. Lightning atmosphere on the hero — not a pasted poster.

---

## Notes for deployment

Intended public URL: **https://sbthunders.com**

Database, authentication, and media storage are provisioned with the app. Secrets stay on the server — never in the browser.
