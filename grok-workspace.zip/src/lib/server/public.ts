import { createServerFn } from "@tanstack/react-start";
import { EMPTY_HOME, EMPTY_INSIGHTS } from "@/lib/defaults";
import type { HomePayload } from "@/lib/types";
import { getSql } from "@/lib/db";
import {
  fetchAchievements,
  fetchGallery,
  fetchInsights,
  fetchMatch,
  fetchMatchSquad,
  fetchMatches,
  fetchPlayer,
  fetchPlayerSeasons,
  fetchSeasonBySlugOrActive,
  fetchSeasons,
  fetchSettings,
  fetchSquad,
  pickFeaturedMatch,
} from "./repo";
import { mapSeason } from "./map";

async function safe<T>(fn: () => Promise<T>, fallback: T): Promise<T> {
  try {
    return await fn();
  } catch (err) {
    console.error("[public]", err);
    return fallback;
  }
}

export const getSiteSettings = createServerFn({ method: "GET" }).handler(async () =>
  safe(() => fetchSettings(), EMPTY_HOME.settings),
);

export const getSeasonsPublic = createServerFn({ method: "GET" }).handler(async () =>
  safe(() => fetchSeasons(), []),
);

export const getHomeData = createServerFn({ method: "GET" }).handler(async (): Promise<HomePayload> => {
  return safe(async () => {
    const settings = await fetchSettings();
    const seasons = await fetchSeasons();
    const activeSeason = seasons.find((s) => s.isActive) ?? seasons[0] ?? null;
    if (!activeSeason) return { ...EMPTY_HOME, settings, seasons };

    const [squad, matches, gallery, achievements, insights] = await Promise.all([
      fetchSquad(activeSeason.id),
      fetchMatches(activeSeason.id, { publishedOnly: true }),
      fetchGallery(activeSeason.id, { publishedOnly: true, limit: 8 }),
      fetchAchievements(activeSeason.id, { publishedOnly: true }),
      fetchInsights(activeSeason.id),
    ]);
    const { featured, next, recent } = pickFeaturedMatch(matches);
    const todaysSquad = featured ? await fetchMatchSquad(featured.id) : [];
    const sql = await getSql();
    const announcements = await sql<{
      id: string;
      title: string;
      body: string;
      published: boolean;
      pinned: boolean;
      created_at: string;
    }>`
      select id, title, body, published, pinned, created_at
      from announcements
      where published = true
      order by pinned desc, created_at desc
      limit 3
    `;

    return {
      settings,
      seasons,
      activeSeason,
      featuredMatch: featured,
      nextMatch: next,
      recentMatch: recent,
      todaysSquad,
      squad,
      insights,
      gallery,
      achievements,
      recentMatches: matches.filter((m) => m.status === "completed").slice(0, 6),
      announcements: announcements.map((a) => ({
        id: a.id,
        title: a.title,
        body: a.body,
        published: a.published,
        pinned: a.pinned,
        createdAt: String(a.created_at),
      })),
    };
  }, EMPTY_HOME);
});

export const getSquadPage = createServerFn({ method: "GET" })
  .validator((data: { season?: string }) => data)
  .handler(async ({ data }) => {
    return safe(async () => {
      const settings = await fetchSettings();
      const seasons = await fetchSeasons();
      const season = await fetchSeasonBySlugOrActive(data.season);
      const squad = season ? await fetchSquad(season.id) : [];
      return { settings, seasons, season, squad };
    }, { settings: EMPTY_HOME.settings, seasons: [], season: null, squad: [] });
  });

export const getPlayerPage = createServerFn({ method: "GET" })
  .validator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    return safe(async () => {
      const settings = await fetchSettings();
      const player = await fetchPlayer(data.id);
      if (!player || player.status === "archived") {
        return { settings, player: null, seasons: [] as Awaited<ReturnType<typeof fetchPlayerSeasons>>, appearances: [] as { match: Awaited<ReturnType<typeof fetchMatch>>; runs: number | null; wickets: number | null }[] };
      }
      const seasons = await fetchPlayerSeasons(player.id);
      const sql = await getSql();
      const stats = await sql<Record<string, unknown>>`
        select s.*, m.opponent, m.match_date, m.result, m.published, m.status
        from player_match_stats s
        join matches m on m.id = s.match_id
        where s.player_id = ${player.id} and m.published = true
        order by m.match_date desc nulls last
      `;
      const appearances = stats.map((row) => ({
        matchId: String(row.match_id),
        opponent: String(row.opponent ?? ""),
        matchDate: row.match_date ? String(row.match_date) : null,
        result: String(row.result ?? ""),
        runs: row.runs === null || row.runs === undefined ? null : Number(row.runs),
        wickets: row.wickets === null || row.wickets === undefined ? null : Number(row.wickets),
      }));
      return { settings, player, seasons, appearances };
    }, { settings: EMPTY_HOME.settings, player: null, seasons: [], appearances: [] });
  });

export const getMatchesPage = createServerFn({ method: "GET" })
  .validator((data: { season?: string }) => data)
  .handler(async ({ data }) => {
    return safe(async () => {
      const settings = await fetchSettings();
      const seasons = await fetchSeasons();
      const season = await fetchSeasonBySlugOrActive(data.season);
      const matches = season ? await fetchMatches(season.id, { publishedOnly: true }) : [];
      const { featured, next, recent } = pickFeaturedMatch(matches);
      return { settings, seasons, season, matches, featured, next, recent };
    }, {
      settings: EMPTY_HOME.settings,
      seasons: [],
      season: null,
      matches: [],
      featured: null,
      next: null,
      recent: null,
    });
  });

export const getMatchPage = createServerFn({ method: "GET" })
  .validator((data: { id: string }) => data)
  .handler(async ({ data }) => {
    return safe(async () => {
      const settings = await fetchSettings();
      const match = await fetchMatch(data.id);
      if (!match || !match.published) return { settings, match: null, squad: [], season: null };
      const squad = await fetchMatchSquad(match.id);
      const sql = await getSql();
      const seasonRows = await sql<Record<string, unknown>>`select * from seasons where id = ${match.seasonId}`;
      return { settings, match, squad, season: seasonRows[0] ? mapSeason(seasonRows[0]) : null };
    }, { settings: EMPTY_HOME.settings, match: null, squad: [], season: null });
  });

export const getInsightsPage = createServerFn({ method: "GET" })
  .validator((data: { season?: string }) => data)
  .handler(async ({ data }) => {
    return safe(async () => {
      const settings = await fetchSettings();
      const seasons = await fetchSeasons();
      const season = await fetchSeasonBySlugOrActive(data.season);
      const insights = season ? await fetchInsights(season.id) : EMPTY_INSIGHTS;
      const matches = season ? await fetchMatches(season.id, { publishedOnly: true }) : [];
      return { settings, seasons, season, insights, matches };
    }, {
      settings: EMPTY_HOME.settings,
      seasons: [],
      season: null,
      insights: EMPTY_INSIGHTS,
      matches: [],
    });
  });

export const getGalleryPage = createServerFn({ method: "GET" })
  .validator((data: { season?: string }) => data)
  .handler(async ({ data }) => {
    return safe(async () => {
      const settings = await fetchSettings();
      const seasons = await fetchSeasons();
      const season = await fetchSeasonBySlugOrActive(data.season);
      const items = await fetchGallery(season?.id ?? null, { publishedOnly: true });
      return { settings, seasons, season, items };
    }, { settings: EMPTY_HOME.settings, seasons: [], season: null, items: [] });
  });

export const getAchievementsPage = createServerFn({ method: "GET" })
  .validator((data: { season?: string }) => data)
  .handler(async ({ data }) => {
    return safe(async () => {
      const settings = await fetchSettings();
      const seasons = await fetchSeasons();
      const season = await fetchSeasonBySlugOrActive(data.season);
      const items = await fetchAchievements(season?.id ?? null, { publishedOnly: true });
      return { settings, seasons, season, items };
    }, { settings: EMPTY_HOME.settings, seasons: [], season: null, items: [] });
  });

export const getAboutPage = createServerFn({ method: "GET" }).handler(async () =>
  safe(async () => {
    const settings = await fetchSettings();
    return { settings };
  }, { settings: EMPTY_HOME.settings }),
);
