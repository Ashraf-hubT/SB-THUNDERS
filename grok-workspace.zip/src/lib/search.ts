export type SeasonSearch = { season?: string };

export function seasonSearch(s: Record<string, unknown>): SeasonSearch {
  return { season: typeof s.season === "string" ? s.season : undefined };
}
