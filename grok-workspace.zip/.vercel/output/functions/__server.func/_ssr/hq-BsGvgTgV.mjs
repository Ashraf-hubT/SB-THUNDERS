import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime, n as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { l as getHqDashboard } from "./hq-DLvonivC.mjs";
import { t as HqShell } from "./hq-shell-dMuZsJhJ.mjs";
import { t as Button } from "./button-CiAG7yUi.mjs";
import { n as StatusPill } from "./status-pill-BO5B8Jkq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/hq-BsGvgTgV.js
var import_jsx_runtime = require_jsx_runtime();
function HqHome() {
	const q = useQuery({
		queryKey: ["hq-dashboard"],
		queryFn: () => getHqDashboard()
	});
	const d = q.data;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HqShell, {
		title: "Dashboard",
		children: q.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-steel",
			children: "Loading HQ…"
		}) : q.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-thunder",
			children: "Could not load dashboard."
		}) : d ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Active season",
						value: d.active?.name ?? "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Players",
						value: String(d.squadCount)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Matches played",
						value: d.insights.played ? String(d.insights.played) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
						label: "Win %",
						value: d.insights.winPct === null ? "—" : `${d.insights.winPct}%`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "panel p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] uppercase tracking-[0.18em] text-steel",
								children: "Today / next match"
							}), d.featured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: d.featured.status }) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-display text-4xl text-ivory",
							children: d.featured?.opponent || d.next?.opponent || "No fixture set"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-steel",
							children: d.featured?.venue || d.next?.venue || "Set opponent, time, and venue from Match Day."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/hq/match-day",
									children: "Open match day"
								})
							})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "panel p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] uppercase tracking-[0.18em] text-steel",
							children: "Recent result"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-4 font-display text-4xl text-ivory",
							children: d.recent?.opponent ?? "No published result"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-steel",
							children: d.recent?.resultDescription || (d.draftMatches ? `${d.draftMatches} draft matches waiting` : "—")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "outline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/hq/matches",
									children: "Matches"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "ghost",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/hq/gallery",
									children: "Gallery"
								})
							})]
						})
					]
				})]
			}),
			d.gallery.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.18em] text-steel",
					children: "Latest uploads"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid grid-cols-3 gap-2 sm:grid-cols-6",
					children: d.gallery.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: g.imageUrl,
						alt: "",
						className: "aspect-square object-cover"
					}, g.id))
				})]
			}) : null
		] }) : null
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] uppercase tracking-[0.16em] text-steel",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 font-display text-3xl text-ivory",
			children: value
		})]
	});
}
//#endregion
export { HqHome as component };
