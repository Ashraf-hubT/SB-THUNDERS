//#region node_modules/.nitro/vite/services/ssr/assets/image-BpjZNsak.js
var MAX_CHARS = 12e5;
async function compressImage(file, maxEdge = 1600, quality = .82) {
	if (!file.type.startsWith("image/")) throw new Error("Please choose an image file.");
	const bitmap = await createImageBitmap(file);
	const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height));
	const w = Math.max(1, Math.round(bitmap.width * scale));
	const h = Math.max(1, Math.round(bitmap.height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = w;
	canvas.height = h;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Could not process image.");
	ctx.drawImage(bitmap, 0, 0, w, h);
	let q = quality;
	let out = canvas.toDataURL("image/jpeg", q);
	while (out.length > MAX_CHARS && q > .5) {
		q -= .08;
		out = canvas.toDataURL("image/jpeg", q);
	}
	if (out.length > MAX_CHARS) throw new Error("Image is still too large. Try a smaller photo.");
	return out;
}
//#endregion
export { compressImage as t };
