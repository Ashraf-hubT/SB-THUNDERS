import { X } from "lucide-react";
import { useEffect } from "react";
import type { GalleryItem } from "@/lib/types";

export function Lightbox({
  items,
  index,
  onClose,
  onMove,
}: {
  items: GalleryItem[];
  index: number;
  onClose: () => void;
  onMove: (next: number) => void;
}) {
  const item = items[index];
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") onMove((index + 1) % items.length);
      if (e.key === "ArrowLeft") onMove((index - 1 + items.length) % items.length);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [index, items.length, onClose, onMove]);

  if (!item) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink/95 p-4"
      role="dialog"
      aria-modal="true"
      aria-label={item.title || "Gallery image"}
    >
      <button
        type="button"
        className="absolute right-4 top-4 inline-flex h-11 w-11 items-center justify-center text-ivory"
        onClick={onClose}
        aria-label="Close"
      >
        <X className="h-6 w-6" />
      </button>
      <img
        src={item.imageUrl}
        alt={item.altText || item.title || "SB Thunders gallery"}
        className="max-h-[82dvh] max-w-full object-contain"
      />
      {items.length > 1 ? (
        <div className="absolute inset-x-0 bottom-6 flex justify-center gap-3">
          <button
            type="button"
            className="h-11 px-4 text-xs uppercase tracking-[0.18em] text-steel hover:text-ivory"
            onClick={() => onMove((index - 1 + items.length) % items.length)}
          >
            Previous
          </button>
          <button
            type="button"
            className="h-11 px-4 text-xs uppercase tracking-[0.18em] text-steel hover:text-ivory"
            onClick={() => onMove((index + 1) % items.length)}
          >
            Next
          </button>
        </div>
      ) : null}
    </div>
  );
}
