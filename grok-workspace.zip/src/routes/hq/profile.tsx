import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { HqShell } from "@/components/hq/hq-shell";
import { ImageField } from "@/components/hq/image-field";
import { Button } from "@/components/ui/button";
import { Field, Input, Textarea } from "@/components/ui/field";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { getHqSettings, saveSettings } from "@/lib/server/hq";

export const Route = createFileRoute("/hq/profile")({ component: ProfileHq });

function ProfileHq() {
  const user = useCurrentUser();
  const q = useQuery({ queryKey: ["hq-settings"], queryFn: () => getHqSettings() });
  const [adminName, setAdminName] = useState("Ashraf");
  const [adminRole, setAdminRole] = useState("Team / Website Administrator");
  const [adminPhotoUrl, setAdminPhotoUrl] = useState("/team/ashraf.jpg");
  const [adminBio, setAdminBio] = useState("");
  const [adminDeepDiveUrl, setAdminDeepDiveUrl] = useState("");

  useEffect(() => {
    const s = q.data?.settings;
    if (!s) return;
    setAdminName(s.adminName);
    setAdminRole(s.adminRole);
    setAdminPhotoUrl(s.adminPhotoUrl);
    setAdminBio(s.adminBio);
    setAdminDeepDiveUrl(s.adminDeepDiveUrl);
  }, [q.data]);

  const save = useMutation({
    mutationFn: () => {
      const s = q.data?.settings;
      if (!s) throw new Error("Settings not loaded");
      return saveSettings({
        data: {
          teamName: s.teamName,
          tagline: s.tagline,
          supportingCopy: s.supportingCopy,
          heroLine1: s.heroLine1,
          heroLine2: s.heroLine2,
          quoteLine: s.quoteLine,
          story: s.story,
          origin: s.origin,
          valuesText: s.valuesText,
          philosophy: s.philosophy,
          milestones: s.milestones,
          culture: s.culture,
          email: s.email,
          instagramUrl: s.instagramUrl,
          twitterUrl: s.twitterUrl,
          facebookUrl: s.facebookUrl,
          youtubeUrl: s.youtubeUrl,
          whatsappUrl: s.whatsappUrl,
          cricheroesTeamUrl: s.cricheroesTeamUrl,
          adminName,
          adminRole,
          adminPhotoUrl,
          adminBio,
          adminDeepDiveUrl,
          logoUrl: s.logoUrl,
          seoTitle: s.seoTitle,
          seoDescription: s.seoDescription,
        },
      });
    },
    onSuccess: () => toast.success("Profile updated"),
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <HqShell title="Admin profile">
      <div className="panel mb-6 p-4">
        <p className="text-[11px] uppercase tracking-[0.16em] text-steel">Signed in</p>
        <p className="mt-2 text-ivory">{user?.displayName ?? "Administrator"}</p>
        <p className="text-sm text-steel">{user?.primaryEmail}</p>
        <div className="mt-4">
          <UserButton />
        </div>
      </div>
      <form
        className="grid gap-4"
        onSubmit={(e) => {
          e.preventDefault();
          save.mutate();
        }}
      >
        <Field label="Public name">
          <Input value={adminName} onChange={(e) => setAdminName(e.target.value)} />
        </Field>
        <Field label="Public role">
          <Input value={adminRole} onChange={(e) => setAdminRole(e.target.value)} />
        </Field>
        <ImageField label="Public photo" value={adminPhotoUrl} onChange={setAdminPhotoUrl} />
        <Field label="Bio">
          <Textarea value={adminBio} onChange={(e) => setAdminBio(e.target.value)} />
        </Field>
        <Field label="Deep dive URL (optional)">
          <Input value={adminDeepDiveUrl} onChange={(e) => setAdminDeepDiveUrl(e.target.value)} placeholder="Leave empty until ready" />
        </Field>
        <Button type="submit" disabled={save.isPending}>
          Save public admin section
        </Button>
      </form>
    </HqShell>
  );
}
