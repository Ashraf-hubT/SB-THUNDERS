export const SITE_URL = "https://sbthunders.com";
export const SITE_TITLE = "SB THUNDERS — Official Team Portfolio";
export const TEAM_EMAIL = "sbthunders@gmail.com";

export const PLAYER_ROLES = [
  "Batter",
  "Bowler",
  "All-Rounder",
  "Wicket Keeper",
  "Management",
  "Player + Management",
] as const;

export type PlayerRole = (typeof PLAYER_ROLES)[number];

export const MATCH_STATUSES = ["upcoming", "live", "completed"] as const;
export type MatchStatus = (typeof MATCH_STATUSES)[number];

export const MATCH_RESULTS = ["", "won", "lost", "draw", "tie", "no_result", "abandoned"] as const;
export type MatchResult = (typeof MATCH_RESULTS)[number];

export const GALLERY_CATEGORIES = [
  "squad",
  "match_day",
  "victories",
  "training",
  "moments",
  "graphics",
  "other",
] as const;
export type GalleryCategory = (typeof GALLERY_CATEGORIES)[number];

export const GALLERY_LABELS: Record<GalleryCategory, string> = {
  squad: "Squad",
  match_day: "Match Day",
  victories: "Victories",
  training: "Training",
  moments: "Moments",
  graphics: "Graphics",
  other: "Other",
};

export const PLAYER_STATUS = ["active", "archived"] as const;

export const PUBLIC_NAV = [
  { to: "/", label: "Home" },
  { to: "/squad", label: "Squad" },
  { to: "/matches", label: "Matches" },
  { to: "/insights", label: "Insights" },
  { to: "/gallery", label: "Gallery" },
  { to: "/achievements", label: "Achievements" },
  { to: "/about", label: "About" },
] as const;

export const HQ_NAV = [
  { to: "/hq", label: "Dashboard", icon: "layout" },
  { to: "/hq/seasons", label: "Seasons", icon: "calendar" },
  { to: "/hq/players", label: "Players", icon: "users" },
  { to: "/hq/match-day", label: "Today's Match", icon: "zap" },
  { to: "/hq/matches", label: "Matches", icon: "list" },
  { to: "/hq/insights", label: "Insights", icon: "chart" },
  { to: "/hq/gallery", label: "Gallery", icon: "image" },
  { to: "/hq/achievements", label: "Achievements", icon: "trophy" },
  { to: "/hq/settings", label: "Settings", icon: "settings" },
  { to: "/hq/profile", label: "Admin Profile", icon: "user" },
] as const;
