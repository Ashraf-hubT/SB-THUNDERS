import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Input, r as Select, t as Field } from "./field-Cnn-JkFT.mjs";
import { p as getHqMatches, y as saveMatch } from "./hq-DLvonivC.mjs";
import { t as HqShell } from "./hq-shell-dMuZsJhJ.mjs";
import { t as Button } from "./button-CiAG7yUi.mjs";
import { n as StatusPill } from "./status-pill-BO5B8Jkq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/matches-ChAODGmr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MatchesHq() {
	const qc = useQueryClient();
	const [seasonId, setSeasonId] = (0, import_react.useState)("");
	const q = useQuery({
		queryKey: ["hq-matches", seasonId],
		queryFn: () => getHqMatches({ data: { seasonId: seasonId || void 0 } })
	});
	const [opponent, setOpponent] = (0, import_react.useState)("");
	const publish = useMutation({
		mutationFn: (m) => saveMatch({ data: {
			id: m.id,
			seasonId: m.seasonId,
			opponent: m.opponent,
			status: m.status,
			published: m.published
		} }),
		onSuccess: async () => {
			toast.success("Updated");
			await qc.invalidateQueries();
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HqShell, {
		title: "Matches",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Season",
					className: "min-w-48",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						value: q.data?.season?.id ?? seasonId,
						onChange: (e) => setSeasonId(e.target.value),
						children: (q.data?.seasons ?? []).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s.id,
							children: s.name
						}, s.id))
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "flex min-w-0 flex-1 flex-wrap gap-2",
					onSubmit: async (e) => {
						e.preventDefault();
						if (!q.data?.season || !opponent.trim()) return;
						await saveMatch({ data: {
							seasonId: q.data.season.id,
							opponent: opponent.trim(),
							status: "upcoming",
							published: false
						} });
						setOpponent("");
						toast.success("Draft match created");
						await qc.invalidateQueries();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						className: "min-w-40 flex-1",
						placeholder: "New opponent",
						value: opponent,
						onChange: (e) => setOpponent(e.target.value)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Add draft"
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-steel",
				children: "Historical 2025–26 fixtures are stored as unpublished drafts. Review and publish only after you confirm them."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 divide-y divide-white/5 border border-white/10",
				children: (q.data?.matches ?? []).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex flex-wrap items-center justify-between gap-3 px-4 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-ivory",
						children: m.opponent || "Untitled"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-steel",
						children: [
							m.matchDate || "No date",
							" · ",
							m.published ? "Published" : "Draft",
							m.sourceNote ? ` · ${m.sourceNote}` : ""
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: m.status }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "sm",
								variant: "ghost",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/hq/match-day",
									children: "Edit in match day"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								size: "sm",
								variant: "outline",
								onClick: () => publish.mutate({
									id: m.id,
									published: !m.published,
									seasonId: m.seasonId,
									opponent: m.opponent,
									status: m.status
								}),
								children: m.published ? "Unpublish" : "Publish"
							})
						]
					})]
				}, m.id))
			})
		]
	});
}
//#endregion
export { MatchesHq as component };
