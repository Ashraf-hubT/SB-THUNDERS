import { n as isHttpUrl } from "./utils-4Kkadyjj.mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { l as Route$21 } from "./router-BqvUT-Ki.mjs";
import { t as PublicShell } from "./public-shell-BOyI-Zlg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-DQSDq6Nh.js
var import_jsx_runtime = require_jsx_runtime();
function Block({ title, body }) {
	if (!body.trim()) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "border-t border-white/10 py-10",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-4xl text-ivory",
			children: title
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4 max-w-2xl whitespace-pre-wrap text-sm leading-relaxed text-steel",
			children: body
		})]
	});
}
function AboutPage() {
	const { settings: s } = Route$21.useLoaderData();
	const hasStory = [
		s.origin,
		s.story,
		s.valuesText,
		s.philosophy,
		s.milestones,
		s.culture
	].some((v) => v.trim());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PublicShell, {
		settings: s,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative overflow-hidden",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hero-storm min-h-[42dvh]" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-gradient-to-t from-navy via-navy/40 to-transparent" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-x-0 bottom-0 mx-auto max-w-5xl px-4 pb-12 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.28em] text-thunder",
						children: "About"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-6xl leading-[0.9] text-ivory sm:text-8xl",
						children: "This is more than cricket."
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl px-4 py-16 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "max-w-2xl text-lg leading-relaxed text-ivory",
					children: s.tagline
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 max-w-2xl text-sm leading-relaxed text-steel",
					children: s.supportingCopy
				}),
				s.quoteLine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("blockquote", {
					className: "mt-10 border-l-2 border-thunder pl-5 font-display text-3xl text-ivory",
					children: s.quoteLine
				}) : null,
				hasStory ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: "Origin",
						body: s.origin
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: "Story",
						body: s.story
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: "Values",
						body: s.valuesText
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: "Philosophy",
						body: s.philosophy
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: "Milestones",
						body: s.milestones
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: "Culture",
						body: s.culture
					})
				] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-12 max-w-xl text-sm leading-relaxed text-steel",
					children: "The origin, values, and milestones of SB THUNDERS will be written here by the team. Until then, the field does the talking."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-16 grid items-center gap-10 border-t border-white/10 py-12 md:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: s.adminPhotoUrl || "/team/ashraf.jpg",
						alt: s.adminName,
						className: "aspect-[4/5] w-full object-cover object-top"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] uppercase tracking-[0.28em] text-thunder",
							children: "The one behind the Thunders"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-5xl text-ivory",
							children: s.adminName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm uppercase tracking-[0.14em] text-steel",
							children: s.adminRole
						}),
						s.adminBio ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-sm leading-relaxed text-steel",
							children: s.adminBio
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: `mailto:${s.email}`,
							className: "mt-6 inline-block text-ivory hover:text-thunder",
							children: s.email
						}),
						isHttpUrl(s.adminDeepDiveUrl) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: s.adminDeepDiveUrl,
								className: "text-sm text-thunder",
								children: "Deep dive into Admin world →"
							})
						}) : null
					] })]
				})
			]
		})]
	});
}
//#endregion
export { AboutPage as component };
