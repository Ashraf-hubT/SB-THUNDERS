import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { HqShell } from "@/components/hq/hq-shell";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/field";
import { StatusPill } from "@/components/brand/status-pill";
import { getHqMatches, saveMatch } from "@/lib/server/hq";

export const Route = createFileRoute("/hq/matches")({ component: MatchesHq });

function MatchesHq() {
  const qc = useQueryClient();
  const [seasonId, setSeasonId] = useState("");
  const q = useQuery({
    queryKey: ["hq-matches", seasonId],
    queryFn: () => getHqMatches({ data: { seasonId: seasonId || undefined } }),
  });
  const [opponent, setOpponent] = useState("");
  const publish = useMutation({
    mutationFn: (m: { id: string; published: boolean; seasonId: string; opponent: string; status: string }) =>
      saveMatch({
        data: {
          id: m.id,
          seasonId: m.seasonId,
          opponent: m.opponent,
          status: m.status,
          published: m.published,
        },
      }),
    onSuccess: async () => {
      toast.success("Updated");
      await qc.invalidateQueries();
    },
  });

  return (
    <HqShell title="Matches">
      <div className="flex flex-wrap items-end gap-3">
        <Field label="Season" className="min-w-48">
          <Select value={q.data?.season?.id ?? seasonId} onChange={(e) => setSeasonId(e.target.value)}>
            {(q.data?.seasons ?? []).map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </Select>
        </Field>
        <form
          className="flex min-w-0 flex-1 flex-wrap gap-2"
          onSubmit={async (e) => {
            e.preventDefault();
            if (!q.data?.season || !opponent.trim()) return;
            await saveMatch({
              data: { seasonId: q.data.season.id, opponent: opponent.trim(), status: "upcoming", published: false },
            });
            setOpponent("");
            toast.success("Draft match created");
            await qc.invalidateQueries();
          }}
        >
          <Input className="min-w-40 flex-1" placeholder="New opponent" value={opponent} onChange={(e) => setOpponent(e.target.value)} />
          <Button type="submit">Add draft</Button>
        </form>
      </div>
      <p className="mt-3 text-sm text-steel">
        Historical 2025–26 fixtures are stored as unpublished drafts. Review and publish only after you confirm them.
      </p>
      <ul className="mt-6 divide-y divide-white/5 border border-white/10">
        {(q.data?.matches ?? []).map((m) => (
          <li key={m.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-4">
            <div>
              <p className="text-ivory">{m.opponent || "Untitled"}</p>
              <p className="text-xs text-steel">
                {m.matchDate || "No date"} · {m.published ? "Published" : "Draft"}
                {m.sourceNote ? ` · ${m.sourceNote}` : ""}
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <StatusPill status={m.status} />
              <Button asChild size="sm" variant="ghost">
                <Link to="/hq/match-day">Edit in match day</Link>
              </Button>
              <Button
                type="button"
                size="sm"
                variant="outline"
                onClick={() =>
                  publish.mutate({
                    id: m.id,
                    published: !m.published,
                    seasonId: m.seasonId,
                    opponent: m.opponent,
                    status: m.status,
                  })
                }
              >
                {m.published ? "Unpublish" : "Publish"}
              </Button>
            </div>
          </li>
        ))}
      </ul>
    </HqShell>
  );
}
