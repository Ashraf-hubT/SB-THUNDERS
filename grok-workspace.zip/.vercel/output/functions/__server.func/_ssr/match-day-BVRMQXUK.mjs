import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { h as MATCH_STATUSES, m as MATCH_RESULTS } from "./router-BqvUT-Ki.mjs";
import { i as Textarea, n as Input, r as Select, t as Field } from "./field-Cnn-JkFT.mjs";
import { f as getHqMatchDay, y as saveMatch } from "./hq-DLvonivC.mjs";
import { t as HqShell } from "./hq-shell-dMuZsJhJ.mjs";
import { t as Button } from "./button-CiAG7yUi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/match-day-BVRMQXUK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MatchDayPage() {
	const qc = useQueryClient();
	const q = useQuery({
		queryKey: ["hq-match-day"],
		queryFn: () => getHqMatchDay()
	});
	const [matchId, setMatchId] = (0, import_react.useState)("");
	const [opponent, setOpponent] = (0, import_react.useState)("");
	const [venue, setVenue] = (0, import_react.useState)("");
	const [matchDate, setMatchDate] = (0, import_react.useState)("");
	const [matchTime, setMatchTime] = (0, import_react.useState)("");
	const [status, setStatus] = (0, import_react.useState)("upcoming");
	const [ourScore, setOurScore] = (0, import_react.useState)("");
	const [oppScore, setOppScore] = (0, import_react.useState)("");
	const [result, setResult] = (0, import_react.useState)("");
	const [resultDescription, setResultDescription] = (0, import_react.useState)("");
	const [pom, setPom] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [cricheroesUrl, setCricheroesUrl] = (0, import_react.useState)("");
	const [squadIds, setSquadIds] = (0, import_react.useState)([]);
	const [published, setPublished] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		if (!q.data) return;
		const current = q.data.matches.find((m) => m.id === matchId) ?? q.data.current;
		if (!current) return;
		setMatchId(current.id);
		setOpponent(current.opponent);
		setVenue(current.venue);
		setMatchDate(current.matchDate ?? "");
		setMatchTime(current.matchTime);
		setStatus(current.status);
		setOurScore(current.ourScoreText);
		setOppScore(current.oppScoreText);
		setResult(current.result);
		setResultDescription(current.resultDescription);
		setPom(current.playerOfMatchId ?? "");
		setNotes(current.notes);
		setCricheroesUrl(current.cricheroesUrl);
		setPublished(current.published);
		setSquadIds(q.data.current?.id === current.id ? q.data.selected : squadIds);
	}, [q.data, matchId]);
	const save = useMutation({
		mutationFn: (publish) => saveMatch({ data: {
			id: matchId || void 0,
			seasonId: q.data.active.id,
			opponent,
			venue,
			matchDate: matchDate || null,
			matchTime,
			status,
			isFeatured: true,
			published: publish,
			ourScoreText: ourScore,
			oppScoreText: oppScore,
			result,
			resultDescription,
			playerOfMatchId: pom || null,
			notes,
			cricheroesUrl,
			squadIds
		} }),
		onSuccess: async () => {
			toast.success("Match day updated");
			await qc.invalidateQueries();
		},
		onError: (e) => toast.error(e.message)
	});
	const roster = q.data?.roster ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HqShell, {
		title: "Today's match",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-xl text-sm text-steel",
				children: "Built for a phone. Update opponent, status, score, and today's XI, then publish."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Fixture",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: matchId,
						onChange: (e) => setMatchId(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "New match"
						}), (q.data?.matches ?? []).map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
							value: m.id,
							children: [
								m.opponent || "Untitled",
								" · ",
								m.status,
								" ",
								m.published ? "" : "(draft)"
							]
						}, m.id))]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-6 grid gap-4",
				onSubmit: (e) => {
					e.preventDefault();
					save.mutate(published);
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Opponent",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							required: true,
							value: opponent,
							onChange: (e) => setOpponent(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Date",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "date",
								value: matchDate,
								onChange: (e) => setMatchDate(e.target.value)
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Time",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: matchTime,
								onChange: (e) => setMatchTime(e.target.value),
								placeholder: "4:00 PM"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Venue",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: venue,
							onChange: (e) => setVenue(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Status",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: status,
							onChange: (e) => setStatus(e.target.value),
							children: MATCH_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: s,
								children: s
							}, s))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "SB Thunders score",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: ourScore,
								onChange: (e) => setOurScore(e.target.value),
								placeholder: "145/7 (20)"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Opponent score",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: oppScore,
								onChange: (e) => setOppScore(e.target.value)
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Result",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							value: result,
							onChange: (e) => setResult(e.target.value),
							children: MATCH_RESULTS.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: r,
								children: r || "Not set"
							}, r || "none"))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Result description",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: resultDescription,
							onChange: (e) => setResultDescription(e.target.value),
							placeholder: "Won by 8 wickets"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Player of the match",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: pom,
							onChange: (e) => setPom(e.target.value),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "",
								children: "Not set"
							}), roster.map((sp) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: sp.playerId,
								children: sp.player.displayName
							}, sp.playerId))]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "CricHeroes match URL",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: cricheroesUrl,
							onChange: (e) => setCricheroesUrl(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Notes",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: notes,
							onChange: (e) => setNotes(e.target.value)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mb-2 text-[11px] uppercase tracking-[0.16em] text-steel",
						children: "Today's squad"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "divide-y divide-white/5 border border-white/10",
						children: roster.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "px-3 py-4 text-sm text-steel",
							children: "Add players to this season first."
						}) : roster.map((sp) => {
							const on = squadIds.includes(sp.playerId);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex min-h-12 items-center gap-3 px-3 text-sm",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: on,
										onChange: () => setSquadIds((ids) => on ? ids.filter((id) => id !== sp.playerId) : [...ids, sp.playerId])
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex-1 text-ivory",
										children: sp.player.displayName
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-[10px] uppercase tracking-[0.12em] text-steel",
										children: sp.role
									})
								]
							}) }, sp.playerId);
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							type: "checkbox",
							checked: published,
							onChange: (e) => setPublished(e.target.checked)
						}), "Published on the public site"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 sm:flex-row",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "outline",
							disabled: save.isPending,
							onClick: () => save.mutate(false),
							children: "Save draft"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							disabled: save.isPending,
							onClick: () => save.mutate(true),
							children: save.isPending ? "Saving…" : "Save & publish"
						})]
					})
				]
			})
		]
	});
}
//#endregion
export { MatchDayPage as component };
