import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { c as Route$20 } from "./router-BqvUT-Ki.mjs";
import { t as PublicShell } from "./public-shell-BOyI-Zlg.mjs";
import { t as EmptyState } from "./empty-state-BMSD6eul.mjs";
import { t as SectionHead } from "./section-head-v7RAHbAM.mjs";
import { t as SeasonSwitch } from "./season-switch-BULz71yR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/achievements-3xZcZnmk.js
var import_jsx_runtime = require_jsx_runtime();
function AchievementsPage() {
	const data = Route$20.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicShell, {
		settings: data.settings,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-5xl px-4 py-14 sm:px-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
					overline: "The ledger",
					title: "Achievements",
					copy: "Confirmed titles, runs, and scars. Nothing here is decorative."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeasonSwitch, {
					seasons: data.seasons,
					current: data.season,
					path: "/achievements"
				})]
			}), data.items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-12",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
					title: "No achievements published",
					copy: "When a result is worth keeping, it will be added from HQ."
				})
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-12 space-y-0",
				children: data.items.map((a, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid gap-6 border-t border-white/10 py-10 md:grid-cols-[140px_1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm uppercase tracking-[0.18em] text-thunder",
						children: a.year || `0${idx + 1}`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						a.competition ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] uppercase tracking-[0.18em] text-steel",
							children: a.competition
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "mt-1 font-display text-4xl text-ivory",
							children: a.title
						}),
						a.result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-ivory",
							children: a.result
						}) : null,
						a.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-2xl text-sm leading-relaxed text-steel",
							children: a.description
						}) : null
					] })]
				}, a.id))
			})]
		})
	});
}
//#endregion
export { AchievementsPage as component };
