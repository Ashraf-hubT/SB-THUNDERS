import { createFileRoute } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { HqShell } from "@/components/hq/hq-shell";
import { ImageField } from "@/components/hq/image-field";
import { Button } from "@/components/ui/button";
import { Field, Input, Select, Textarea } from "@/components/ui/field";
import { deleteAchievement, getHqAchievements, saveAchievement } from "@/lib/server/hq";

export const Route = createFileRoute("/hq/achievements")({ component: AchievementsHq });

function AchievementsHq() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["hq-achievements"], queryFn: () => getHqAchievements() });
  const [title, setTitle] = useState("");
  const [year, setYear] = useState("");
  const [result, setResult] = useState("");
  const [competition, setCompetition] = useState("");
  const [description, setDescription] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [seasonId, setSeasonId] = useState("");
  const [published, setPublished] = useState(false);

  const save = useMutation({
    mutationFn: () =>
      saveAchievement({
        data: { title, year, result, competition, description, imageUrl, seasonId: seasonId || null, published },
      }),
    onSuccess: async () => {
      toast.success("Achievement saved");
      setTitle("");
      setYear("");
      setResult("");
      setCompetition("");
      setDescription("");
      setImageUrl("");
      setPublished(false);
      await qc.invalidateQueries();
    },
    onError: (e: Error) => toast.error(e.message),
  });

  return (
    <HqShell title="Achievements">
      <form
        className="panel grid gap-4 p-5 sm:grid-cols-2"
        onSubmit={(e) => {
          e.preventDefault();
          save.mutate();
        }}
      >
        <Field label="Title" className="sm:col-span-2">
          <Input required value={title} onChange={(e) => setTitle(e.target.value)} />
        </Field>
        <Field label="Year">
          <Input value={year} onChange={(e) => setYear(e.target.value)} />
        </Field>
        <Field label="Competition">
          <Input value={competition} onChange={(e) => setCompetition(e.target.value)} />
        </Field>
        <Field label="Result">
          <Input value={result} onChange={(e) => setResult(e.target.value)} />
        </Field>
        <Field label="Season">
          <Select value={seasonId} onChange={(e) => setSeasonId(e.target.value)}>
            <option value="">None</option>
            {(q.data?.seasons ?? []).map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Description" className="sm:col-span-2">
          <Textarea value={description} onChange={(e) => setDescription(e.target.value)} />
        </Field>
        <div className="sm:col-span-2">
          <ImageField label="Image" value={imageUrl} onChange={setImageUrl} />
        </div>
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={published} onChange={(e) => setPublished(e.target.checked)} />
          Publish
        </label>
        <Button type="submit" disabled={save.isPending}>
          Save
        </Button>
      </form>
      <ul className="mt-8 divide-y divide-white/5 border border-white/10">
        {(q.data?.items ?? []).map((a) => (
          <li key={a.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-4">
            <div>
              <p className="text-ivory">{a.title}</p>
              <p className="text-xs text-steel">
                {a.year} {a.published ? "· published" : "· draft"}
              </p>
            </div>
            <Button type="button" size="sm" variant="ghost" onClick={() => deleteAchievement({ data: { id: a.id } }).then(() => qc.invalidateQueries())}>
              Delete
            </Button>
          </li>
        ))}
      </ul>
    </HqShell>
  );
}
