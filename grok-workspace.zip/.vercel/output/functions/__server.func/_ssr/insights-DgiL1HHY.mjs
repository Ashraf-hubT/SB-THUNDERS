import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime, n as useQuery } from "../_libs/react+tanstack__react-query.mjs";
import { r as Select } from "./field-Cnn-JkFT.mjs";
import { d as getHqInsights } from "./hq-DLvonivC.mjs";
import { t as HqShell } from "./hq-shell-dMuZsJhJ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/insights-DgiL1HHY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function InsightsHq() {
	const [seasonId, setSeasonId] = (0, import_react.useState)("");
	const q = useQuery({
		queryKey: ["hq-insights", seasonId],
		queryFn: () => getHqInsights({ data: { seasonId: seasonId || void 0 } })
	});
	const i = q.data?.insights;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HqShell, {
		title: "Team insights",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
				className: "max-w-xs",
				value: q.data?.season?.id ?? seasonId,
				onChange: (e) => setSeasonId(e.target.value),
				children: (q.data?.seasons ?? []).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
					value: s.id,
					children: s.name
				}, s.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-xl text-sm text-steel",
				children: "These numbers are computed from published completed matches only. Draft historical records do not count until you publish them."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Played",
						value: i?.played ? String(i.played) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Wins",
						value: i?.played ? String(i.wins) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Losses",
						value: i?.played ? String(i.losses) : "—"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, {
						label: "Win %",
						value: i?.winPct === null || i?.winPct === void 0 ? "—" : `${i.winPct}%`
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-8 text-sm text-steel",
				children: [(q.data?.matches ?? []).filter((m) => !m.published).length, " unpublished matches in this season."]
			})
		]
	});
}
function Cell({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "panel p-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] uppercase tracking-[0.16em] text-steel",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 font-display text-4xl text-ivory",
			children: value
		})]
	});
}
//#endregion
export { InsightsHq as component };
