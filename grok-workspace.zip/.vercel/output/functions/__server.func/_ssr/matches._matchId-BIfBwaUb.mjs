import { n as isHttpUrl } from "./utils-4Kkadyjj.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { r as Route$3 } from "./router-BqvUT-Ki.mjs";
import { t as PublicShell } from "./public-shell-BOyI-Zlg.mjs";
import { t as EmptyState } from "./empty-state-BMSD6eul.mjs";
import { t as Button } from "./button-CiAG7yUi.mjs";
import { n as StatusPill } from "./status-pill-BO5B8Jkq.mjs";
import { t as format } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/matches._matchId-BIfBwaUb.js
var import_jsx_runtime = require_jsx_runtime();
function MatchPage() {
	const data = Route$3.useLoaderData();
	const m = data.match;
	if (!m) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicShell, {
		settings: data.settings,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-3xl px-4 py-24",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
				title: "Match not found",
				copy: "This fixture is unpublished or does not exist."
			})
		})
	});
	const dateLabel = m.matchDate ? (() => {
		try {
			return format(/* @__PURE__ */ new Date(m.matchDate + "T12:00:00"), "EEEE d MMMM yyyy");
		} catch {
			return m.matchDate;
		}
	})() : "Date TBC";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicShell, {
		settings: data.settings,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-4xl px-4 py-14 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { status: m.status }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-[12px] uppercase tracking-[0.24em] text-steel",
					children: "SB Thunders versus"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-6xl leading-none text-ivory sm:text-7xl",
					children: m.opponent
				}),
				m.competition ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-xs uppercase tracking-[0.18em] text-thunder",
					children: m.competition
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
					className: "mt-8 grid gap-4 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "panel p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[10px] uppercase tracking-[0.16em] text-steel",
								children: "Date"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-ivory",
								children: dateLabel
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "panel p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[10px] uppercase tracking-[0.16em] text-steel",
								children: "Time"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-ivory",
								children: m.matchTime || "TBC"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "panel p-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[10px] uppercase tracking-[0.16em] text-steel",
								children: "Venue"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 text-ivory",
								children: m.venue || "TBC"
							})]
						})
					]
				}),
				m.status === "completed" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 border-l-2 border-thunder pl-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-4xl text-ivory",
							children: m.result === "won" ? "SB THUNDERS WON" : m.result === "lost" ? "SB THUNDERS LOST" : "Result"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-steel",
							children: [
								m.ourScoreText,
								m.ourScoreText && m.oppScoreText ? "  —  " : "",
								m.oppScoreText
							]
						}),
						m.resultDescription ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-ivory",
							children: m.resultDescription
						}) : null,
						m.playerOfMatchName ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 text-xs uppercase tracking-[0.16em] text-thunder",
							children: ["Player of the match — ", m.playerOfMatchName]
						}) : null
					]
				}) : null,
				m.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-6 text-sm leading-relaxed text-steel",
					children: m.notes
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-12 font-display text-4xl text-ivory",
					children: "Match-day squad"
				}),
				data.squad.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-sm text-steel",
					children: "Playing XI has not been selected for this match."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "mt-4 divide-y divide-white/5 border border-white/5",
					children: data.squad.map((row, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/squad/$playerId",
						params: { playerId: row.playerId },
						className: "flex items-center justify-between px-4 py-3 text-sm text-ivory hover:text-thunder",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-3 tabular text-steel",
							children: String(i + 1).padStart(2, "0")
						}), row.player.displayName] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-[10px] uppercase tracking-[0.14em] text-steel",
							children: row.jerseyNumber ? `#${row.jerseyNumber}` : row.role
						})]
					}) }, row.playerId))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-wrap gap-3",
					children: [isHttpUrl(m.cricheroesUrl) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: m.cricheroesUrl,
							target: "_blank",
							rel: "noreferrer",
							children: "View on CricHeroes ↗"
						})
					}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/matches",
							children: "All matches"
						})
					})]
				})
			]
		})
	});
}
//#endregion
export { MatchPage as component };
