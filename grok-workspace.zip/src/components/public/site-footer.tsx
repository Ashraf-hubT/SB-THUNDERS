import { Link } from "@tanstack/react-router";
import { PUBLIC_NAV } from "@/lib/constants";
import { isHttpUrl } from "@/lib/utils";
import type { SiteSettings } from "@/lib/types";

export function SiteFooter({ settings }: { settings: SiteSettings }) {
  const socials = [
    { label: "Instagram", href: settings.instagramUrl },
    { label: "X", href: settings.twitterUrl },
    { label: "Facebook", href: settings.facebookUrl },
    { label: "YouTube", href: settings.youtubeUrl },
  ].filter((s) => isHttpUrl(s.href));

  return (
    <footer className="border-t border-white/5 bg-ink">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-3">
        <div>
          <div className="flex items-center gap-3">
            <img src={settings.logoUrl || "/team/logo.jpg"} alt="" className="h-12 w-12 object-contain" />
            <p className="font-display text-3xl leading-none text-ivory">SB THUNDERS</p>
          </div>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-steel">{settings.tagline}</p>
        </div>
        <div>
          <p className="text-[11px] uppercase tracking-[0.22em] text-thunder">Navigate</p>
          <ul className="mt-4 grid grid-cols-2 gap-2">
            {PUBLIC_NAV.map((item) => (
              <li key={item.to}>
                <Link to={item.to} className="text-sm text-steel hover:text-ivory">
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="text-[11px] uppercase tracking-[0.22em] text-thunder">Contact</p>
          <a href={`mailto:${settings.email}`} className="mt-4 block text-sm text-ivory hover:text-thunder">
            {settings.email}
          </a>
          {socials.length ? (
            <ul className="mt-4 flex flex-wrap gap-4">
              {socials.map((s) => (
                <li key={s.label}>
                  <a href={s.href} target="_blank" rel="noreferrer" className="text-sm text-steel hover:text-ivory">
                    {s.label}
                  </a>
                </li>
              ))}
            </ul>
          ) : null}
        </div>
      </div>
      <div className="border-t border-white/5">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-5 text-xs text-steel-2 sm:px-6">
          <p>© {new Date().getFullYear()} SB THUNDERS. All rights reserved.</p>
          <Link to="/login" className="tracking-[0.14em] uppercase hover:text-steel">
            HQ
          </Link>
        </div>
      </div>
    </footer>
  );
}
