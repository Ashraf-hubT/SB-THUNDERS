import { o as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-4Kkadyjj.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/safe-img-BxRY9_YA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function SafeImg({ src, alt, className, fallback }) {
	const [ok, setOk] = (0, import_react.useState)(true);
	if (!src || !ok) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("bg-navy-3", className),
		"aria-hidden": true,
		children: fallback ?? null
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src,
		alt,
		className,
		loading: "lazy",
		onError: () => setOk(false)
	});
}
//#endregion
export { SafeImg as t };
