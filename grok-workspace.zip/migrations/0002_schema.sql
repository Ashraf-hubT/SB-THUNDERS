-- SB THUNDERS content schema
-- Public CMS tables are team-owned (not per-visitor). Writes are enforced
-- in server functions via admin checks. Do not add Postgres extensions.

create table if not exists seasons (
  id            text primary key,
  name          text not null,
  slug          text not null unique,
  start_year    integer not null,
  end_year      integer not null,
  is_active     boolean not null default false,
  is_archived   boolean not null default false,
  tagline       text not null default '',
  notes         text not null default '',
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table if not exists site_settings (
  id                    text primary key default 'site',
  team_name             text not null default 'SB THUNDERS',
  tagline               text not null default 'MORE THAN A TEAM. ONE THUNDER.',
  supporting_copy       text not null default 'Built on cricket. Driven by brotherhood. Powered by the fight to come back stronger.',
  hero_line_1           text not null default 'SB',
  hero_line_2           text not null default 'THUNDERS',
  quote_line            text not null default '',
  story                 text not null default '',
  origin                text not null default '',
  values_text           text not null default '',
  philosophy            text not null default '',
  milestones            text not null default '',
  culture               text not null default '',
  email                 text not null default 'sbthunders@gmail.com',
  instagram_url         text not null default '',
  twitter_url           text not null default '',
  facebook_url          text not null default '',
  youtube_url           text not null default '',
  whatsapp_url          text not null default '',
  cricheroes_team_url   text not null default '',
  admin_name            text not null default 'Ashraf',
  admin_role            text not null default 'Team / Website Administrator',
  admin_photo_url       text not null default '/team/ashraf.jpg',
  admin_bio             text not null default '',
  admin_deep_dive_url   text not null default '',
  logo_url              text not null default '/team/logo.jpg',
  seo_title             text not null default 'SB THUNDERS — Official Team Portfolio',
  seo_description       text not null default 'Official home of SB THUNDERS. More than a team. One thunder.',
  updated_at            timestamptz not null default now()
);

create table if not exists admin_allowlist (
  email text primary key
);

create table if not exists admins (
  user_id       text primary key,
  email         text not null default '',
  display_name  text not null default '',
  created_at    timestamptz not null default now()
);

create table if not exists media (
  id            text primary key,
  mime_type     text not null,
  data_url      text not null,
  alt_text      text not null default '',
  created_by    text not null default '',
  created_at    timestamptz not null default now()
);

create table if not exists players (
  id              text primary key,
  full_name       text not null,
  display_name    text not null,
  photo_url       text not null default '',
  batting_style   text not null default '',
  bowling_style   text not null default '',
  bio             text not null default '',
  cricheroes_url  text not null default '',
  instagram_url   text not null default '',
  twitter_url     text not null default '',
  status          text not null default 'active',
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create table if not exists season_players (
  id                  text primary key,
  season_id           text not null references seasons(id) on delete cascade,
  player_id           text not null references players(id) on delete cascade,
  role                text not null default 'Batter',
  management_title    text not null default '',
  jersey_number       text not null default '',
  is_captain          boolean not null default false,
  is_vice_captain     boolean not null default false,
  display_order       integer not null default 0,
  status              text not null default 'active',
  unique (season_id, player_id)
);

create index if not exists season_players_season_idx on season_players (season_id);
create index if not exists season_players_player_idx on season_players (player_id);

create table if not exists matches (
  id                    text primary key,
  season_id             text not null references seasons(id) on delete cascade,
  opponent              text not null default '',
  venue                 text not null default '',
  match_date            date,
  match_time            text not null default '',
  status                text not null default 'upcoming',
  is_featured           boolean not null default false,
  published             boolean not null default false,
  our_score_text        text not null default '',
  opp_score_text        text not null default '',
  our_runs              integer,
  opp_runs              integer,
  result                text not null default '',
  result_description    text not null default '',
  player_of_match_id    text references players(id) on delete set null,
  notes                 text not null default '',
  cricheroes_url        text not null default '',
  competition           text not null default '',
  source_note           text not null default '',
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now()
);

create index if not exists matches_season_idx on matches (season_id);
create index if not exists matches_status_idx on matches (status);
create index if not exists matches_date_idx on matches (match_date);

create table if not exists match_squad (
  match_id        text not null references matches(id) on delete cascade,
  player_id       text not null references players(id) on delete cascade,
  is_playing      boolean not null default true,
  batting_order   integer not null default 0,
  primary key (match_id, player_id)
);

create table if not exists player_match_stats (
  match_id    text not null references matches(id) on delete cascade,
  player_id   text not null references players(id) on delete cascade,
  runs        integer,
  balls       integer,
  wickets     integer,
  overs       text not null default '',
  catches     integer,
  notes       text not null default '',
  primary key (match_id, player_id)
);

create table if not exists achievements (
  id            text primary key,
  season_id     text references seasons(id) on delete set null,
  match_id      text references matches(id) on delete set null,
  title         text not null,
  year          text not null default '',
  result        text not null default '',
  description   text not null default '',
  image_url     text not null default '',
  competition   text not null default '',
  published     boolean not null default false,
  display_order integer not null default 0,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create table if not exists gallery_items (
  id            text primary key,
  season_id     text references seasons(id) on delete set null,
  title         text not null default '',
  category      text not null default 'moments',
  image_url     text not null,
  alt_text      text not null default '',
  published     boolean not null default false,
  display_order integer not null default 0,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create index if not exists gallery_category_idx on gallery_items (category);

create table if not exists announcements (
  id            text primary key,
  title         text not null,
  body          text not null default '',
  published     boolean not null default false,
  pinned        boolean not null default false,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- Seed: identity + seasons. No invented players or verified public results.
insert into site_settings (id) values ('site')
  on conflict (id) do nothing;

insert into admin_allowlist (email) values ('sbthunders@gmail.com')
  on conflict (email) do nothing;

insert into seasons (id, name, slug, start_year, end_year, is_active, is_archived, tagline)
values
  ('season-2025-26', '2025–26 Season', '2025-26', 2025, 2026, false, true, ''),
  ('season-2026-27', '2026–27 Season', '2026-27', 2026, 2027, true, false, 'The next thunder.')
on conflict (id) do nothing;

-- Historical CricHeroes-era record, stored UNPUBLISHED so it is never
-- presented as verified until an administrator reviews and publishes it.
insert into matches (
  id, season_id, opponent, status, result, result_description,
  published, competition, source_note
) values
  ('m-hist-01', 'season-2025-26', 'RUN RIOTERS', 'completed', 'won', 'Won by 8 wickets', false, '', 'Historical reference — confirm before publishing.'),
  ('m-hist-02', 'season-2025-26', 'KG FIGHTERS', 'completed', 'won', 'Won by 17 runs', false, '', 'Historical reference — confirm before publishing.'),
  ('m-hist-03', 'season-2025-26', 'SELURPAR SUPER KINGS', 'completed', 'won', 'Won by 71 runs', false, '', 'Historical reference — confirm before publishing.'),
  ('m-hist-04', 'season-2025-26', 'MD CLUB', 'completed', 'lost', 'Lost by 22 runs', false, '', 'Historical reference — confirm before publishing.'),
  ('m-hist-05', 'season-2025-26', 'NHK TITANS', 'completed', 'lost', 'Lost by 19 runs', false, '', 'Historical reference — confirm before publishing.'),
  ('m-hist-06', 'season-2025-26', 'AG WARRIOR', 'completed', 'won', 'Won by 9 wickets', false, '', 'Historical reference — confirm before publishing.'),
  ('m-hist-07', 'season-2025-26', 'AMTOLA SUPER KINGS', 'completed', 'won', 'Won by 3 runs', false, '', 'Historical reference — confirm before publishing.'),
  ('m-hist-08', 'season-2025-26', 'AQIB WARRIORS', 'completed', 'lost', 'Lost by 8 wickets', false, '', 'Historical reference — confirm before publishing.'),
  ('m-hist-09', 'season-2025-26', 'SB STRIKERS', 'completed', 'won', 'Won by 9 wickets', false, '', 'Historical reference — confirm before publishing.'),
  ('m-hist-10', 'season-2025-26', 'AG WARRIOR', 'completed', 'lost', 'Lost by 7 wickets', false, 'Qualifier 1', 'Historical reference — confirm before publishing.'),
  ('m-hist-11', 'season-2025-26', 'AMTOLA SUPER KINGS', 'completed', 'lost', 'Lost by 76 runs', false, 'Qualifier 2', 'Historical reference — confirm before publishing.')
on conflict (id) do nothing;
