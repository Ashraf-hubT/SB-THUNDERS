import { t as cn } from "./utils-4Kkadyjj.mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/section-head-v7RAHbAM.js
var import_jsx_runtime = require_jsx_runtime();
function SectionHead({ overline, title, copy, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("max-w-3xl", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.28em] text-thunder",
				children: overline
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-2 font-display text-5xl leading-none text-ivory sm:text-6xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "thunder-line mt-4 max-w-40" }),
			copy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 max-w-xl text-sm leading-relaxed text-steel",
				children: copy
			}) : null
		]
	});
}
//#endregion
export { SectionHead as t };
