import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-4Kkadyjj.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function nid() {
	return crypto.randomUUID();
}
function isHttpUrl(value) {
	if (!value) return false;
	try {
		const u = new URL(value);
		return u.protocol === "http:" || u.protocol === "https:";
	} catch {
		return false;
	}
}
function winPct(wins, played) {
	if (!played) return null;
	return Math.round(wins / played * 1e3) / 10;
}
//#endregion
export { winPct as i, isHttpUrl as n, nid as r, cn as t };
