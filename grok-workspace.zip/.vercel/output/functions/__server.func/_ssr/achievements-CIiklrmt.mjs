import { o as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as Textarea, n as Input, r as Select, t as Field } from "./field-Cnn-JkFT.mjs";
import { _ as saveAchievement, a as deleteAchievement, c as getHqAchievements } from "./hq-DLvonivC.mjs";
import { t as HqShell } from "./hq-shell-dMuZsJhJ.mjs";
import { t as Button } from "./button-CiAG7yUi.mjs";
import { t as ImageField } from "./image-field-DyYab_pI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/achievements-CIiklrmt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AchievementsHq() {
	const qc = useQueryClient();
	const q = useQuery({
		queryKey: ["hq-achievements"],
		queryFn: () => getHqAchievements()
	});
	const [title, setTitle] = (0, import_react.useState)("");
	const [year, setYear] = (0, import_react.useState)("");
	const [result, setResult] = (0, import_react.useState)("");
	const [competition, setCompetition] = (0, import_react.useState)("");
	const [description, setDescription] = (0, import_react.useState)("");
	const [imageUrl, setImageUrl] = (0, import_react.useState)("");
	const [seasonId, setSeasonId] = (0, import_react.useState)("");
	const [published, setPublished] = (0, import_react.useState)(false);
	const save = useMutation({
		mutationFn: () => saveAchievement({ data: {
			title,
			year,
			result,
			competition,
			description,
			imageUrl,
			seasonId: seasonId || null,
			published
		} }),
		onSuccess: async () => {
			toast.success("Achievement saved");
			setTitle("");
			setYear("");
			setResult("");
			setCompetition("");
			setDescription("");
			setImageUrl("");
			setPublished(false);
			await qc.invalidateQueries();
		},
		onError: (e) => toast.error(e.message)
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(HqShell, {
		title: "Achievements",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "panel grid gap-4 p-5 sm:grid-cols-2",
			onSubmit: (e) => {
				e.preventDefault();
				save.mutate();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Title",
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						required: true,
						value: title,
						onChange: (e) => setTitle(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Year",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: year,
						onChange: (e) => setYear(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Competition",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: competition,
						onChange: (e) => setCompetition(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Result",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: result,
						onChange: (e) => setResult(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Season",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						value: seasonId,
						onChange: (e) => setSeasonId(e.target.value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "None"
						}), (q.data?.seasons ?? []).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: s.id,
							children: s.name
						}, s.id))]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Description",
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: description,
						onChange: (e) => setDescription(e.target.value)
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "sm:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImageField, {
						label: "Image",
						value: imageUrl,
						onChange: setImageUrl
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						checked: published,
						onChange: (e) => setPublished(e.target.checked)
					}), "Publish"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					disabled: save.isPending,
					children: "Save"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-8 divide-y divide-white/5 border border-white/10",
			children: (q.data?.items ?? []).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex flex-wrap items-center justify-between gap-3 px-4 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-ivory",
					children: a.title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-steel",
					children: [
						a.year,
						" ",
						a.published ? "· published" : "· draft"
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					size: "sm",
					variant: "ghost",
					onClick: () => deleteAchievement({ data: { id: a.id } }).then(() => qc.invalidateQueries()),
					children: "Delete"
				})]
			}, a.id))
		})]
	});
}
//#endregion
export { AchievementsHq as component };
