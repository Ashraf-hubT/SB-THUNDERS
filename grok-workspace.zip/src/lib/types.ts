import type { GalleryCategory, MatchResult, MatchStatus, PlayerRole } from "./constants";

export type SiteSettings = {
  id: string;
  teamName: string;
  tagline: string;
  supportingCopy: string;
  heroLine1: string;
  heroLine2: string;
  quoteLine: string;
  story: string;
  origin: string;
  valuesText: string;
  philosophy: string;
  milestones: string;
  culture: string;
  email: string;
  instagramUrl: string;
  twitterUrl: string;
  facebookUrl: string;
  youtubeUrl: string;
  whatsappUrl: string;
  cricheroesTeamUrl: string;
  adminName: string;
  adminRole: string;
  adminPhotoUrl: string;
  adminBio: string;
  adminDeepDiveUrl: string;
  logoUrl: string;
  seoTitle: string;
  seoDescription: string;
};

export type Season = {
  id: string;
  name: string;
  slug: string;
  startYear: number;
  endYear: number;
  isActive: boolean;
  isArchived: boolean;
  tagline: string;
  notes: string;
};

export type Player = {
  id: string;
  fullName: string;
  displayName: string;
  photoUrl: string;
  battingStyle: string;
  bowlingStyle: string;
  bio: string;
  cricheroesUrl: string;
  instagramUrl: string;
  twitterUrl: string;
  status: "active" | "archived";
};

export type SeasonPlayer = {
  id: string;
  seasonId: string;
  playerId: string;
  role: PlayerRole | string;
  managementTitle: string;
  jerseyNumber: string;
  isCaptain: boolean;
  isViceCaptain: boolean;
  displayOrder: number;
  status: "active" | "archived";
  player: Player;
};

export type Match = {
  id: string;
  seasonId: string;
  opponent: string;
  venue: string;
  matchDate: string | null;
  matchTime: string;
  status: MatchStatus | string;
  isFeatured: boolean;
  published: boolean;
  ourScoreText: string;
  oppScoreText: string;
  ourRuns: number | null;
  oppRuns: number | null;
  result: MatchResult | string;
  resultDescription: string;
  playerOfMatchId: string | null;
  notes: string;
  cricheroesUrl: string;
  competition: string;
  sourceNote: string;
  playerOfMatchName?: string | null;
};

export type MatchSquadMember = {
  playerId: string;
  isPlaying: boolean;
  battingOrder: number;
  player: Player;
  role?: string;
  jerseyNumber?: string;
};

export type Achievement = {
  id: string;
  seasonId: string | null;
  matchId: string | null;
  title: string;
  year: string;
  result: string;
  description: string;
  imageUrl: string;
  competition: string;
  published: boolean;
  displayOrder: number;
};

export type GalleryItem = {
  id: string;
  seasonId: string | null;
  title: string;
  category: GalleryCategory | string;
  imageUrl: string;
  altText: string;
  published: boolean;
  displayOrder: number;
};

export type Announcement = {
  id: string;
  title: string;
  body: string;
  published: boolean;
  pinned: boolean;
  createdAt: string;
};

export type TeamInsights = {
  played: number;
  wins: number;
  losses: number;
  draws: number;
  winPct: number | null;
  highestScore: number | null;
  lowestScore: number | null;
  bestIndividualScore: number | null;
  topRunScorer: { name: string; runs: number } | null;
  topWicketTaker: { name: string; wickets: number } | null;
};

export type HomePayload = {
  settings: SiteSettings;
  seasons: Season[];
  activeSeason: Season | null;
  featuredMatch: Match | null;
  nextMatch: Match | null;
  recentMatch: Match | null;
  todaysSquad: MatchSquadMember[];
  squad: SeasonPlayer[];
  insights: TeamInsights;
  gallery: GalleryItem[];
  achievements: Achievement[];
  recentMatches: Match[];
  announcements: Announcement[];
};

export type HqAccess = {
  isAdmin: boolean;
  email: string;
  displayName: string;
  userId: string;
};
