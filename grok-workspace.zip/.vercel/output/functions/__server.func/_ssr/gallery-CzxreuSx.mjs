import { o as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-4Kkadyjj.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { n as X } from "../_libs/lucide-react.mjs";
import { d as GALLERY_CATEGORIES, f as GALLERY_LABELS, s as Route$19 } from "./router-BqvUT-Ki.mjs";
import { t as PublicShell } from "./public-shell-BOyI-Zlg.mjs";
import { t as EmptyState } from "./empty-state-BMSD6eul.mjs";
import { t as SectionHead } from "./section-head-v7RAHbAM.mjs";
import { t as SeasonSwitch } from "./season-switch-BULz71yR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/gallery-CzxreuSx.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Lightbox({ items, index, onClose, onMove }) {
	const item = items[index];
	(0, import_react.useEffect)(() => {
		const onKey = (e) => {
			if (e.key === "Escape") onClose();
			if (e.key === "ArrowRight") onMove((index + 1) % items.length);
			if (e.key === "ArrowLeft") onMove((index - 1 + items.length) % items.length);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [
		index,
		items.length,
		onClose,
		onMove
	]);
	if (!item) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center bg-ink/95 p-4",
		role: "dialog",
		"aria-modal": "true",
		"aria-label": item.title || "Gallery image",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "absolute right-4 top-4 inline-flex h-11 w-11 items-center justify-center text-ivory",
				onClick: onClose,
				"aria-label": "Close",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-6 w-6" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: item.imageUrl,
				alt: item.altText || item.title || "SB Thunders gallery",
				className: "max-h-[82dvh] max-w-full object-contain"
			}),
			items.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-x-0 bottom-6 flex justify-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 px-4 text-xs uppercase tracking-[0.18em] text-steel hover:text-ivory",
					onClick: () => onMove((index - 1 + items.length) % items.length),
					children: "Previous"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "h-11 px-4 text-xs uppercase tracking-[0.18em] text-steel hover:text-ivory",
					onClick: () => onMove((index + 1) % items.length),
					children: "Next"
				})]
			}) : null
		]
	});
}
function GalleryPage() {
	const data = Route$19.useLoaderData();
	const [cat, setCat] = (0, import_react.useState)("all");
	const [open, setOpen] = (0, import_react.useState)(null);
	const filtered = (0, import_react.useMemo)(() => cat === "all" ? data.items : data.items.filter((i) => i.category === cat), [cat, data.items]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PublicShell, {
		settings: data.settings,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-7xl px-4 py-14 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
						overline: "Frames",
						title: "Thunder moments"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SeasonSwitch, {
						seasons: data.seasons,
						current: data.season,
						path: "/gallery"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-8 flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setCat("all"),
						className: cn("h-10 px-3 text-[11px] uppercase tracking-[0.16em]", cat === "all" ? "bg-thunder text-ivory" : "border border-white/10 text-steel"),
						children: "All"
					}), GALLERY_CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setCat(c),
						className: cn("h-10 px-3 text-[11px] uppercase tracking-[0.16em]", cat === c ? "bg-thunder text-ivory" : "border border-white/10 text-steel"),
						children: GALLERY_LABELS[c]
					}, c))]
				}),
				filtered.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						title: "No photographs yet",
						copy: "Upload match-day and training frames from HQ to fill this wall."
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 columns-1 gap-3 sm:columns-2 lg:columns-3",
					children: filtered.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "mb-3 block w-full overflow-hidden",
						onClick: () => setOpen(idx),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: item.imageUrl,
							alt: item.altText || item.title || "SB Thunders",
							className: "w-full object-cover",
							loading: "lazy"
						})
					}, item.id))
				})
			]
		}), open !== null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbox, {
			items: filtered,
			index: open,
			onClose: () => setOpen(null),
			onMove: setOpen
		}) : null]
	});
}
//#endregion
export { GalleryPage as component };
