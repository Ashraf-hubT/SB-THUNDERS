import { Link } from "@tanstack/react-router";
import type { SeasonPlayer } from "@/lib/types";
import { SafeImg } from "./safe-img";

export function PlayerCard({ entry }: { entry: SeasonPlayer }) {
  const p = entry.player;
  return (
    <Link
      to="/squad/$playerId"
      params={{ playerId: p.id }}
      className="group block"
    >
      <div className="relative aspect-[3/4] overflow-hidden bg-navy-3">
        <SafeImg
          src={p.photoUrl}
          alt={p.displayName}
          className="h-full w-full object-cover object-top transition-transform duration-500 group-hover:scale-[1.04]"
          fallback={
            <div className="flex h-full items-end p-4">
              <span className="font-display text-7xl text-ivory/10">
                {entry.jerseyNumber ? `#${entry.jerseyNumber}` : "SB"}
              </span>
            </div>
          }
        />
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink via-transparent to-transparent" />
        <div className="absolute inset-x-0 bottom-0 p-4">
          {entry.jerseyNumber ? (
            <p className="font-display text-3xl leading-none text-thunder">#{entry.jerseyNumber}</p>
          ) : null}
          <h3 className="mt-1 font-display text-2xl leading-none text-ivory">{p.displayName}</h3>
          <p className="mt-1 text-[11px] uppercase tracking-[0.18em] text-steel">{entry.role}</p>
          {entry.isCaptain ? (
            <p className="mt-2 text-[10px] uppercase tracking-[0.2em] text-thunder">Captain</p>
          ) : null}
        </div>
      </div>
    </Link>
  );
}
