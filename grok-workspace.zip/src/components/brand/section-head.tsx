import { cn } from "@/lib/utils";

export function SectionHead({
  overline,
  title,
  copy,
  className,
}: {
  overline: string;
  title: string;
  copy?: string;
  className?: string;
}) {
  return (
    <div className={cn("max-w-3xl", className)}>
      <p className="text-[11px] font-medium uppercase tracking-[0.28em] text-thunder">{overline}</p>
      <h2 className="mt-2 font-display text-5xl leading-none text-ivory sm:text-6xl">{title}</h2>
      <div className="thunder-line mt-4 max-w-40" />
      {copy ? <p className="mt-4 max-w-xl text-sm leading-relaxed text-steel">{copy}</p> : null}
    </div>
  );
}
