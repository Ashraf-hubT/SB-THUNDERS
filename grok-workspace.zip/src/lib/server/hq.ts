import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { EMPTY_INSIGHTS } from "@/lib/defaults";
import { nid } from "@/lib/utils";
import { assertAdmin } from "./admin";
import {
  fetchAchievements,
  fetchGallery,
  fetchInsights,
  fetchMatch,
  fetchMatchSquad,
  fetchMatches,
  fetchSeasons,
  fetchSettings,
  fetchSquad,
  pickFeaturedMatch,
} from "./repo";
import { mapPlayer } from "./map";

const adminMw = [authMiddleware];

function uid(context: { userId?: string } | undefined): string {
  if (!context?.userId) throw new Error("Unauthorized");
  return uid(context);
}

async function requireAdmin(userId: string) {
  return assertAdmin(userId);
}


export const getHqAccess = createServerFn({ method: "GET" })
  .middleware(adminMw)
  .handler(async ({ context }) => {
    const ident = await requireAdmin(uid(context));
    return { isAdmin: true as const, ...ident };
  });

export const getHqDashboard = createServerFn({ method: "GET" })
  .middleware(adminMw)
  .handler(async ({ context }) => {
    await requireAdmin(uid(context));
    const settings = await fetchSettings();
    const seasons = await fetchSeasons();
    const active = seasons.find((s) => s.isActive) ?? null;
    if (!active) {
      return {
        settings,
        seasons,
        active,
        squadCount: 0,
        insights: EMPTY_INSIGHTS,
        featured: null,
        next: null,
        recent: null,
        gallery: [],
        draftMatches: 0,
      };
    }
    const [squad, matches, gallery, insights] = await Promise.all([
      fetchSquad(active.id, { includeArchived: true }),
      fetchMatches(active.id),
      fetchGallery(active.id, { limit: 6 }),
      fetchInsights(active.id),
    ]);
    const { featured, next, recent } = pickFeaturedMatch(matches);
    return {
      settings,
      seasons,
      active,
      squadCount: squad.filter((s) => s.status === "active").length,
      insights,
      featured,
      next,
      recent,
      gallery,
      draftMatches: matches.filter((m) => !m.published).length,
    };
  });

export const getHqSeasons = createServerFn({ method: "GET" })
  .middleware(adminMw)
  .handler(async ({ context }) => {
    await requireAdmin(uid(context));
    return fetchSeasons();
  });

export const saveSeason = createServerFn({ method: "POST" })
  .middleware(adminMw)
  .validator((data: {
    id?: string;
    name: string;
    slug: string;
    startYear: number;
    endYear: number;
    tagline?: string;
    notes?: string;
    isActive?: boolean;
    isArchived?: boolean;
  }) => data)
  .handler(async ({ context, data }) => {
    await requireAdmin(uid(context));
    const sql = await getSql();
    const id = data.id || nid();
    if (data.isActive) {
      await sql`update seasons set is_active = false, updated_at = now()`;
    }
    await sql`
      insert into seasons (id, name, slug, start_year, end_year, is_active, is_archived, tagline, notes, updated_at)
      values (
        ${id}, ${data.name.trim()}, ${data.slug.trim()}, ${data.startYear}, ${data.endYear},
        ${Boolean(data.isActive)}, ${Boolean(data.isArchived)}, ${data.tagline ?? ""}, ${data.notes ?? ""}, now()
      )
      on conflict (id) do update set
        name = excluded.name,
        slug = excluded.slug,
        start_year = excluded.start_year,
        end_year = excluded.end_year,
        is_active = excluded.is_active,
        is_archived = excluded.is_archived,
        tagline = excluded.tagline,
        notes = excluded.notes,
        updated_at = now()
    `;
    return { id };
  });

export const setActiveSeason = createServerFn({ method: "POST" })
  .middleware(adminMw)
  .validator((data: { id: string }) => data)
  .handler(async ({ context, data }) => {
    await requireAdmin(uid(context));
    const sql = await getSql();
    await sql`update seasons set is_active = false, updated_at = now()`;
    await sql`update seasons set is_active = true, is_archived = false, updated_at = now() where id = ${data.id}`;
    return { ok: true };
  });

export const getHqPlayers = createServerFn({ method: "GET" })
  .middleware(adminMw)
  .validator((data: { seasonId?: string }) => data)
  .handler(async ({ context, data }) => {
    await requireAdmin(uid(context));
    const seasons = await fetchSeasons();
    const season = data.seasonId
      ? seasons.find((s) => s.id === data.seasonId) ?? seasons.find((s) => s.isActive)
      : seasons.find((s) => s.isActive) ?? seasons[0];
    const sql = await getSql();
    const allPlayers = await sql<Record<string, unknown>>`
      select * from players order by display_name asc
    `;
    const squad = season ? await fetchSquad(season.id, { includeArchived: true }) : [];
    return {
      seasons,
      season,
      players: allPlayers.map((r) => mapPlayer(r)),
      squad,
    };
  });

export const savePlayer = createServerFn({ method: "POST" })
  .middleware(adminMw)
  .validator((data: {
    id?: string;
    fullName: string;
    displayName: string;
    photoUrl?: string;
    battingStyle?: string;
    bowlingStyle?: string;
    bio?: string;
    cricheroesUrl?: string;
    instagramUrl?: string;
    twitterUrl?: string;
    status?: "active" | "archived";
    seasonId?: string;
    role?: string;
    managementTitle?: string;
    jerseyNumber?: string;
    isCaptain?: boolean;
    isViceCaptain?: boolean;
    attachToSeason?: boolean;
  }) => data)
  .handler(async ({ context, data }) => {
    await requireAdmin(uid(context));
    const sql = await getSql();
    const id = data.id || nid();
    await sql`
      insert into players (
        id, full_name, display_name, photo_url, batting_style, bowling_style, bio,
        cricheroes_url, instagram_url, twitter_url, status, updated_at
      ) values (
        ${id}, ${data.fullName.trim()}, ${data.displayName.trim()}, ${data.photoUrl ?? ""},
        ${data.battingStyle ?? ""}, ${data.bowlingStyle ?? ""}, ${data.bio ?? ""},
        ${data.cricheroesUrl ?? ""}, ${data.instagramUrl ?? ""}, ${data.twitterUrl ?? ""},
        ${data.status ?? "active"}, now()
      )
      on conflict (id) do update set
        full_name = excluded.full_name,
        display_name = excluded.display_name,
        photo_url = excluded.photo_url,
        batting_style = excluded.batting_style,
        bowling_style = excluded.bowling_style,
        bio = excluded.bio,
        cricheroes_url = excluded.cricheroes_url,
        instagram_url = excluded.instagram_url,
        twitter_url = excluded.twitter_url,
        status = excluded.status,
        updated_at = now()
    `;
    if (data.seasonId && (data.attachToSeason !== false)) {
      const spId = nid();
      await sql`
        insert into season_players (
          id, season_id, player_id, role, management_title, jersey_number,
          is_captain, is_vice_captain, status
        ) values (
          ${spId}, ${data.seasonId}, ${id}, ${data.role ?? "Batter"}, ${data.managementTitle ?? ""},
          ${data.jerseyNumber ?? ""}, ${Boolean(data.isCaptain)}, ${Boolean(data.isViceCaptain)}, 'active'
        )
        on conflict (season_id, player_id) do update set
          role = excluded.role,
          management_title = excluded.management_title,
          jersey_number = excluded.jersey_number,
          is_captain = excluded.is_captain,
          is_vice_captain = excluded.is_vice_captain,
          status = 'active'
      `;
    }
    return { id };
  });

export const setPlayerSeason = createServerFn({ method: "POST" })
  .middleware(adminMw)
  .validator((data: {
    playerId: string;
    seasonId: string;
    role: string;
    managementTitle?: string;
    jerseyNumber?: string;
    isCaptain?: boolean;
    isViceCaptain?: boolean;
    status?: "active" | "archived";
    remove?: boolean;
  }) => data)
  .handler(async ({ context, data }) => {
    await requireAdmin(uid(context));
    const sql = await getSql();
    if (data.remove) {
      await sql`delete from season_players where player_id = ${data.playerId} and season_id = ${data.seasonId}`;
      return { ok: true };
    }
    const spId = nid();
    await sql`
      insert into season_players (
        id, season_id, player_id, role, management_title, jersey_number,
        is_captain, is_vice_captain, status
      ) values (
        ${spId}, ${data.seasonId}, ${data.playerId}, ${data.role}, ${data.managementTitle ?? ""},
        ${data.jerseyNumber ?? ""}, ${Boolean(data.isCaptain)}, ${Boolean(data.isViceCaptain)},
        ${data.status ?? "active"}
      )
      on conflict (season_id, player_id) do update set
        role = excluded.role,
        management_title = excluded.management_title,
        jersey_number = excluded.jersey_number,
        is_captain = excluded.is_captain,
        is_vice_captain = excluded.is_vice_captain,
        status = excluded.status
    `;
    return { ok: true };
  });

export const archivePlayer = createServerFn({ method: "POST" })
  .middleware(adminMw)
  .validator((data: { id: string; archived: boolean }) => data)
  .handler(async ({ context, data }) => {
    await requireAdmin(uid(context));
    const sql = await getSql();
    const status = data.archived ? "archived" : "active";
    await sql`update players set status = ${status}, updated_at = now() where id = ${data.id}`;
    return { ok: true };
  });

export const getHqMatches = createServerFn({ method: "GET" })
  .middleware(adminMw)
  .validator((data: { seasonId?: string }) => data)
  .handler(async ({ context, data }) => {
    await requireAdmin(uid(context));
    const seasons = await fetchSeasons();
    const season = data.seasonId
      ? seasons.find((s) => s.id === data.seasonId)
      : seasons.find((s) => s.isActive) ?? seasons[0];
    const matches = season ? await fetchMatches(season.id) : [];
    return { seasons, season, matches };
  });

export const getHqMatch = createServerFn({ method: "GET" })
  .middleware(adminMw)
  .validator((data: { id: string }) => data)
  .handler(async ({ context, data }) => {
    await requireAdmin(uid(context));
    const match = await fetchMatch(data.id);
    const squad = match ? await fetchMatchSquad(match.id) : [];
    const seasons = await fetchSeasons();
    const season = match ? seasons.find((s) => s.id === match.seasonId) ?? null : null;
    const roster = season ? await fetchSquad(season.id, { includeArchived: true }) : [];
    const sql = await getSql();
    const selected = match
      ? await sql<{ player_id: string }>`select player_id from match_squad where match_id = ${match.id} and is_playing = true`
      : [];
    return {
      match,
      squad,
      seasons,
      season,
      roster,
      selectedIds: selected.map((r) => r.player_id),
    };
  });

export const saveMatch = createServerFn({ method: "POST" })
  .middleware(adminMw)
  .validator((data: {
    id?: string;
    seasonId: string;
    opponent: string;
    venue?: string;
    matchDate?: string | null;
    matchTime?: string;
    status?: string;
    isFeatured?: boolean;
    published?: boolean;
    ourScoreText?: string;
    oppScoreText?: string;
    ourRuns?: number | null;
    oppRuns?: number | null;
    result?: string;
    resultDescription?: string;
    playerOfMatchId?: string | null;
    notes?: string;
    cricheroesUrl?: string;
    competition?: string;
    sourceNote?: string;
    squadIds?: string[];
  }) => data)
  .handler(async ({ context, data }) => {
    await requireAdmin(uid(context));
    const sql = await getSql();
    const id = data.id || nid();
    if (data.isFeatured) {
      await sql`update matches set is_featured = false where season_id = ${data.seasonId}`;
    }
    const dateVal = data.matchDate ? data.matchDate : null;
    await sql`
      insert into matches (
        id, season_id, opponent, venue, match_date, match_time, status, is_featured, published,
        our_score_text, opp_score_text, our_runs, opp_runs, result, result_description,
        player_of_match_id, notes, cricheroes_url, competition, source_note, updated_at
      ) values (
        ${id}, ${data.seasonId}, ${data.opponent.trim()}, ${data.venue ?? ""}, ${dateVal},
        ${data.matchTime ?? ""}, ${data.status ?? "upcoming"}, ${Boolean(data.isFeatured)},
        ${Boolean(data.published)}, ${data.ourScoreText ?? ""}, ${data.oppScoreText ?? ""},
        ${data.ourRuns ?? null}, ${data.oppRuns ?? null}, ${data.result ?? ""},
        ${data.resultDescription ?? ""}, ${data.playerOfMatchId ?? null}, ${data.notes ?? ""},
        ${data.cricheroesUrl ?? ""}, ${data.competition ?? ""}, ${data.sourceNote ?? ""}, now()
      )
      on conflict (id) do update set
        season_id = excluded.season_id,
        opponent = excluded.opponent,
        venue = excluded.venue,
        match_date = excluded.match_date,
        match_time = excluded.match_time,
        status = excluded.status,
        is_featured = excluded.is_featured,
        published = excluded.published,
        our_score_text = excluded.our_score_text,
        opp_score_text = excluded.opp_score_text,
        our_runs = excluded.our_runs,
        opp_runs = excluded.opp_runs,
        result = excluded.result,
        result_description = excluded.result_description,
        player_of_match_id = excluded.player_of_match_id,
        notes = excluded.notes,
        cricheroes_url = excluded.cricheroes_url,
        competition = excluded.competition,
        source_note = excluded.source_note,
        updated_at = now()
    `;
    if (data.squadIds) {
      await sql`delete from match_squad where match_id = ${id}`;
      for (let i = 0; i < data.squadIds.length; i++) {
        const pid = data.squadIds[i];
        await sql`
          insert into match_squad (match_id, player_id, is_playing, batting_order)
          values (${id}, ${pid}, true, ${i})
        `;
      }
    }
    return { id };
  });

export const getHqMatchDay = createServerFn({ method: "GET" })
  .middleware(adminMw)
  .handler(async ({ context }) => {
    await requireAdmin(uid(context));
    const seasons = await fetchSeasons();
    const active = seasons.find((s) => s.isActive) ?? seasons[0] ?? null;
    const matches = active ? await fetchMatches(active.id) : [];
    const { featured, next } = pickFeaturedMatch(matches);
    const current = featured ?? next ?? matches[0] ?? null;
    const roster = active ? await fetchSquad(active.id, { includeArchived: true }) : [];
    const selected = current
      ? (await fetchMatchSquad(current.id)).map((s) => s.playerId)
      : [];
    return { seasons, active, matches, current, roster, selected };
  });

export const saveMedia = createServerFn({ method: "POST" })
  .middleware(adminMw)
  .validator((data: { dataUrl: string; alt?: string }) => data)
  .handler(async ({ context, data }) => {
    const ident = await requireAdmin(uid(context));
    const url = data.dataUrl.trim();
    if (!url.startsWith("data:image/")) throw new Error("Only image uploads are allowed.");
    if (url.length > 1_400_000) throw new Error("Image is too large. Compress it under 1MB.");
    const mime = url.slice(5, url.indexOf(";")) || "image/jpeg";
    if (!/^image\/(jpeg|png|webp|gif)$/.test(mime)) throw new Error("Unsupported image type.");
    const id = nid();
    const sql = await getSql();
    await sql`
      insert into media (id, mime_type, data_url, alt_text, created_by)
      values (${id}, ${mime}, ${url}, ${data.alt ?? ""}, ${ident.userId})
    `;
    return { id, url: `/api/media/${id}` };
  });

export const getHqGallery = createServerFn({ method: "GET" })
  .middleware(adminMw)
  .handler(async ({ context }) => {
    await requireAdmin(uid(context));
    const seasons = await fetchSeasons();
    const items = await fetchGallery(null);
    return { seasons, items };
  });

export const saveGalleryItem = createServerFn({ method: "POST" })
  .middleware(adminMw)
  .validator((data: {
    id?: string;
    title?: string;
    category: string;
    imageUrl: string;
    altText?: string;
    seasonId?: string | null;
    published?: boolean;
    displayOrder?: number;
  }) => data)
  .handler(async ({ context, data }) => {
    await requireAdmin(uid(context));
    const sql = await getSql();
    const id = data.id || nid();
    await sql`
      insert into gallery_items (
        id, season_id, title, category, image_url, alt_text, published, display_order, updated_at
      ) values (
        ${id}, ${data.seasonId ?? null}, ${data.title ?? ""}, ${data.category}, ${data.imageUrl},
        ${data.altText ?? ""}, ${Boolean(data.published)}, ${data.displayOrder ?? 0}, now()
      )
      on conflict (id) do update set
        season_id = excluded.season_id,
        title = excluded.title,
        category = excluded.category,
        image_url = excluded.image_url,
        alt_text = excluded.alt_text,
        published = excluded.published,
        display_order = excluded.display_order,
        updated_at = now()
    `;
    return { id };
  });

export const deleteGalleryItem = createServerFn({ method: "POST" })
  .middleware(adminMw)
  .validator((data: { id: string }) => data)
  .handler(async ({ context, data }) => {
    await requireAdmin(uid(context));
    const sql = await getSql();
    await sql`delete from gallery_items where id = ${data.id}`;
    return { ok: true };
  });

export const getHqAchievements = createServerFn({ method: "GET" })
  .middleware(adminMw)
  .handler(async ({ context }) => {
    await requireAdmin(uid(context));
    const seasons = await fetchSeasons();
    const items = await fetchAchievements(null);
    return { seasons, items };
  });

export const saveAchievement = createServerFn({ method: "POST" })
  .middleware(adminMw)
  .validator((data: {
    id?: string;
    title: string;
    year?: string;
    result?: string;
    description?: string;
    imageUrl?: string;
    competition?: string;
    seasonId?: string | null;
    published?: boolean;
    displayOrder?: number;
  }) => data)
  .handler(async ({ context, data }) => {
    await requireAdmin(uid(context));
    const sql = await getSql();
    const id = data.id || nid();
    await sql`
      insert into achievements (
        id, season_id, title, year, result, description, image_url, competition, published, display_order, updated_at
      ) values (
        ${id}, ${data.seasonId ?? null}, ${data.title.trim()}, ${data.year ?? ""}, ${data.result ?? ""},
        ${data.description ?? ""}, ${data.imageUrl ?? ""}, ${data.competition ?? ""},
        ${Boolean(data.published)}, ${data.displayOrder ?? 0}, now()
      )
      on conflict (id) do update set
        season_id = excluded.season_id,
        title = excluded.title,
        year = excluded.year,
        result = excluded.result,
        description = excluded.description,
        image_url = excluded.image_url,
        competition = excluded.competition,
        published = excluded.published,
        display_order = excluded.display_order,
        updated_at = now()
    `;
    return { id };
  });

export const deleteAchievement = createServerFn({ method: "POST" })
  .middleware(adminMw)
  .validator((data: { id: string }) => data)
  .handler(async ({ context, data }) => {
    await requireAdmin(uid(context));
    const sql = await getSql();
    await sql`delete from achievements where id = ${data.id}`;
    return { ok: true };
  });

export const saveSettings = createServerFn({ method: "POST" })
  .middleware(adminMw)
  .validator((data: Record<string, string>) => data)
  .handler(async ({ context, data }) => {
    await requireAdmin(uid(context));
    const sql = await getSql();
    const s = (k: string, fallback = "") => data[k] ?? fallback;
    await sql`
      update site_settings set
        team_name = ${s("teamName", "SB THUNDERS")},
        tagline = ${s("tagline")},
        supporting_copy = ${s("supportingCopy")},
        hero_line_1 = ${s("heroLine1", "SB")},
        hero_line_2 = ${s("heroLine2", "THUNDERS")},
        quote_line = ${s("quoteLine")},
        story = ${s("story")},
        origin = ${s("origin")},
        values_text = ${s("valuesText")},
        philosophy = ${s("philosophy")},
        milestones = ${s("milestones")},
        culture = ${s("culture")},
        email = ${s("email", "sbthunders@gmail.com")},
        instagram_url = ${s("instagramUrl")},
        twitter_url = ${s("twitterUrl")},
        facebook_url = ${s("facebookUrl")},
        youtube_url = ${s("youtubeUrl")},
        whatsapp_url = ${s("whatsappUrl")},
        cricheroes_team_url = ${s("cricheroesTeamUrl")},
        admin_name = ${s("adminName", "Ashraf")},
        admin_role = ${s("adminRole")},
        admin_photo_url = ${s("adminPhotoUrl")},
        admin_bio = ${s("adminBio")},
        admin_deep_dive_url = ${s("adminDeepDiveUrl")},
        logo_url = ${s("logoUrl", "/team/logo.jpg")},
        seo_title = ${s("seoTitle")},
        seo_description = ${s("seoDescription")},
        updated_at = now()
      where id = 'site'
    `;
    return { ok: true };
  });

export const getHqSettings = createServerFn({ method: "GET" })
  .middleware(adminMw)
  .handler(async ({ context }) => {
    const ident = await requireAdmin(uid(context));
    const settings = await fetchSettings();
    const sql = await getSql();
    const allow = await sql<{ email: string }>`select email from admin_allowlist order by email`;
    return { settings, ident, allowlist: allow.map((r) => r.email) };
  });

export const addAllowlistEmail = createServerFn({ method: "POST" })
  .middleware(adminMw)
  .validator((data: { email: string }) => data)
  .handler(async ({ context, data }) => {
    await requireAdmin(uid(context));
    const email = data.email.trim().toLowerCase();
    if (!email.includes("@")) throw new Error("Enter a valid email.");
    const sql = await getSql();
    await sql`insert into admin_allowlist (email) values (${email}) on conflict do nothing`;
    return { ok: true };
  });

export const getHqInsights = createServerFn({ method: "GET" })
  .middleware(adminMw)
  .validator((data: { seasonId?: string }) => data)
  .handler(async ({ context, data }) => {
    await requireAdmin(uid(context));
    const seasons = await fetchSeasons();
    const season = data.seasonId
      ? seasons.find((s) => s.id === data.seasonId)
      : seasons.find((s) => s.isActive) ?? seasons[0];
    const insights = season ? await fetchInsights(season.id) : EMPTY_INSIGHTS;
    const matches = season ? await fetchMatches(season.id) : [];
    return { seasons, season, insights, matches };
  });
