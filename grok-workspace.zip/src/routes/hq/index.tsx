import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { HqShell } from "@/components/hq/hq-shell";
import { Button } from "@/components/ui/button";
import { StatusPill } from "@/components/brand/status-pill";
import { getHqDashboard } from "@/lib/server/hq";

export const Route = createFileRoute("/hq/")({
  component: HqHome,
});

function HqHome() {
  const q = useQuery({ queryKey: ["hq-dashboard"], queryFn: () => getHqDashboard() });
  const d = q.data;

  return (
    <HqShell title="Dashboard">
      {q.isPending ? (
        <p className="text-sm text-steel">Loading HQ…</p>
      ) : q.error ? (
        <p className="text-sm text-thunder">Could not load dashboard.</p>
      ) : d ? (
        <>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Stat label="Active season" value={d.active?.name ?? "—"} />
            <Stat label="Players" value={String(d.squadCount)} />
            <Stat label="Matches played" value={d.insights.played ? String(d.insights.played) : "—"} />
            <Stat
              label="Win %"
              value={d.insights.winPct === null ? "—" : `${d.insights.winPct}%`}
            />
          </div>
          <div className="mt-6 grid gap-4 lg:grid-cols-2">
            <div className="panel p-5">
              <div className="flex items-center justify-between">
                <p className="text-[11px] uppercase tracking-[0.18em] text-steel">Today / next match</p>
                {d.featured ? <StatusPill status={d.featured.status} /> : null}
              </div>
              <h2 className="mt-4 font-display text-4xl text-ivory">
                {d.featured?.opponent || d.next?.opponent || "No fixture set"}
              </h2>
              <p className="mt-2 text-sm text-steel">
                {d.featured?.venue || d.next?.venue || "Set opponent, time, and venue from Match Day."}
              </p>
              <div className="mt-5">
                <Button asChild>
                  <Link to="/hq/match-day">Open match day</Link>
                </Button>
              </div>
            </div>
            <div className="panel p-5">
              <p className="text-[11px] uppercase tracking-[0.18em] text-steel">Recent result</p>
              <h2 className="mt-4 font-display text-4xl text-ivory">
                {d.recent?.opponent ?? "No published result"}
              </h2>
              <p className="mt-2 text-sm text-steel">
                {d.recent?.resultDescription || (d.draftMatches ? `${d.draftMatches} draft matches waiting` : "—")}
              </p>
              <div className="mt-5 flex gap-3">
                <Button asChild variant="outline">
                  <Link to="/hq/matches">Matches</Link>
                </Button>
                <Button asChild variant="ghost">
                  <Link to="/hq/gallery">Gallery</Link>
                </Button>
              </div>
            </div>
          </div>
          {d.gallery.length > 0 ? (
            <div className="mt-8">
              <p className="text-[11px] uppercase tracking-[0.18em] text-steel">Latest uploads</p>
              <div className="mt-3 grid grid-cols-3 gap-2 sm:grid-cols-6">
                {d.gallery.map((g) => (
                  <img key={g.id} src={g.imageUrl} alt="" className="aspect-square object-cover" />
                ))}
              </div>
            </div>
          ) : null}
        </>
      ) : null}
    </HqShell>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="panel p-4">
      <p className="text-[11px] uppercase tracking-[0.16em] text-steel">{label}</p>
      <p className="mt-2 font-display text-3xl text-ivory">{value}</p>
    </div>
  );
}
