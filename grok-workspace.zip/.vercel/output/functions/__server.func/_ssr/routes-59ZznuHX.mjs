import { n as isHttpUrl } from "./utils-4Kkadyjj.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { h as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { u as Route$22 } from "./router-BqvUT-Ki.mjs";
import { t as PublicShell } from "./public-shell-BOyI-Zlg.mjs";
import { t as EmptyState } from "./empty-state-BMSD6eul.mjs";
import { t as SectionHead } from "./section-head-v7RAHbAM.mjs";
import { t as Button } from "./button-CiAG7yUi.mjs";
import { n as MatchCard, t as FeaturedMatch } from "./featured-match-DcnasVJS.mjs";
import { t as SafeImg } from "./safe-img-BxRY9_YA.mjs";
import { t as PlayerCard } from "./player-card-kewBYBDF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-59ZznuHX.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const data = Route$22.useLoaderData();
	const s = data.settings;
	const insightCells = [
		{
			label: "Matches",
			value: data.insights.played ? String(data.insights.played) : "—"
		},
		{
			label: "Wins",
			value: data.insights.played ? String(data.insights.wins) : "—"
		},
		{
			label: "Losses",
			value: data.insights.played ? String(data.insights.losses) : "—"
		},
		{
			label: "Win %",
			value: data.insights.winPct === null ? "—" : `${data.insights.winPct}`
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PublicShell, {
		settings: s,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative min-h-[88dvh] overflow-hidden hero-storm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "lightning-veil" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "lightning-flash" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative mx-auto flex min-h-[88dvh] max-w-7xl flex-col justify-end px-4 pb-16 pt-24 sm:px-6 sm:pb-20",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "stagger-in max-w-4xl",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
									src: s.logoUrl || "/team/logo.jpg",
									alt: "SB Thunders",
									className: "h-20 w-20 object-contain sm:h-24 sm:w-24"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-8 text-[12px] uppercase tracking-[0.36em] text-thunder",
									children: "Official team portfolio"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
									className: "mt-3 font-display leading-[0.8] text-ivory",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-[22vw] sm:text-[9.5rem]",
										children: s.heroLine1 || "SB"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "block text-[14vw] text-thunder sm:text-[7.5rem]",
										children: s.heroLine2 || "THUNDERS"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-6 max-w-xl text-lg tracking-[0.12em] text-ivory sm:text-xl",
									children: s.tagline
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 max-w-xl text-sm leading-relaxed text-steel",
									children: s.supportingCopy
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mt-8 flex flex-wrap gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										size: "lg",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/squad",
											children: "Meet the squad"
										})
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										asChild: true,
										variant: "outline",
										size: "lg",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/matches",
											children: "Latest match"
										})
									})]
								})
							]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FeaturedMatch, {
				match: data.featuredMatch ?? data.nextMatch,
				squad: data.todaysSquad
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-7xl px-4 py-20 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
						overline: "The brotherhood",
						title: "Meet the Thunders",
						copy: "The active-season squad. Roles move with the season — players, management, or both."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/squad",
							children: "Full squad"
						})
					})]
				}), data.squad.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						title: "Squad forthcoming",
						copy: "The current season list is being assembled in HQ. Names will appear here when published — we will not invent them."
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4",
					children: data.squad.slice(0, 8).map((entry) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayerCard, { entry }, entry.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-y border-white/5 bg-navy-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-4 py-20 sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
							overline: "Numbers that are earned",
							title: "Team insights",
							copy: "Only published, confirmed matches count. Empty cells stay empty until the data is real."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-10 grid grid-cols-2 gap-3 lg:grid-cols-4",
							children: insightCells.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "panel p-5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] uppercase tracking-[0.18em] text-steel",
									children: c.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 font-display text-5xl tabular text-ivory",
									children: c.value
								})]
							}, c.label))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "ghost",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/insights",
									children: ["Open insights ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "h-4 w-4" })]
								})
							})
						})
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-7xl px-4 py-20 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
						overline: "Thunder moments",
						title: "Gallery"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/gallery",
							children: "All photos"
						})
					})]
				}), data.gallery.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						title: "Moments incoming",
						copy: "Match-day frames and graphics will hang here after they are uploaded from HQ."
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid grid-cols-2 gap-3 md:grid-cols-4",
					children: data.gallery.map((g) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SafeImg, {
						src: g.imageUrl,
						alt: g.altText || g.title || "SB Thunders",
						className: "aspect-[4/5] w-full object-cover"
					}, g.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "border-y border-white/5 bg-ink",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto max-w-7xl px-4 py-20 sm:px-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
						overline: "Silverware & scars",
						title: "Achievements"
					}), data.achievements.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
							title: "The ledger is open",
							copy: "Titles and milestones will be recorded here once confirmed."
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid gap-4 md:grid-cols-3",
						children: data.achievements.slice(0, 3).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
							className: "panel p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-[11px] uppercase tracking-[0.18em] text-thunder",
									children: a.year || a.competition
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "mt-3 font-display text-3xl text-ivory",
									children: a.title
								}),
								a.result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm text-steel",
									children: a.result
								}) : null
							]
						}, a.id))
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mx-auto max-w-7xl px-4 py-20 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-end justify-between gap-6",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
						overline: "Archive",
						title: "Match history"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/matches",
							children: "All matches"
						})
					})]
				}), data.recentMatches.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
						title: "No published results yet",
						copy: "Completed matches appear here after they are published from HQ."
					})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10 grid gap-4 md:grid-cols-3",
					children: data.recentMatches.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, { match: m }, m.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "relative overflow-hidden border-y border-white/5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hero-storm absolute inset-0 opacity-30" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto max-w-7xl px-4 py-24 sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] uppercase tracking-[0.28em] text-thunder",
							children: "Our story"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 max-w-3xl font-display text-6xl leading-[0.9] text-ivory sm:text-7xl",
							children: "This is more than cricket."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-2xl text-base leading-relaxed text-steel",
							children: s.story || "The origin, values, and milestones of SB THUNDERS will be written here by the team — not invented for the website."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "outline",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/about",
									children: "Read about the Thunders"
								})
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "mx-auto max-w-7xl px-4 py-20 sm:px-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid items-center gap-10 lg:grid-cols-[0.9fr_1.1fr]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "relative aspect-[4/5] overflow-hidden bg-navy-3 sm:aspect-[3/4]",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SafeImg, {
							src: s.adminPhotoUrl || "/team/ashraf.jpg",
							alt: s.adminName,
							className: "h-full w-full object-cover object-top"
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] uppercase tracking-[0.28em] text-thunder",
							children: "The one behind the Thunders"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 font-display text-6xl text-ivory",
							children: s.adminName
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm uppercase tracking-[0.16em] text-steel",
							children: s.adminRole
						}),
						s.adminBio ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-xl text-sm leading-relaxed text-steel",
							children: s.adminBio
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: `mailto:${s.email}`,
							className: "mt-6 inline-block text-ivory hover:text-thunder",
							children: s.email
						}),
						isHttpUrl(s.adminDeepDiveUrl) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
								href: s.adminDeepDiveUrl,
								className: "text-sm uppercase tracking-[0.16em] text-thunder hover:text-ivory",
								children: "Deep dive into Admin world → Know more about Admin"
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 text-sm text-steel-2",
							children: "Deep dive into Admin world — link reserved."
						})
					] })]
				})
			})
		]
	});
}
//#endregion
export { Home as component };
