//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BG1qquVv.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/hq",
			"/about",
			"/achievements",
			"/gallery",
			"/insights",
			"/login",
			"/matches",
			"/squad",
			"/api/auth/$",
			"/api/media/$id"
		],
		preloads: [
			"/assets/index-BXj8KkGD.js",
			"/assets/react-SIfiwpqq.js",
			"/assets/preload-helper-DvJ3lTku.js",
			"/assets/constants-DDAdx05T.js",
			"/assets/root-DLTE-HSj.js",
			"/assets/public-DS-xf900.js",
			"/assets/useNavigate-DrqvhG58.js",
			"/assets/search-Cv6JxibE.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BXj8KkGD.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BDWOt9pv.js",
			"/assets/utils-DFz7DA99.js",
			"/assets/public-shell-B65oTXRb.js",
			"/assets/empty-state-DPCyu9d2.js",
			"/assets/section-head-DpgMHM0A.js",
			"/assets/button-BU34GG3Q.js",
			"/assets/featured-match-CEtVrg9q.js",
			"/assets/safe-img-DgGgwUbk.js",
			"/assets/player-card-0SQLbNr8.js"
		]
	},
	"/hq": {
		filePath: "/workspace/src/routes/hq/route.tsx",
		children: [
			"/hq/achievements",
			"/hq/gallery",
			"/hq/insights",
			"/hq/match-day",
			"/hq/matches",
			"/hq/players",
			"/hq/profile",
			"/hq/seasons",
			"/hq/settings",
			"/hq/"
		],
		preloads: [
			"/assets/route-Btpe934n.js",
			"/assets/hq-ClkEajE6.js",
			"/assets/use-current-user-C4dygdOb.js",
			"/assets/button-BU34GG3Q.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-DJL6A30G.js",
			"/assets/utils-DFz7DA99.js",
			"/assets/public-shell-B65oTXRb.js"
		]
	},
	"/achievements": {
		filePath: "/workspace/src/routes/achievements.tsx",
		children: void 0,
		preloads: [
			"/assets/achievements-q30e0gDB.js",
			"/assets/public-shell-B65oTXRb.js",
			"/assets/empty-state-DPCyu9d2.js",
			"/assets/section-head-DpgMHM0A.js",
			"/assets/season-switch-CT1a2OB-.js"
		]
	},
	"/gallery": {
		filePath: "/workspace/src/routes/gallery.tsx",
		children: void 0,
		preloads: [
			"/assets/gallery-Bd4Ju91i.js",
			"/assets/x-DQdqnNgo.js",
			"/assets/utils-DFz7DA99.js",
			"/assets/public-shell-B65oTXRb.js",
			"/assets/empty-state-DPCyu9d2.js",
			"/assets/section-head-DpgMHM0A.js",
			"/assets/season-switch-CT1a2OB-.js"
		]
	},
	"/insights": {
		filePath: "/workspace/src/routes/insights.tsx",
		children: void 0,
		preloads: [
			"/assets/insights-CZhYQ5Wq.js",
			"/assets/public-shell-B65oTXRb.js",
			"/assets/empty-state-DPCyu9d2.js",
			"/assets/section-head-DpgMHM0A.js",
			"/assets/season-switch-CT1a2OB-.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DRrBZipP.js",
			"/assets/client-C85fcJ4s.js",
			"/assets/field-wK81M7Xg.js",
			"/assets/use-current-user-C4dygdOb.js",
			"/assets/button-BU34GG3Q.js"
		]
	},
	"/matches": {
		filePath: "/workspace/src/routes/matches.tsx",
		children: ["/matches/$matchId"],
		preloads: [
			"/assets/matches-Ceb79lc1.js",
			"/assets/public-shell-B65oTXRb.js",
			"/assets/empty-state-DPCyu9d2.js",
			"/assets/section-head-DpgMHM0A.js",
			"/assets/season-switch-CT1a2OB-.js",
			"/assets/featured-match-CEtVrg9q.js"
		]
	},
	"/squad": {
		filePath: "/workspace/src/routes/squad.tsx",
		children: ["/squad/$playerId"],
		preloads: [
			"/assets/squad-ByX4K9XZ.js",
			"/assets/public-shell-B65oTXRb.js",
			"/assets/empty-state-DPCyu9d2.js",
			"/assets/section-head-DpgMHM0A.js",
			"/assets/season-switch-CT1a2OB-.js",
			"/assets/player-card-0SQLbNr8.js"
		]
	},
	"/hq/achievements": {
		filePath: "/workspace/src/routes/hq/achievements.tsx",
		children: void 0,
		preloads: [
			"/assets/achievements-Ce3eg2v6.js",
			"/assets/hq-shell-SoQoi8AL.js",
			"/assets/useMutation-BuYXSvLO.js",
			"/assets/field-wK81M7Xg.js",
			"/assets/image-field-JYMZAAhv.js"
		]
	},
	"/hq/gallery": {
		filePath: "/workspace/src/routes/hq/gallery.tsx",
		children: void 0,
		preloads: [
			"/assets/gallery-BIC-HkNs.js",
			"/assets/hq-shell-SoQoi8AL.js",
			"/assets/useMutation-BuYXSvLO.js",
			"/assets/field-wK81M7Xg.js",
			"/assets/image-79oAZxsA.js"
		]
	},
	"/hq/insights": {
		filePath: "/workspace/src/routes/hq/insights.tsx",
		children: void 0,
		preloads: [
			"/assets/insights-hBNyP1hL.js",
			"/assets/hq-shell-SoQoi8AL.js",
			"/assets/field-wK81M7Xg.js"
		]
	},
	"/hq/match-day": {
		filePath: "/workspace/src/routes/hq/match-day.tsx",
		children: void 0,
		preloads: [
			"/assets/match-day-BDGKzJ-O.js",
			"/assets/hq-shell-SoQoi8AL.js",
			"/assets/useMutation-BuYXSvLO.js",
			"/assets/field-wK81M7Xg.js"
		]
	},
	"/hq/matches": {
		filePath: "/workspace/src/routes/hq/matches.tsx",
		children: void 0,
		preloads: [
			"/assets/matches-BhmNOzVQ.js",
			"/assets/hq-shell-SoQoi8AL.js",
			"/assets/useMutation-BuYXSvLO.js",
			"/assets/field-wK81M7Xg.js",
			"/assets/status-pill-CSWZQ5AP.js"
		]
	},
	"/hq/players": {
		filePath: "/workspace/src/routes/hq/players.tsx",
		children: void 0,
		preloads: [
			"/assets/players-CNT4Kwch.js",
			"/assets/hq-shell-SoQoi8AL.js",
			"/assets/useMutation-BuYXSvLO.js",
			"/assets/field-wK81M7Xg.js",
			"/assets/image-field-JYMZAAhv.js"
		]
	},
	"/hq/profile": {
		filePath: "/workspace/src/routes/hq/profile.tsx",
		children: void 0,
		preloads: [
			"/assets/profile-DDQhAzfQ.js",
			"/assets/hq-shell-SoQoi8AL.js",
			"/assets/useMutation-BuYXSvLO.js",
			"/assets/field-wK81M7Xg.js",
			"/assets/image-field-JYMZAAhv.js"
		]
	},
	"/hq/seasons": {
		filePath: "/workspace/src/routes/hq/seasons.tsx",
		children: void 0,
		preloads: [
			"/assets/seasons-BZhpnwWE.js",
			"/assets/hq-shell-SoQoi8AL.js",
			"/assets/useMutation-BuYXSvLO.js",
			"/assets/field-wK81M7Xg.js"
		]
	},
	"/hq/settings": {
		filePath: "/workspace/src/routes/hq/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-woXE9WGU.js",
			"/assets/hq-shell-SoQoi8AL.js",
			"/assets/useMutation-BuYXSvLO.js",
			"/assets/field-wK81M7Xg.js",
			"/assets/image-field-JYMZAAhv.js"
		]
	},
	"/matches/$matchId": {
		filePath: "/workspace/src/routes/matches.$matchId.tsx",
		children: void 0,
		preloads: [
			"/assets/matches._matchId-DfTZHIne.js",
			"/assets/utils-DFz7DA99.js",
			"/assets/button-BU34GG3Q.js",
			"/assets/status-pill-CSWZQ5AP.js",
			"/assets/format-DVr6sjC1.js"
		]
	},
	"/squad/$playerId": {
		filePath: "/workspace/src/routes/squad.$playerId.tsx",
		children: void 0,
		preloads: [
			"/assets/squad._playerId-DGq30E2Q.js",
			"/assets/utils-DFz7DA99.js",
			"/assets/button-BU34GG3Q.js",
			"/assets/safe-img-DgGgwUbk.js"
		]
	},
	"/hq/": {
		filePath: "/workspace/src/routes/hq/index.tsx",
		children: void 0,
		preloads: [
			"/assets/hq-D-x4pYh_.js",
			"/assets/hq-shell-SoQoi8AL.js",
			"/assets/status-pill-CSWZQ5AP.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
